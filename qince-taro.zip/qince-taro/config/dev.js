/*
 * @Author: CaiPeng
 * @Date: 2022-09-14 15:49:15
 * @LastEditors: caipeng
 * @LastEditTime: 2023-05-29 16:40:04
 * @FilePath: \qince-taro\config\dev.js
 * @Description: 
 */
// H5 端使用 devServer 实现跨域，需要修改 package.json 的运行命令，加入环境变量
const isH5 = process.env.CLIENT_ENV === 'h5'

// const HOST = '"https://wxgateway.waiqin365.com"'  // 勤策   wxeed62e5cb360a640
const HOST = '"https://wxgatewaytest.waiqin365.com"' // 柠云测试  wxb75c623d16d21769

module.exports = {
  env: {
    NODE_ENV: '"development"'
  },
  defineConstants: {
    HOST: isH5 ? '"/api"' : HOST
  },
  mini: {},
  h5: {}
}

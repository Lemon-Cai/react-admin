import { useState } from 'react'
import classNames from 'classnames'
import { Input, Text, View } from '@tarojs/components'

const SearchBar = props => {
  const {
    value = '',
    placeholder = '搜索',
    maxLength = 140,
    fixed = false,
    disabled = false,
    showActionButton = false,
    actionName = '搜索',
    inputType = 'input', // 处理issue#464
    className,
    ...others
  } = props

  const [state, setState] = useState({
    isFocus: !!props.focus
  })

  const handleFocus = event => {
    setState(prevState => ({
      ...prevState,
      isFocus: true
    }))
    props.onFocus && props.onFocus(event)
  }

  const handleBlur = event => {
    setState(prevState => ({
      ...prevState,
      isFocus: false
    }))
    props.onBlur && props.onBlur(event)
  }

  const handleChange = e => {
    props.onChange(e.detail.value, e)
  }

  const handleClear = event => {
    if (props.onClear) {
      props.onClear(event)
    } else {
      props.onChange('', event)
    }
  }

  const handleConfirm = event => {
    props.onConfirm && props.onConfirm(event)
  }

  const handleActionClick = event => {
    props.onActionClick && props.onActionClick(event)
  }

  const fontSize = 14
  const rootCls = classNames(
    'at-search-bar',
    {
      'at-search-bar--fixed': fixed
    },
    className
  )
  const placeholderWrapStyle = {}
  const actionStyle = {}
  if (state.isFocus || (!state.isFocus && value)) {
    actionStyle.opacity = 1
    actionStyle.marginRight = `0`
    placeholderWrapStyle.flexGrow = 0
  } else if (!state.isFocus && !value) {
    placeholderWrapStyle.flexGrow = 1
    actionStyle.opacity = 0
    actionStyle.marginRight = `-${(actionName.length + 1) * fontSize + fontSize / 2 + 10}px`
  }
  if (showActionButton) {
    actionStyle.opacity = 1
    actionStyle.marginRight = `0`
  }

  const clearIconStyle = { display: 'flex' }
  const placeholderStyle = { visibility: 'hidden' }
  if (!value.length) {
    clearIconStyle.display = 'none'
    placeholderStyle.visibility = 'visible'
  }

  return (
    <View className={rootCls} {...others}>
      <View className="at-search-bar__input-cnt">
        <View className="at-search-bar__placeholder-wrap" style={placeholderWrapStyle}>
          <Text className="at-icon at-icon-search"></Text>
          <Text className="at-search-bar__placeholder" style={placeholderStyle}>
            {state.isFocus ? '' : placeholder}
          </Text>
        </View>
        <Input
          className="at-search-bar__input"
          type={inputType}
          confirmType="search"
          value={value}
          focus={state.isFocus}
          disabled={disabled}
          maxlength={maxLength}
          onInput={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onConfirm={handleConfirm}
        />
        <View className="at-search-bar__clear" style={clearIconStyle} onTouchStart={handleClear}>
          <Text className="at-icon at-icon-close-circle"></Text>
        </View>
      </View>
      <View className="at-search-bar__action" style={actionStyle} onClick={handleActionClick}>
        {actionName}
      </View>
    </View>
  )
}

export default SearchBar

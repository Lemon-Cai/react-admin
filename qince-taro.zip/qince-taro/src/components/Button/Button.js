import { useMemo } from 'react'
import Taro from '@tarojs/taro'
import classNames from 'classnames'

import { mergeStyle } from '@/utils'

import { Button, Text } from '@tarojs/components'

export default props => {
  const {
    type = 'default',
    disabled = false,
    mini = false,
    plain = false,
    loading = false,
    border = true,
    gradients,
    children,
    ...others
  } = props

  const env = { // eslint-disable-line
    isWEB: Taro.getEnv() === Taro.ENV_TYPE.WEB,
    isWEAPP: Taro.getEnv() === Taro.ENV_TYPE.WEAPP,
    isALIPAY: Taro.getEnv() === Taro.ENV_TYPE.ALIPAY
  }

  const handleClick = e => {
    if (!disabled) {
      props.onClick && props.onClick(e)
    }
  }

  const style = useMemo(() => {
    if (gradients && Array.isArray(gradients) && gradients.length === 2) {
      return {
        background: `linear-gradient(90deg, ${gradients[0]}, ${gradients[1]})`,
        color: '#fff'
      }
    }
  }, [gradients])

  return (
    <Button
      {...others}
      disabled={disabled}
      type={type}
      className={classNames(
        `weui-btn ${others.className}`,
        {
          'weui-btn_disabled': !plain && disabled,
          'weui-btn_plain-disabled': plain && disabled,
          'weui-btn_mini': mini,
          'qince-button-no-border': border
        },
        [
          !plain ? `weui-btn_${type}` : '',
          plain ? `weui-btn_plain-${type}` : '',
          loading ? `weui-btn_loading` : ''
        ]
      )}
      style={mergeStyle(style, others.style)}
      onClick={handleClick}
    >
      {loading && <Text className="weui-loading"></Text>}
      {children}
    </Button>
  )
}

import './ProgressBar.less'
import ProgressBar from './ProgressBar'

export { ProgressBar }

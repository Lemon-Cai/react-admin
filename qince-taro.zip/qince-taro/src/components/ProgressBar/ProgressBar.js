import { View } from '@tarojs/components'
import classNames from 'classnames'

const classPrefix = `qince-progress-bar`

const ProgressBar = props => {
  const { percent = 0, rounded = true, text = false } = props

  const textElement = (function() {
    if (text === true) {
      return `${percent}%`
    }
    if (typeof text === 'function') {
      return text(percent)
    }
    return text
  })()

  return (
    <View
      className={classNames(classPrefix, {
        [`${classPrefix}-rounded`]: rounded
      })}
    >
      <View className={`${classPrefix}-trail`}>
        <View className={`${classPrefix}-fill`} style={{ width: `${percent}%` }} />
      </View>
      {textElement && <View className={`${classPrefix}-text`}>{textElement}</View>}
    </View>
  )
}

export default ProgressBar

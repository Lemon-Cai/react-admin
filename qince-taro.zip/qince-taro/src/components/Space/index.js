import './space.less'
import Space from './Space'

export { Space }

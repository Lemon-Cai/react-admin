import React from 'react'
import { View } from '@tarojs/components'
import classNames from 'classnames'

const classPrefix = `qince-space`

const Space = props => {
  const { direction = 'horizontal', children, ...others } = props

  return (
    <View
      className={classNames(classPrefix, {
        [`${classPrefix}-wrap`]: props.wrap,
        [`${classPrefix}-block`]: props.block,
        [`${classPrefix}-${direction}`]: true,
        [`${classPrefix}-align-${props.align}`]: !!props.align,
        [`${classPrefix}-justify-${props.justify}`]: !!props.justify
      })}
      {...others}
    >
      {React.Children.map(children, child => {
        return (
          child !== null &&
          child !== undefined && <View className={`${classPrefix}-item`}>{child}</View>
        )
      })}
    </View>
  )
}

export default Space

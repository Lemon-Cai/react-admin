import { View } from '@tarojs/components'
import { useState, useEffect } from 'react'
import { Icons } from '../Icons'

export default ({
  isControl = false,  // 完全受控
  checked = false,
  halfChecked,        // 子节点选中 半选中
  onChange,
  children,
  ...others
}) => {
  const [_checked, setChecked] = useState(checked)

  useEffect(() => {
    if (checked !== _checked) setChecked(checked)
  }, [checked]) // eslint-disable-line

  const handleChangeChecked = () => {
    !isControl && setChecked(!_checked)
    onChange && onChange(!_checked)
  }

  return (
    <View
      style={{ display: 'flex', alignItems: 'center' }}
      onClick={handleChangeChecked}
      {...others}
    >
      <Icons
        style={{
          marginRight: 8,
          fontSize: 22,
          color: _checked ? '#ff9008' : halfChecked ? '#eee' : '#b6b6b6',
          ...(others.style || {})
        }}
        value={_checked || halfChecked ? 'checked' : 'check'}
      ></Icons>
      {children}
    </View>
  )
}

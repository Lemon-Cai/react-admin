import Employee from './Employee'

export default Employee
import { forwardRef, useImperativeHandle } from 'react'
import Taro, { useDidShow } from '@tarojs/taro'

import { View } from '@tarojs/components'

export default forwardRef(({
  onChange,
  value,
  multiple = true,
  menuId = '',
  empQueryParams = {},    // 人员接口入参
  deptQueryParams = {},  // 部门接口入参
  beforeConfirm,        // Promise 人员选择确定前操作 resolve(false)则终止
  children,
  className
}, ref) => {
  // beforeConfirm = (val) => {
  //   return new Promise(resolve => {
  //     Taro.showModal({
  //       content: '您编辑的内容将会发送给全公司，确定发送吗？',
  //       success ({cancel}) {
  //         resolve(cancel ? false : true)
  //       },
  //       fail: () => {
  //         resolve(false)
  //       }
  //     })
  //   })
  // }
  useImperativeHandle(ref, () => ({
    handleOpen
  }))

  useDidShow(() => {
    let data = Taro.getCurrentInstance()?.page?.data || ''
    if (data?.empSelected) {
      onChange && onChange(data?.empSelected || [])
      Taro.getCurrentInstance().page.data.empSelected = ''
    }
  })

  const handleOpen = () => {
    Taro.navigateTo({
      title: '选择人员',
      url: `/pages/Components/Employee/index?menuId=${menuId}`,
      success: res => {
        res.eventChannel.emit('empDatas', {
          value,
          empQueryParams,
          deptQueryParams,
          multiple,
          beforeConfirm
        })
      }
    })
  }

  return (
    <View onClick={handleOpen} className={className}>
      <View>{children}</View>
    </View>
  )
})
import classNames from 'classnames'
import { View } from '@tarojs/components'

import { Space } from '@/components/Space'
import { Flex, FlexItem } from '@/components/Flex'
import { Cell, CellHeader, CellBody } from '@/components/Cell'

import './index.less'

const SubmitBar = props => {
  const {
    className,
    data = [],
    checked = false,
    editable = false,
    onCheck = () => {},
    onClick = () => {}
  } = props

  return (
    <Flex className={classNames('qince-submit-bar', className)}>
      {editable ? (
        <>
          <FlexItem>
            <Cell>
              <CellHeader onClick={onCheck}>{checked ? '取消全选' : '全选'}</CellHeader>
              <CellBody>
                <Space block justify="end" style={{ '--gap-horizontal': '12px' }}>
                  {data.map((item, index) => (
                    <View
                      key={item.key || index}
                      type={item.type}
                      className={classNames('qince-submit-btn', {
                        'wq-border': true,
                        'qince-submit-btn-mini': true,
                        [`qince-submit-btn-${item.type}`]: item.type
                      })}
                      onClick={() => onClick(item)}
                    >
                      {item.name}
                    </View>
                  ))}
                </Space>
              </CellBody>
            </Cell>
          </FlexItem>
        </>
      ) : (
        data.map((item, index) => (
          <>
            <FlexItem
              className={classNames('qince-submit-btn', {
                [`qince-submit-btn-${item.type}`]: item.type
              })}
              key={item.key || index}
              onClick={() => onClick(item)}
            >
              {item.name}
            </FlexItem>
            {index < data.length - 1 && <View className="qince-submit-split"></View>}
          </>
        ))
      )}
    </Flex>
  )
}

export default SubmitBar

import { useState, useEffect, useRef } from 'react'
// import Taro from '@tarojs/taro'
import { View, ScrollView } from '@tarojs/components'
import { styled } from 'linaria/lib/react'
import classNames from 'classnames'

import './index.less'


const Empty = styled(View)`
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  &:before {
    content: '暂无数据'
  }
`

// https://taro-docs.jd.com/docs/components/viewContainer/scroll-view
export default ({
  list = [], // 列表数据
  alphabetBar = false, // 是否启用字母导航 配合列表数据
  alphabetField = 'name_spell', // 列表item中导航字段  例如员工接口中name_spell
  renderItem, // 列表数据渲染函数 // 渲染单个item函数
  onScrollToLower = () => {}, // 滚动到底部/右边，会触发 scrolltolower 事件
  onScrollToUpper = () => {}, // 滚动到顶部/左边，会触发 onScrollToUpper 事件
  scrollY = true,
  scrollWithAnimation = true,
  ...others
}) => {
  const [bars, setBars] = useState([])
  const [scrollId, setScrollId] = useState('')
  const scrollRef = useRef(null)

  useEffect(() => {
    if (alphabetBar && list.length) {
      // 收集右侧导航
      handleFormatAlphabetBar()
    } else {
      setBars([])
    }
  }, [alphabetBar, list]) // eslint-disable-line

  const handleFormatAlphabetBar = () => {
    let barList = []
    list.forEach(item => {
      if (item[alphabetField] && !barList.includes(item[alphabetField])) {
        barList.push(item[alphabetField])
      }
    })
    setBars(barList)
  }

  const renderFormatList = () => {
    if (alphabetBar && bars.length) {
      return bars.map(bar => (
        <View key={bar}>
          <View
            className={classNames('bar-row')}
            id={`bar-${bar}`}
          >
            {bar}
          </View>
          <View>
            {list
              .filter(data => data[alphabetField] === bar)
              .map(item => (
                <>
                  {renderItem ? (
                    renderItem(item)
                  ) : (
                    <View style={{ height: 38, lineHeight: '38px' }}>{item.name}</View>
                  )}
                </>
              ))}
          </View>
        </View>
      ))
    } else {
      return list.map(item => (
        <>
          {renderItem ? (
            renderItem(item)
          ) : (
            <View style={{ height: 38, lineHeight: '38px' }}>{item.name}</View>
          )}
        </>
      ))
    }
  }

  const handleClickBar = bar => {
    setScrollId(`bar-${bar}`)
  }

  return (
    <View className="page-scroll-view">
      <ScrollView
        ref={scrollRef}
        enhanced
        // scrollTop={_scrollTop}
        scrollIntoView={scrollId}
        scrollY={scrollY}
        lowerThreshold={40}
        scrollWithAnimation={scrollWithAnimation}
        onScrollToLower={onScrollToLower}
        onScrollToUpper={onScrollToUpper}
        {...others}
      >
        {list?.length ? renderFormatList() : <Empty />}
      </ScrollView>
      {bars.length > 0 && (
        <View className="right-bars">
          {bars.map(item => (
            <View onClick={() => handleClickBar(item)} className="bar-item" key={item}>
              {item}
            </View>
          ))}
        </View>
      )}
    </View>
  )
}

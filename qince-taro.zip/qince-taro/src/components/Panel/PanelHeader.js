import classNames from 'classnames'
import { View } from '@tarojs/components'

export default props => {
  const { children, className, ...others } = props

  return (
    <View className={classNames('weui-panel__hd', className)} {...others}>
      {children}
    </View>
  )
}

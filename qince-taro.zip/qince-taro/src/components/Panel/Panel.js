import classNames from 'classnames'
import { View } from '@tarojs/components'

export default props => {
  const { children, className, access = false, ...others } = props

  return (
    <View
      className={classNames(
        'weui-panel',
        {
          'weui-panel_access': access
        },
        className
      )}
      {...others}
    >
      {children}
    </View>
  )
}

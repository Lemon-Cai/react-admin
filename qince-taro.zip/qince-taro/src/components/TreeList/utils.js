import _cloneDeep from 'lodash/cloneDeep'
import _differenceBy from 'lodash/differenceBy'

export default {
  // 树节点 结构平铺
  getTileNode: treeNode => {
    const cloneData = _cloneDeep(treeNode)
    const nodeList = []

    const pushData = data => {
      const childrenData = data?.children || null
      delete data.children
      nodeList.push(data)
      if (childrenData?.length) {
        childrenData.forEach(node => {
          pushData(node)
        })
      }
    }
    pushData(cloneData)
    return nodeList
  },
  // 获取父级列表
  getParentsNode(node, treeData) {
    // 获取层级比当前节点高的列表数据
    const list = this.getTileData(treeData, node.index + 1)

    const topList = []
    const getParentItem = treeNode => {
      const parentId = list.find(i => i.id === treeNode.id)?.pId
      const parentNode = list.find(i => i.id === parentId)

      parentNode && topList.push(parentNode)

      if (parentId && parentId !== '-1') {
        getParentItem(parentNode)
      }
    }
    getParentItem(node)

    return topList
  },
  // 获取关联后的父级列表
  getRelationParentsNode(node, selectedNode, treeData) {
    // 获取同级数据  照顾人员比部门index+1
    const list = this.getTileData(treeData, node.index + 1)

    // 关联选中的父级节点
    let checkedList = []

    const getParentsChecked = _node => {
      // 找到当前节点的pId  筛选出相同的pId兄弟节点
      const currentPid = list.find(i => i.id === _node.id)?.pId
      let siblingNodes = _cloneDeep(list.filter(i => i.pId === currentPid))
      let newSelectedNode = [...selectedNode, _node]

      let filtereds = _differenceBy(siblingNodes, newSelectedNode, 'id')
      if (filtereds.length === 0) {
        let targetItem = list.find(i => i.id === currentPid)
        // 父级选中
        checkedList.push(targetItem)
        getParentsChecked(targetItem)
      }
    }
    getParentsChecked(node)

    return checkedList
  },
  // 树列表平铺
  getTileData(treeData, limitIndex = 0) {
    const nodeList = []
    const pushData = (list, pId = '-1') => {
      list.forEach(item => {
        if (limitIndex && item.index > limitIndex) {
          return
        }
        nodeList.push({
          ...item,
          pId
        })
        const childrenData = item?.children || null
        if (childrenData?.length) {
          pushData(childrenData, item.id)
        }
      })
    }
    pushData(treeData)
    return nodeList
  }
}

import { View } from '@tarojs/components'
import classNames from 'classnames'

const PageAffix = props => {
  const { className, children, ...others } = props
  return (
    <View
      className={classNames('qince-page-affix', className)}
      {...others}
    >
      {children}
    </View>
  )
}

export default PageAffix

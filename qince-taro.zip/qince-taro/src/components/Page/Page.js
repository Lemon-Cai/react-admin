import { View } from '@tarojs/components'
import classNames from 'classnames'

import './page.less'

const Page = props => {
  const { className, children, ...others } = props

  return (
    <View className={classNames('qince-page', className)} {...others}>
      {children}
    </View>
  )
}

export default Page

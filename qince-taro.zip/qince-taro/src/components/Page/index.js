import Page from './page'
import PageAffix from './PageAffix'
import PageHeader from './PageHeader'
import PageSegment from './PageSegment'
import PageBody from './PageBody'
import PageFooter from './PageFooter'

export { Page, PageAffix, PageHeader, PageSegment, PageBody, PageFooter }

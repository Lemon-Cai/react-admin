import { View } from '@tarojs/components'
import classNames from 'classnames'

const PageBody = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('qince-page-body', className)} {...others}>
      {children}
    </View>
  )
}

export default PageBody

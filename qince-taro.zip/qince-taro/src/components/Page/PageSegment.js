import { View } from '@tarojs/components'
import classNames from 'classnames'

const PageSegment = props => {
  const { className, fixed = false, placeholder = false, children, ...others } = props
  return (
    <View
      className={classNames('qince-page-segment', { 
        'qince-page-segment-fixed': fixed ,
        'qince-page-segment-placeholder': placeholder
    }, className)}
      {...others}
    >
      {children}
    </View>
  )
}

export default PageSegment

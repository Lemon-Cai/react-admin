import { View } from '@tarojs/components'

const classPrefix = 'qince-auto-center'

const AutoCenter = props => {
  return (
    <View className={classPrefix}>
      <View className={`${classPrefix}-content`}>{props.children}</View>
    </View>
  )
}

export default AutoCenter

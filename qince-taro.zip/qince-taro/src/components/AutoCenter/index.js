import './autoCenter.less'
import AutoCenter from './AutoCenter'

export { AutoCenter }
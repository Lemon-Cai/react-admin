import classNames from 'classnames'
import { View, Text, Checkbox } from '@tarojs/components'
import { styled } from 'linaria/react'

const StyledCheckbox = styled(View)`
  font-size: 0;
`

export default props => {
  const { className, ...others } = props
  return (
    <StyledCheckbox className="weui-cells_checkbox">
      <Checkbox className={classNames('weui-check', className)} {...others} />
      <Text className="weui-icon-checked"></Text>
    </StyledCheckbox>
  )
}

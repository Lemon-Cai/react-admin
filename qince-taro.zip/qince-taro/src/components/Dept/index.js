/*
 * @Author: CaiPeng
 * @Date: 2023-02-21 13:58:48
 * @LastEditors: caipeng
 * @LastEditTime: 2023-02-24 14:45:15
 * @FilePath: \qince-taro\src\components\Dept\index.js
 * @Description: 
 */
// import { useState } from 'react'
import Taro, { useDidShow } from '@tarojs/taro'

import { View } from '@tarojs/components'

export default ({
  onChange,
  value,
  menuId = '',
  queryParams = {},  // 接口入参
  children,
  className
}) => {

  useDidShow(() => {
    let data = Taro.getCurrentInstance()?.page?.data || ''
    if (data?.deptSelected) {
      onChange && onChange(data?.deptSelected || [])
      Taro.getCurrentInstance().page.data.deptSelected = ''
    }
  })

  const handleOpen = () => {
    Taro.navigateTo({
      title: '选择部门',
      url: `/pages/Components/Dept/index?menuId=${menuId}`,
      success: res => {
        res.eventChannel.emit('deptDatas', {
          value,
          queryParams,
        })
      }
    })
  }

  return (
    <View onClick={handleOpen} className={className}>
      <View>{children}</View>
    </View>
  )
}

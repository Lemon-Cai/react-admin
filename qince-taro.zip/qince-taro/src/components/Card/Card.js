import { View } from '@tarojs/components'
import classNames from 'classnames'

const Card = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('qince-card', className)} {...others}>
      {children}
    </View>
  )
}

export default Card

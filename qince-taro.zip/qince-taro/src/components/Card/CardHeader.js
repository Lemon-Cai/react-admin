import { View } from '@tarojs/components'
import classNames from 'classnames'

const CardHeader = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('qince-card-header', className)} {...others}>
      {children}
    </View>
  )
}

export default CardHeader

import { View } from '@tarojs/components'
import classNames from 'classnames'

const CardTitle = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('qince-card-title', className)} {...others}>
      {children}
    </View>
  )
}

export default CardTitle

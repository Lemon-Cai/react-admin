import './card.less'
import Card from './Card'
import CardHeader from './CardHeader'
import CardTitle from './CardTitle'
import CardBody from './CardBody'

export { Card, CardHeader, CardTitle, CardBody }

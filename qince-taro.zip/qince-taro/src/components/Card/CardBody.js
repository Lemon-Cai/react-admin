import { View } from '@tarojs/components'
import classNames from 'classnames'

const CardBody = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('qince-card-body', className)} {...others}>
      {children}
    </View>
  )
}

export default CardBody

import { View, Text } from '@tarojs/components'
import classNames from 'classnames'
import { pxTransform } from '@/utils'

export default props => {
  const {
    className = '',
    size = 0,
    value = 0,
    max = 5,
    margin = 5,
    readyOnly,
    onChange = () => {},
    ...others
  } = props

  const iconStyle = {
    marginRight: pxTransform(margin)
  }

  const starIconStyle = {
    fontSize: size ? `${size}px` : ''
  }

  // 生成星星颜色 className 数组，方便在jsx中直接map
  const classNameArr = []
  const floorValue = Math.floor(value)
  const ceilValue = Math.ceil(value)
  for (let i = 0; i < max; i++) {
    if (floorValue > i) {
      classNameArr.push('wq-rate-icon wq-rate-icon-on')
    } else if (ceilValue - 1 === i) {
      classNameArr.push('wq-rate-icon wq-rate-icon-half')
    } else {
      classNameArr.push('wq-rate-icon wq-rate-icon-off')
    }
  }

  const handleClick = i => {
    !readyOnly && onChange(i)
  }

  return (
    <View className={classNames('wq-rate', className)} {...others}>
      {classNameArr.map((cls, i) => (
        <View
          className={cls}
          key={`wq-rate-star-${i}`}
          style={iconStyle}
          onClick={() => handleClick(i + 1)}
        >
          <Text className="wq-icon wq-icon-star" style={starIconStyle}></Text>
          <View className="wq-rate-left">
            <Text className="wq-icon wq-icon-star" style={starIconStyle}></Text>
          </View>
        </View>
      ))}
    </View>
  )
}
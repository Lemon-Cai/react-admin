import classNames from 'classnames'
import { View, Image } from '@tarojs/components'
import { styled } from 'linaria/react'

const StyledGrid = styled(View)`
  &.qince-grid-no-border {
    &:before,
    &:after {
      display: none;
    }
  }
  .weui-grid__badge {
    position: absolute;
    top: 0;
    left: calc(50% + 12px);
  }
`

const GridItem = props => {
  const {
    className,
    icon,
    label,
    badge,
    column,
    hasBorder = true,
    style = {},
    children,
    ...others
  } = props

  return (
    <StyledGrid
      className={classNames(
        'weui-grid',
        {
          'qince-grid-no-border': !hasBorder
        },
        className
      )}
      style={{
        ...style,
        width: `${100 / column}%`
      }}
      {...others}
    >
      {icon && (
        <View className="weui-grid__icon">
          <Image src={icon} mode="scaleToFill" />
        </View>
      )}
      {label && <View className="weui-grid__label">{label}</View>}
      {badge && <View className="weui-grid__badge">{badge}</View>}
      {children}
    </StyledGrid>
  )
}

export default GridItem

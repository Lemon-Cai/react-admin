import React from 'react'
import classNames from 'classnames'
import { View } from '@tarojs/components'
import { styled } from 'linaria/react'

const StyledGrids = styled(View)`
  &.qince-grids-no-border {
    &:before, &:after {
      display: none;
    }
  }
`

const Grid = props => {
  const { className, column = 3, hasBorder, children, ...others } = props

  return (
    <StyledGrids className={classNames('weui-grids', {
      'qince-grids-no-border': !hasBorder
    }, className)} {...others}>
      {React.Children.map(children, child => {
        return React.cloneElement(child, { column, hasBorder })
      })}
    </StyledGrids>
  )
}

export default Grid

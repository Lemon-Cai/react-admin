import { View, Text } from '@tarojs/components'
import classNames from 'classnames'

const LoadMore = props => {
  const { className, showLoading = true, status = 0 } = props

  let view = null
  switch (status) {
    case 0:
      {
        view = <Text className="weui-loadmore__tips"></Text>
      }
      break
    case 1:
      {
        view = (
          <>
            {showLoading && (
              <Text className="weui-primary-loading">
                <Text className="weui-primary-loading__dot"></Text>
              </Text>
            )}
            <Text className="weui-loadmore__tips">加载中...</Text>
          </>
        )
      }
      break
    case 2: {
      view = <Text className="weui-loadmore__tips">暂无数据</Text>
    }
  }

  return (
    <View
      className={classNames(
        'weui-loadmore',
        {
          'weui-loadmore_line': !showLoading,
          'weui-loadmore_dot': !showLoading
        },
        className
      )}
    >
      {view}
    </View>
  )
}

export default LoadMore

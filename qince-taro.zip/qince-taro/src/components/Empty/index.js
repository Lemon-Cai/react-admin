import './index.less'
import Empty from './Empty'

export { Empty }

import { View, Textarea } from '@tarojs/components'
import classNames from 'classnames'
import { pxTransform } from '@/utils'

function getMaxLength(maxLength, textOverflowForbidden) {
  if (!textOverflowForbidden) {
    return maxLength + 500
  }
  return maxLength
}

export default props => {
  const {
    className,
    value,
    cursorSpacing,
    placeholder,
    placeholderStyle,
    placeholderClass,
    maxLength = 200,
    count,
    disabled,
    autoFocus,
    autoHeight,
    focus,
    showConfirmBar,
    selectionStart,
    selectionEnd,
    fixed,
    textOverflowForbidden = true,
    height,
    ...others
  } = props

  const handleInput = event => {
    props.onChange && props.onChange(event.detail.value, event)
  }

  const handleFocus = event => {
    props.onFocus && props.onFocus(event)
  }

  const handleBlur = event => {
    props.onBlur && props.onBlur(event)
  }

  const handleConfirm = event => {
    props.onConfirm && props.onConfirm(event)
  }

  const handleLineChange = event => {
    props.onLineChange && props.onLineChange(event)
  }

  return (
    <>
      <Textarea
        className={classNames('weui-textarea', className)}
        style={height ? `height:${height}px` : ''}
        placeholderStyle={placeholderStyle}
        placeholderClass={classNames('placeholder', placeholderClass)}
        cursorSpacing={cursorSpacing}
        value={value}
        maxLength={getMaxLength(maxLength, textOverflowForbidden)}
        placeholder={placeholder}
        disabled={disabled}
        autoFocus={autoFocus}
        autoHeight={autoHeight}
        focus={focus}
        showConfirmBar={showConfirmBar}
        selectionStart={selectionStart}
        selectionEnd={selectionEnd}
        fixed={fixed}
        onInput={handleInput}
        onFocus={handleFocus}
        onBlur={handleBlur}
        onConfirm={handleConfirm}
        onLineChange={handleLineChange}
        {...others}
      />
      {count && (
        <View className="weui-textarea-counter">
          {value.length}/{maxLength}
        </View>
      )}
    </>
  )
}

import classNames from 'classnames'

import { Cell, CellHeader, CellBody, CellFooter } from '@/components/Cell'
import { Flex } from '@/components/Flex'

export default props => {
  const { className, title, extra, layout = 'vertical', children, ...others } = props

  return (
    <Cell layout={layout} className={classNames('qince-list-item', className)} {...others}>
      <CellHeader>{title}</CellHeader>
      {layout === 'vertical' ? (
        <Flex style={{ width: '100%' }}>
          <CellBody>{children}</CellBody>
          <CellFooter>{extra}</CellFooter>
        </Flex>
      ) : (
        <>
          <CellBody>{children}</CellBody>
          <CellFooter>{extra}</CellFooter>
        </>
      )}
    </Cell>
  )
}

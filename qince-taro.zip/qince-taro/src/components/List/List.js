import classNames from 'classnames'

import { Cells } from '@/components/Cell'

export default props => {
  const { children, className, ...others } = props

  return (
    <Cells className={classNames('qince-list', className)} {...others}>
      {children}
    </Cells>
  )
}

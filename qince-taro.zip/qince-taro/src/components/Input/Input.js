import { useState } from 'react'
import { View, Input } from '@tarojs/components'
import { Icons } from '@/components/Icons'

export default props => {
  const {
    name,
    type,
    value,
    clear = true,
    placeholder,
    focus,
    password,
    showEye=false,
    compStyle,
    inputStyle,
    maxLength,
    onChange = () => {},
    onClick = () => {},
    onFocus = () => {},
    onBlur = () => {},
    onConfirm = () => {},
    onKeyboardHeightChange = () => {},
    ...others
  } = props

  const [oepnEye, setOpenEye] = useState(false)

  const handleInput = e => {
    e.target.id = name
    onChange && onChange(e.detail.value, e)
  }

  const handleFocus = e => {
    e.target.id = name
    onFocus && onFocus(e.detail.value, e)
  }

  const handleBlur = e => {
    e.target.id = name
    onBlur && onBlur(e.detail.value, e)
  }

  const handleClick = e => {
    e.target.id = name
    onClick && onClick(e)
  }

  const handleConfirm = e => {
    e.target.id = name
    onConfirm(e.detail.value, e)
  }

  const handleKeyboardHeightChange = e => {
    onKeyboardHeightChange && onKeyboardHeightChange(e)
  }

  const handleClear = () => {
    onChange('', {
      target: {
        id: name
      }
    })
  }

  return (
    <View className="wq-input" style={compStyle}>
      <Input
        style={inputStyle}
        name={name}
        value={value}
        focus={focus}
        password={oepnEye ? false : password}
        placeholder={placeholder}
        placeholderClass="wq-input-placeholder"
        onInput={handleInput}
        onFocus={handleFocus}
        onBlur={handleBlur}
        onClick={handleClick}
        onConfirm={handleConfirm}
        maxlength={maxLength}
        onKeyboardHeightChange={handleKeyboardHeightChange}
        {...others}
      />
      {clear && value && <Icons value="clear" color="#ccc" onClick={handleClear} style={{zIndex: 99, marginLeft: 8}} />}
      {password && showEye && <Icons className={oepnEye ? 'weui-icon-eye-open' : 'weui-icon-eye-close'} onClick={() => setOpenEye(!oepnEye)} style={{zIndex: 99, marginLeft: 10, marginRight: 5, color: '#ccc'}} /> }
    </View>
  )
}

import Taro from '@tarojs/taro'
import classNames from 'classnames'
import { Image, OpenData, Text, View } from '@tarojs/components'

export default props => {
  const { className, size = 'normal', circle, image, text = '', openData, style } = props

  let child
  if (openData && openData.type === 'userAvatarUrl' && Taro.getEnv() === Taro.ENV_TYPE.WEAPP) {
    child = <OpenData type={openData.type}></OpenData>
  } else if (image) {
    child = <Image className="qince-avatar-img" src={image} />
  } else {
    child = <Text className="qince-avatar-text">{text[0]}</Text>
  }

  return (
    <View
      className={classNames(
        'qince-avatar',
        {
          [`qince-avatar-${size}`]: size,
          'qince-avatar-circle': circle
        },
        className
      )}
      style={style}
      onClick={props.onClick}
    >
      {child}
    </View>
  )
}

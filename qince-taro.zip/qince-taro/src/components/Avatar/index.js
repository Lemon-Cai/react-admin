import './index.less'
import Avatar from './Avatar'

export { Avatar }
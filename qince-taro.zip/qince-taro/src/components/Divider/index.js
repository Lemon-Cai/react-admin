import './index.less'
import Divider from './Divider'

export { Divider }

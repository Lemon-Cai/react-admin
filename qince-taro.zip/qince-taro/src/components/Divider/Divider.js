import classNames from 'classnames'
import { View } from '@tarojs/components'

const Divider = props => {
  const { className, children } = props
  
  return <View className={classNames('qince-divider', className)}>{children}</View>
}

export default Divider

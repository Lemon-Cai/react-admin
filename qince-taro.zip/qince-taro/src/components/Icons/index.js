import './index.less'
import Icons from './Icons'

export { Icons }
import classNames from 'classnames'
import { Text } from '@tarojs/components'
import { mergeStyle, pxTransform } from '@/utils'

const Icons = props => {
  const { className, value, color = '', size = '', style, ...others } = props
  return (
    <Text
      className={classNames('qince-icon', [value ? `qince-icon-${value}` : ''], className)}
      style={mergeStyle(
        {
          fontSize: size ? `${pxTransform(parseInt(String(size)) * 2)}` : '',
          color
        },
        style
      )}
      {...others}
    ></Text>
  )
}

export default Icons

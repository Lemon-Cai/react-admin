import { View } from '@tarojs/components'
import classNames from 'classnames'

const CellHeader = props => {
  const { className, children, primary, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cell__hd': true,
        'weui-cell_primary': primary,
        [className]: className
      })}
      {...others}
    >
      {children}
    </View>
  )
}

export default CellHeader

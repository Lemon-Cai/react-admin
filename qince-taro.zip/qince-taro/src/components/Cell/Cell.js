import { View } from '@tarojs/components'
import classNames from 'classnames'

const Cell = props => {
  const { className, layout = 'horizontal', children, access, href, link, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cell': true,
        'weui-cell_access': access,
        'weui-cell_link': link,
        [className]: className
      }, `weui-cell-${layout}`)}
      href={href}
      {...others}
    >
      {children}
    </View>
  )
}

export default Cell

import { View } from '@tarojs/components'
import classNames from 'classnames'

export default props => {
  const { children, className, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cells': true,
        [className]: className
      })}
      {...others}
    >
      {children}
    </View>
  )
}

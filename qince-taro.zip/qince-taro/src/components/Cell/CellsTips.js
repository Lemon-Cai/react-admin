import { View } from '@tarojs/components'
import classNames from 'classnames'

const CellsTips = props => {
  const { className, children, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cells__tips': true,
        [className]: className
      })}
      {...others}
    >
      {children}
    </View>
  )
}

export default CellsTips

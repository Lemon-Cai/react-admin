import { View } from '@tarojs/components'
import classNames from 'classnames'

const CellFooter = props => {
  const { className, children, primary, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cell__ft': true,
        'weui-cell_primary': primary,
        [className]: className
      })}
      {...others}
    >
      {children}
    </View>
  )
}

export default CellFooter

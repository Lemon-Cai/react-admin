import { View } from '@tarojs/components'
import classNames from 'classnames'

const CellBody = props => {
  const { className, children, primary, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cell__bd': true,
        'weui-cell_primary': primary,
        [className]: className
      })}
      {...others}
    >
      {children}
    </View>
  )
}

export default CellBody

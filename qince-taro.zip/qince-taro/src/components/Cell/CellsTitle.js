import { View } from '@tarojs/components'
import classNames from 'classnames'

const CellsTitle = props => {
  const { className, children, ...others } = props

  return (
    <View
      className={classNames({
        'weui-cells__title': true,
        [className]: className
      })}
      {...others}
    >
      {children}
    </View>
  )
}

export default CellsTitle

import { View } from '@tarojs/components'
import classNames from 'classnames'

export default props => {
  const { className, extra = false, children, ...others } = props
  return (
    <View
      className={classNames(
        {
          'weui-media-box__info__meta': true,
          'weui-media-box__info__meta_extra': extra
        },
        className
      )}
      {...others}
    >
      {children}
    </View>
  )
}

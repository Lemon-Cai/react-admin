import { View } from '@tarojs/components'
import classNames from 'classnames'

export default props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('weui-media-box__desc', className)} {...others}>
      {children}
    </View>
  )
}

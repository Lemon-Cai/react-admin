import { View } from '@tarojs/components'
import classNames from 'classnames'
import { styled } from 'linaria/react'

const StyledView = styled(View)`
  width: auto;
  height: 100%;
  margin-right: 12px;
`

export default props => {
  const { className, children, ...others } = props
  return (
    <StyledView className={classNames('weui-media-box__checkbox', className)} {...others}>
      {children}
    </StyledView>
  )
}

import { View } from '@tarojs/components'
import classNames from 'classnames'

import MediaBoxInfoMeta from './MediaBoxInfoMeta'

export default props => {
  const { className, data = [], children, ...others } = props
  return (
    <View className={classNames('weui-media-box__info', className)} {...others}>
      {data.length > 0
        ? data.map((meta, i) => {
            return (
              <MediaBoxInfoMeta key={i} extra={meta.extra}>
                {meta.label}
              </MediaBoxInfoMeta>
            )
          })
        : children}
    </View>
  )
}

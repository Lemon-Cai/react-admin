import { View } from '@tarojs/components'
import classNames from 'classnames'

const FlexItem = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('weui-flex__item', className)} {...others}>
      {children}
    </View>
  )
}

export default FlexItem

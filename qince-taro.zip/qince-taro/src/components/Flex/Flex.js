import { View } from '@tarojs/components'
import classNames from 'classnames'

const Flex = props => {
  const { className, children, ...others } = props
  return (
    <View className={classNames('weui-flex', className)} {...others}>
      {children}
    </View>
  )
}

export default Flex

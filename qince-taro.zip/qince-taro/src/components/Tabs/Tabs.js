import Taro from '@tarojs/taro'
import classNames from 'classnames'
import { useRef, useState, useEffect } from 'react'
import { View, ScrollView } from '@tarojs/components'
import { uuid, mergeStyle } from '@/utils'

const ENV = Taro.getEnv()
const MIN_DISTANCE = 100
const MAX_INTERVAL = 10

const Tabs = props => {
  const {
    customStyle = '',
    className = '',
    tabDirection = 'horizontal',
    height = '',
    current = 0,
    swipeable = true,
    scroll = false,
    animated = true,
    header = true,
    fixed = false,
    tabList = [],
    onClick = () => {},
    children
  } = props

  const [state, setState] = useState({
    _scrollLeft: 0,
    _scrollTop: 0,
    _scrollIntoView: ''
  })

  useEffect(() => {
    console.log(current)
  }, [current])

  const _tabId = useRef(uuid())
  // 触摸时的原点
  const _touchDot = useRef(0)
  // 定时器
  const _timer = useRef(null)
  // 滑动时间间隔
  const _interval = useRef(0)
  // 是否已经在滑动
  const _isMoving = useRef(false)

  const scrollX = tabDirection === 'horizontal'
  const scrollY = tabDirection === 'vertical'
  const heightStyle = { height }
  const underlineStyle = {
    height: tabDirection === 'vertical' ? `${tabList.length * 100}%` : '1px',
    width: tabDirection === 'horizontal' ? `${tabList.length * 100}%` : '1px'
  }
  const bodyStyle = {}
  let transformStyle = `translate3d(0px, -${current * 100}%, 0px)`
  if (tabDirection === 'horizontal') {
    transformStyle = `translate3d(-${current * 100}%, 0px, 0px)`
  }
  Object.assign(bodyStyle, {
    transform: transformStyle,
    '-webkit-transform': transformStyle
  })
  if (!animated) {
    bodyStyle.transition = 'unset'
  }

  const handleClick = (index, e) => {
    onClick(index, e)
  }

  const _handleTouchStart = e => {
    if (!swipeable || tabDirection === 'vertical') return
    // 获取触摸时的原点
    _touchDot.current = e.touches[0].pageX
    // 使用js计时器记录时间
    _timer.current = setInterval(() => {
      _interval.current++
    }, 100)
  }

  const _handleTouchMove = e => {
    if (!swipeable || tabDirection === 'vertical') return
    const touchMove = e.touches[0].pageX
    const moveDistance = touchMove - _touchDot.current
    const maxIndex = tabList.length
    if (!_isMoving.current && _interval.current < MAX_INTERVAL && _touchDot.current > 20) {
      // 向左滑动
      if (current + 1 < maxIndex && moveDistance <= -MIN_DISTANCE) {
        _isMoving.current = true
        handleClick(current + 1, e)
        // 向右滑动
      } else if (current - 1 >= 0 && moveDistance >= MIN_DISTANCE) {
        _isMoving.current = true
        handleClick(current - 1, e)
      }
    }
  }

  const _handleTouchEnd = () => {
    if (!swipeable || tabDirection === 'vertical') return
    clearInterval(_timer.current)
    _interval.current = 0
    _isMoving.current = false
  }

  const tabItems = tabList.map((item, index) => {
    const itemClass = classNames({
      'qince-tabs-item': true,
      'qince-tabs-item-active': current === index
    })
    return (
      <View
        className={itemClass}
        id={`tab${index}`}
        key={item.title}
        onClick={e => handleClick(index, e)}
      >
        {item.title}
        <View className="qince-tabs-item-underline"></View>
      </View>
    )
  })

  return (
    <View
      className={classNames(
        {
          'qince-tabs': true,
          'qince-tabs-scroll': scroll,
          [`qince-tabs-${tabDirection}`]: true,
          'qince-tabs-fixed': fixed,
          [`qince-tabs-${ENV}`]: true
        },
        className
      )}
      style={mergeStyle(heightStyle, customStyle)}
    >
      {header &&
        (scroll ? (
          <ScrollView
            ref={_tabId}
            className="qince-tabs-header"
            style={heightStyle}
            scrollX={scrollX}
            scrollY={scrollY}
            scrollWithAnimation
            scrollLeft={state._scrollLeft}
            scrollTop={state._scrollTop}
            scrollIntoView={state._scrollIntoView}
          >
            {tabItems}
          </ScrollView>
        ) : (
          <View ref={_tabId} className="qince-tabs-header">
            {tabItems}
          </View>
        ))}
      {children && (
        <View
          className="qince-tabs-body"
          onTouchStart={_handleTouchStart}
          onTouchEnd={_handleTouchEnd}
          onTouchMove={_handleTouchMove}
          style={mergeStyle(bodyStyle, heightStyle)}
        >
          {/* <View className='qince-tabs-underline' style={underlineStyle}></View> */}
          {children}
        </View>
      )}
    </View>
  )
}

export default Tabs

import './tabs.less'
import Tabs from './Tabs'
import TabsPanel from './TabsPanel'

export { Tabs, TabsPanel }

import { View } from '@tarojs/components'
import classNames from 'classnames'

const TabsPanel = props => {
  const {
    className = '',
    tabDirection = 'horizontal',
    index = 0,
    current = 0,
    children,
    ...others
  } = props

  return (
    <View
      className={classNames(
        {
          'qince-tabs-panel': true,
          'qince-tabs-panel-vertical': tabDirection === 'vertical',
          'qince-tabs-panel-active': index === current,
          'qince-tabs-panel-inactive': index !== current
        },
        className
      )}
      {...others}
    >
      {children}
    </View>
  )
}

export default TabsPanel

import PhotosUpload from './PhotosUpload'
import uploadUtils from './uploadUtils'
import './index.less'


PhotosUpload.uploadUtils = uploadUtils

export default PhotosUpload
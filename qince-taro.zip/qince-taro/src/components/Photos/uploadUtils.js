import Taro from '@tarojs/taro'

export default {
  upload: function ({ sourceType, uploadDir }) {
    const that = this
    return new Promise(resolve => {
      Taro.chooseImage({
        count: 1,
        sourceType: sourceType || ['album', 'camera'],
        success: async res => {
          let files = res.tempFiles || []
          const file = files[0]

          const result = await that.handleUpload(file, { uploadDir })

          if (result.code === '1' && result.data.length ) {
            resolve({...result.data?.[0], pic: result.data?.[0]?.url})
          } else {
            resolve('')
          }
        },
        fail: function(e) {
          console.log('chooseImage fail', e)
        }
      })
    })
  },
  handleUpload: async (file, { uploadDir }) => {
    return new Promise(resolve => {
      Taro.uploadFile({
        url: `${Taro.getStorageSync(
          'appsvrUrl'
        )}/platform/fileupload/v1/doUpload.do?uploadPath=${uploadDir}`,
        filePath: file.path,
        name: 'file',
        withCredentials: true,
        formData: {
          file: file.path
        },
        header: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${Taro.getStorageSync('qince-token')}` // 上传需要单独处理cookie
        },
        success(result) {
          if (result.statusCode === 200) {
            resolve(JSON.parse(result.data))
          }
        },
        fail(e) {
          console.log('uploadFile fail:', e)
          // resolve({e, domain: Taro.getStorageSync('appsvrUrl')})
        }
      })
    })
  }
}

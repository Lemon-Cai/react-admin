import { useRef, useState, useEffect } from 'react'
import classNames from 'classnames'
import { useReady, vibrateShort, createSelectorQuery } from '@tarojs/taro'
import { View, ScrollView } from '@tarojs/components'
import { execSelectQuery } from '@/utils'

import { Cells, Cell, CellHeader, CellBody, CellFooter } from '@/components/Cell'
import { Icons } from '@/components/Icons'

const Drag = props => {
  const [state, setState] = useState({
    current: 0,
    transformIndex: -1,
    translateX: 0,
    translateY: 0,
    data: [],
    scrollTop: 0
  })

  const { current: _baseData } = useRef({
    distanceX: 0,
    distanceY: 0,
    identifier: -1,
    itemHeight: 0,
    itemWidth: 0,
    isDragging: false,
    previousMove: '',
    windowHeight: 600,
    // scroll view
    left: 0,
    top: 0,
    bottom: 0,
    scrollTop: -1 // -1 un-init
  })

  const wrapHeight = Math.ceil(props.data.length / props.columns) * props.itemHeight
  const getOffsetX = index => index % props.columns
  const getOffsetY = index => Math.floor(index / props.columns)
  const getIndex = (x, y) => x + props.columns * y

  const sort = (sourceIndex, targetIndex) => {
    const renderPosition = list => {
      const data = list.map(item => {
        item.tranX = `${getOffsetX(item.sortIndex) * 100}%`
        item.tranY = `${getOffsetY(item.sortIndex) * 100}%`
        return item
      })
      setState({ ...state, data })
    }

    const excludeFixed = (sortKey, reversed) => {
      if (state.data[sortKey].fixed) {
        reversed ? --sortKey : ++sortKey
        return excludeFixed(sortKey, reversed)
      }
      return sortKey
    }

    // 节流
    const move = `${sourceIndex}-${targetIndex}`
    if (move === _baseData.previousMove) return
    _baseData.previousMove = move

    if (sourceIndex < targetIndex) {
      // 正序拖动
      const list = state.data.map(item => {
        if (item.fixed) return item
        if (item.sortIndex > sourceIndex && item.sortIndex <= targetIndex) {
          item.sortIndex = excludeFixed(item.sortIndex - 1, true)
        } else if (item.sortIndex === sourceIndex) {
          item.sortIndex = targetIndex
        }
        return item
      })
      renderPosition(list)
    } else if (sourceIndex > targetIndex) {
      // 倒序拖动
      const list = state.data.map(item => {
        if (item.fixed) return item
        if (item.sortIndex >= targetIndex && item.sortIndex < sourceIndex) {
          item.sortIndex = excludeFixed(item.sortIndex + 1, false)
        } else if (item.sortIndex === sourceIndex) {
          item.sortIndex = targetIndex
        }
        return item
      })
      renderPosition(list)
    }
  }

  const onDragStart = (event, originIndex) => {
    if (_baseData.scrollTop === -1) return // 还未获取到 scrollTop
    const iTouch = event.touches[0]
    if (!iTouch) return
    const realIndex = state.data[originIndex].sortIndex
    // 初始项是固定项则返回
    if (state.data[originIndex].fixed) return
    // 如果已经在 drag 中则返回, 防止多指触发 drag 动作, touchstart 事件中有效果
    if (_baseData.isDragging) return
    _baseData.isDragging = true

    const offsetX = getOffsetX(realIndex) * _baseData.itemWidth
    const offsetY = getOffsetY(realIndex) * _baseData.itemHeight
    _baseData.distanceX = iTouch.pageX - _baseData.left - offsetX
    _baseData.distanceY = iTouch.pageY - _baseData.top - offsetY
    _baseData.identifier = iTouch.identifier

    setState({
      ...state,
      current: originIndex,
      translateX: props.columns === 1 ? 0 : offsetX,
      translateY: offsetY
    })

    if (props.vibrate) vibrateShort({ type: 'light' })
    props.onDragStart?.(event)
  }

  const onTouchStart = (event, index) => {
    execSelectQuery(
      createSelectorQuery()
        .select(`#${props.id}`)
        .scrollOffset()
    ).then(res => {
      _baseData.scrollTop = res.scrollTop
      onDragStart(event, index)
    })
  }

  const onTouchMove = event => {
    event.stopPropagation()
    event.preventDefault()
    if (!_baseData.isDragging) return
    const iTouch = event.touches[0]
    if (!iTouch) return

    // 如果不是同一个触发点则返回
    if (_baseData.identifier !== iTouch.identifier) return

    // 到顶到底自动滑动
    const offsetTop = _baseData.distanceY + _baseData.scrollTop
    const toBottom = iTouch.clientY - offsetTop + _baseData.itemHeight - _baseData.bottom
    const nextState = { ...state }
    if (toBottom > 0) {
      nextState.scrollTop = _baseData.scrollTop + toBottom
    } else {
      const toTop = iTouch.clientY - offsetTop - _baseData.top
      if (toTop < 0) {
        nextState.scrollTop = _baseData.scrollTop + toTop
      }
    }

    const tranX = props.columns === 1 ? 0 : iTouch.pageX - _baseData.left - _baseData.distanceX
    const tranY = iTouch.pageY - _baseData.top - _baseData.distanceY

    nextState.translateX = tranX
    nextState.translateY = tranY
    setState(nextState)

    const currentItem = state.data[state.current]
    const sourceIndex = currentItem.sortIndex
    const curX = Math.round(tranX / _baseData.itemWidth)
    const curY = Math.round(tranY / _baseData.itemHeight)
    const targetIndex = getIndex(curX, curY)

    // 目标项是固定项则返回
    const targetItem = state.data[targetIndex]
    if (targetItem && targetItem.fixed) return

    if (targetIndex > -1 && targetIndex < state.data.length) {
      sort(sourceIndex, targetIndex)
    }
  }

  const reset = () => {
    _baseData.previousMove = ''
    _baseData.isDragging = false
    _baseData.scrollTop = -1
    setState({ ...state, current: -1 })
  }

  const onTouchEnd = event => {
    props.onDragEnd?.(event)
    reset()
    const hasChanged = state.data.some(v => v.index !== v.sortIndex)
    if (hasChanged) {
      const data = state.data.map(item => ({
        ...item,
        index: item.sortIndex
      }))
      state.data = [...data]
      props.onChange?.(data.sort((a, b) => a.index - b.index).map(i => ({ ...i.data })))
    }
  }

  const render = init => {
    if (init !== 'init') {
      reset()
    }
    const data = (props.data || []).map((item, index) => ({
      data: item,
      fixed: item.fixed || false,
      index,
      sortIndex: index,
      tranX: `${getOffsetX(index) * 100}%`,
      tranY: `${getOffsetY(index) * 100}%`
    }))

    setState({ ...state, data })

    // 需要等到页面重排 再获取相应的尺寸
    setTimeout(async () => {
      const [container, item] = await Promise.all([
        execSelectQuery(
          createSelectorQuery()
            .select(`#${props.id}`)
            .boundingClientRect()
        ),
        execSelectQuery(
          createSelectorQuery()
            .select(`#${props.id} .qince-drag-item`)
            .boundingClientRect()
        )
      ])
      _baseData.itemWidth = item.width
      _baseData.itemHeight = item.height
      _baseData.left = container.left
      _baseData.top = container.top
      _baseData.bottom = container.bottom
    }, 100)
  }

  useReady(() => {
    render('init')
  })

  useEffect(render, [props.itemHeight, props.columns, props.data]) // eslint-disable-line

  const handleClickBody = () => {
    setState(prevState => ({ ...prevState, transformIndex: -1 }))
  }

  // 删除操作
  const handleClickDelete = (e, index, item) => {
    e.stopPropagation()
    props?.onClick?.(props?.type, index, item)
    handleClickBody()
  }

  // 渲染图标
  const renderIcon = (index, item) => {
    if (props?.type === 'delete') {
      return state.data?.length > 1 ? (
        <Icons
          value="minus-circle-fill"
          style={{ color: '#fa5151', fontSize: '24px', marginRight: '8px' }}
          onClick={e => {
            e.stopPropagation()
            setState(prevState => ({ ...prevState, transformIndex: index }))
          }}
        />
      ) : (
        <View style={{ width: '24px', marginRight: '8px' }}></View>
      )
    } else if (props?.type === 'add') {
      return (
        <Icons
          value="plus-circle-fill"
          style={{ color: '#69ce82', fontSize: '24px', marginRight: '8px' }}
          onClick={e => {
            e.stopPropagation()
            props?.onClick?.(props?.type, index, item)
          }}
        />
      )
    }
  }

  return (
    <ScrollView
      id={props.id}
      className={classNames(props.className, 'qince-drag-scroll')}
      style={props.style}
      scrollY
      scrollTop={state.scrollTop}
    >
      <Cells className="qince-drag" style={{ height: `${wrapHeight}px` }}>
        {state.data.map((item, index) => (
          <Cell
            key={index}
            className={classNames('weui-cell_swiped', {
              'qince-drag-item': true,
              'qince-drag-item-upper': item.index === state.current,
              'qince-drag-item-transition': props.transition && item.index !== state.current
            })}
            style={{
              width: `${100 / props.columns}%`,
              height: `${props.itemHeight}px`,
              transform:
                item.index === state.current
                  ? `translateX(${state.translateX}px) translateY(${state.translateY}px)`
                  : `translateX(${item.tranX}) translateY(${item.tranY})`
            }}
          >
            <CellBody
              onClick={handleClickBody}
              style={state.transformIndex === index ? { transform: 'translateX(-68px)' } : {}}
            >
              <Cell style={{ height: `${props.itemHeight}px` }}>
                {props?.type && <CellHeader>{renderIcon(index, item)}</CellHeader>}
                <CellBody>{item?.data?.name ?? ''}</CellBody>
                {props?.draggable && (
                  <CellFooter>
                    <View
                      catchMove
                      onTouchStart={e => onTouchStart(e, index)}
                      onTouchMove={onTouchMove}
                      onTouchEnd={onTouchEnd}
                    >
                      <Icons value="menu" />
                    </View>
                  </CellFooter>
                )}
              </Cell>
            </CellBody>
            <CellFooter>
              <View
                className="weui-swiped-btn weui-swiped-btn_warn"
                onClick={e => {
                  handleClickDelete(e, index, item)
                }}
              >
                删除
              </View>
            </CellFooter>
          </Cell>
        ))}
      </Cells>
    </ScrollView>
  )
}

Drag.defaultProps = {
  data: [],
  id: 'fish-drag-scroll',
  columns: 1,
  itemHeight: 64,
  vibrate: false,
  transition: false
}

export default Drag

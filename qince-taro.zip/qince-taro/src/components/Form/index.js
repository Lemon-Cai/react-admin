import './form.less'
import Form from './Form'
import FormItem from './FormItem'

export { Form, FormItem }

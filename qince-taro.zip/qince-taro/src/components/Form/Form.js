import React from 'react'
import classNames from 'classnames'
import { Form, View } from '@tarojs/components'

import { List } from '@/components/List'

export default props => {
  const {
    className,
    layout = 'vertical', // 'vertical' | 'horizontal'
    footer,
    children,
    ...others
  } = props

  return (
    <Form className={classNames('qince-form', `qince-form-${layout}`, className)} {...others}>
      <List>
        {React.Children.map(children, child => {
          return child ? React.cloneElement(child, {
            layout
          }) : child
        })}
      </List>
      {footer && <View className="qince-form-footer">{footer}</View>}
    </Form>
  )
}

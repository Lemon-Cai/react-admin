import classNames from 'classnames'

import { ListItem } from '@/components/List'

export default props => {
  const { className, children, ...others } = props

  return (
    <ListItem className={classNames('qince-form-item', className)} {...others}>
      {children}
    </ListItem>
  )
}

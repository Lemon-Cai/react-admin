export default defineAppConfig({
  pages: [
    'pages/Login/index',
    'pages/Login/forgot',
    'pages/Login/select',
    'pages/Login/setPassword',
    'pages/Home/index',
    'pages/Home/Assistant/Blog/index',
    'pages/Home/Commonly/Functions/index', 
    'pages/Home/Commonly/Others/index', 
    'pages/Home/Setting/index', 
    'pages/Home/NoticePupop/ViewTxt/index', 
    'pages/Blog/index', 
    'pages/Blog/AttentionList/index', 
    'pages/Blog/BlogTypes/index',
    'pages/Blog/Daily/index',
    'pages/Blog/Edit/index',
    'pages/Blog/Search/index',
    'pages/Blog/Detail/index',
    'pages/Blog/Person/index',
    'pages/Report/index',
    'pages/Mine/index',
    'pages/external/login',
    'pages/Components/Employee/index',
    'pages/Components/Dept/index'
  ],
  permission: {
    'scope.userLocation': {
      desc: '你的位置信息将用于小程序位置接口的效果展示'
    }
  },
  // 需要获取的权限 https://developers.weixin.qq.com/miniprogram/dev/reference/configuration/app.html#requiredBackgroundModes
  requiredPrivateInfos: ['getLocation'],
  subPackages: [
    {
      root: 'app/',
      pages: [
        'Webview/index',
        'Mine/ChangeAccount/index',
        'Mine/Logout/index',
        'Mine/ScanLogin/index',
        'Mine/UserInfo/index',
        'Mine/ModifyPassword/index',
        'Blog/DayBlogDetail/index',
        'Blog/VisitDetail/index',
        'Blog/Register/index',
      ]
    }
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: '勤策',
    navigationBarTextStyle: 'black'
  },
  tabBar: {
    color: '#808080',
    selectedColor: '#ff9008',
    backgroundColor: '#fff',
    borderStyle: 'black',
    list: [
      {
        pagePath: 'pages/Home/index',
        iconPath: './assets/images/icon/icon-workbench.png',
        selectedIconPath: './assets/images/icon/icon-workbench-on.png',
        text: '工作台'
      },
      {
        pagePath: 'pages/Blog/index',
        iconPath: './assets/images/icon/icon-feeds.png',
        selectedIconPath: './assets/images/icon/icon-feeds-on.png',
        text: '日报'
      },
      {
        pagePath: 'pages/Report/index',
        iconPath: './assets/images/icon/icon-report.png',
        selectedIconPath: './assets/images/icon/icon-report-on.png',
        text: '报表'
      },
      {
        pagePath: 'pages/Mine/index',
        iconPath: './assets/images/icon/icon-mine.png',
        selectedIconPath: './assets/images/icon/icon-mine-on.png',
        text: '我的'
      }
    ]
  },
  plugins: {
    captcha: {
      version: '1.0.4',
      provider: 'wxb302e0fc8ab232b4'
    }
  }
})

import Taro from '@tarojs/taro'
import _cloneDeep from 'lodash/cloneDeep'
import _findIndex from 'lodash/findIndex'

const CHANGE_STATE = 'BLOG/CHANGE_STATE'

const BLOG_TYPES = 'BLOG/BLOG_TYPES'
const BLOG_TYPES_SUCCESS = 'BLOG/BLOG_TYPES_SUCCESS'
const BLOG_TYPES_FAILURE = 'BLOG/BLOG_TYPES_FAILURE'

const BLOG_TYPE_INIT = 'BLOG/BLOG_TYPE_INIT'

const BLOG_INIT = 'BLOG/BLOG_INIT'

const BLOG_LIST = 'BLOG/BLOG_LIST'
const BLOG_LIST_SUCCESS = 'BLOG/BLOG_LIST_SUCCESS'
const BLOG_LIST_FAILURE = 'BLOG/BLOG_LIST_FAILURE'

const BLOG_COMMENT_LIST = 'BLOG/BLOG_COMMENT_LIST'
const BLOG_COMMENT_LIST_SUCCESS = 'BLOG/BLOG_COMMENT_LIST_SUCCESS'
const BLOG_COMMENT_LIST_FAILURE = 'BLOG/BLOG_COMMENT_LIST_FAILURE'

const FETCH_ATTEND_LIST = 'BLOG/FETCH_ATTEND_LIST'
const FETCH_ATTEND_LIST_SUCCESS = 'BLOG/FETCH_ATTEND_LIST_SUCCESS'
const FETCH_ATTEND_LIST_FAILURE = 'BLOG/FETCH_ATTEND_LIST_FAILURE'


const SAVE_BLOG_COMMENT = 'BLOG/SAVE_BLOG_COMMENT'
const SAVE_BLOG_COMMENT_SUCCESS = 'BLOG/SAVE_BLOG_COMMENT_SUCCESS'
const SAVE_BLOG_COMMENT_FAILURE = 'BLOG/SAVE_BLOG_COMMENT_FAILURE'

const FETCH_BLOG_COMMENT_BY_ID = 'BLOG/FETCH_BLOG_COMMENT_BY_ID'
const FETCH_BLOG_COMMENT_BY_ID_SUCCESS = 'BLOG/FETCH_BLOG_COMMENT_BY_ID_SUCCESS'
const FETCH_BLOG_COMMENT_BY_ID_FAILURE = 'BLOG/FETCH_BLOG_COMMENT_BY_ID_FAILURE'

const UPDATE_USER_ATTENTION = 'BLOG/UPDATE_USER_ATTENTION'
const UPDATE_USER_ATTENTION_SUCCESS = 'BLOG/UPDATE_USER_ATTENTION_SUCCESS'
const UPDATE_USER_ATTENTION_FAILURE = 'BLOG/UPDATE_USER_ATTENTION_FAILURE'

const DEPLOY_RANGE_ENUM = [
  {
    key: '-1',
    default: true,
    label: '仅自己和领导可见',
    title: '仅自己和领导可见-你发表的日报和分享只有自己和您的领导才能看到'
  },
  {
    key: '1',
    label: '所在部门可见（包含下级部门）',
    display: '所在部门可见', // 展示的文本
    title: '所在部门可见-发表的日报和分享只有您所在的部门及下级部门才能看到'
  },
  {
    key: '0',
    label: '全公司可见',
    title: '全公司可见-发表的日报和分享全公司的人都能看到'
  }
]

const userInfo = Taro.getStorageSync('qince-loginInfo')?.userInfo

const INITIAL_STATE = {
  defaultTypes: [
    {
      id: '-1',
      name: '全部',
      title: '全部',
      type: '1',
      default: true
    },
    {
      id: '-2',
      name: '关注',
      title: '关注',
      type: '5',
      default: true
    },
    {
      id: '-3',
      name: '@我的',
      title: '@我的',
      type: '2',
      default: true
    },
    {
      id: '-4',
      name: '直属下级',
      title: '直属下级',
      type: '4',
      default: true
    },
    {
      id: '-5',
      name: '评论',
      title: '评论',
      type: '1',
      default: true
    },
    {
      id: '-6',
      name: '我自己的',
      title: '我自己的',
      type: '3'
    }
  ],
  blogTypes: [], // 日报类型集合
  focusBlogTypes: [], // 我关注的日报类型集合
  unFocusBolgType: [], // 未关注日报类型集合
  // 当前选中的tab页签
  activeIndex: Taro.getStorageSync('qince-blog-tabindex') || 0, 
  datas: [], // 各个页签的数据集合
  pages: {}, // 各个页签的数据集合
  currentPage: {}, // 当前页面分页信息

  notifyStatus: -1,

  loading: false, // 加载状态
  // hasMore: true, // 判断是否存在更多数据
  attentionList: [], // 关注列表
  attentionTotal: 0,
  showAttendanceList: false, // 显示关注列表

  hasAuth: true, // 是否有权限查看日报
  userId: userInfo?.userId,  // 当前登录用户
  userInfo: userInfo,

  // 新增日报选择的模板
  selectedTemplate: null,
  // 

  // 新增部分的redux 数据
  // 发布范围
  deployRangeEnum: [...DEPLOY_RANGE_ENUM],
  selectedDeploy: DEPLOY_RANGE_ENUM.find(o => o.default),
  selectedDeployKey: DEPLOY_RANGE_ENUM.find(o => o.default)?.key,

}

export default function blog(state = INITIAL_STATE, action) {
  switch (action.type) {
    case CHANGE_STATE: {
      return {
        ...state,
        ...action.params
      }
    }
    case BLOG_TYPES: {
      return {
        ...state
      }
    }
    case BLOG_TYPES_SUCCESS: {
      let result = action.result
      let defaultTypes = state.defaultTypes
      if (result.code === '1') {
        // 读取个人信息
        let hasChild = '0'
        let loginInfo = Taro.getStorageSync('qince-loginInfo')
        if (loginInfo) {
          if (loginInfo.userInfo) {
            hasChild = loginInfo.userInfo.has_child
          }
        }
        if (hasChild !== '1') {
          // 当前登录人无下级， 去掉直属下级 页签
          state.defaultTypes = defaultTypes.filter((item) => {
            return item.id !== '-4'
          })
        }
        let data = (result.data || []).map(item => ({ ...item, title: item.name }))
        if (data && data.length > 0) {
          // 所有日报页签
          state.blogTypes = [...state.defaultTypes, ...data]
        }
        let focusTypesCache = Taro.getStorageSync('blog-focus-types')
        if (focusTypesCache) {
          state.focusBlogTypes = focusTypesCache.filter(item => {
            return !!(
              state.blogTypes.find(type => {
                return item.id === type.id
              })
            )
          })
        } else {
          state.focusBlogTypes = state.defaultTypes.concat(
            data.filter(item => {
              return item.id === '1' || item.id === '4'
            })
          )
        }
        state.unFocusBolgType = state.blogTypes.filter(item => {
          return (
            state.focusBlogTypes.filter(type => {
              return item.id === type.id
            }).length === 0
          )
        })
        if (state.activeIndex >= state.focusBlogTypes.length) {
          state.activeIndex = 0
        }
      }
      return {
        ...state
      }
    }
    case BLOG_TYPES_FAILURE: {
      return {
        ...state
      }
    }
    case BLOG_TYPE_INIT: {
      let currentTab = state.focusBlogTypes[state.activeIndex]
      let currentPage = state.pages[`${currentTab.id}`]
      if ((currentPage && currentPage.scrollTop === 0) || !currentPage) {
        // 本地不存在缓存数据或存在数据且scrollTop为0时，重新加载数据
        return {
          ...state,
          pages: {
            ...state.pages,
            [`${currentTab.id}`]: {
              params: {
                blogTypes: currentTab.id > 0 ? currentTab.id : '',
                dataType: currentTab.id > 0 ? '1' : currentTab.type,
                lastTime: ''
              },
              list: [],
              scrollTop: 0,
              noData: false,
              hasMore: true,
              pageSize: 0,
            }
          }
        }
      }
      return {
        ...state
      }
    }
    case BLOG_INIT: {
      return {
        ...state
      }
    }
    case BLOG_LIST: {
      return {
        ...state,
        loading: true
      }
    }
    case BLOG_LIST_SUCCESS: {
      const { result, flag } = action
      // let focusBlogTypes = _cloneDeep(state.focusBlogTypes)
      // let currentTab = focusBlogTypes[state.activeIndex]
      let currentTab = state.focusBlogTypes[state.activeIndex]
      let currentPage = _cloneDeep(state.pages[`${currentTab.id}`])

      let auth = false
      let userId = ''  // 当前登录人
      if (result.code === '1') {
        // let blogs = result.data.blogs || []
        let permissions = (result.data?.permissions || '').split(',')
        auth = permissions.includes('VIEW')
        let hasAttendAuth = permissions.includes('ADD_ATTENTION')
        userId = result.data.login_id
        // 714 新增全量关注人员id集合
        let allAttention = result.data.blog_attentions || []
        let blogs = (result.data.blogs || []).map(item => ({
          ...item,
          hasAttendAuth: hasAttendAuth && userId !== item.publish_id && currentTab.id !== '-2', // 关注页签不显示
          // 新增字段
          hasAttend: allAttention.includes(item.publish_id)
        }))
        if (blogs.length > 0) {
          currentPage.params.lastTime = blogs[blogs.length - 1].publish_time
        }
        if (flag) {
          currentPage.list = (currentPage.list || []).concat(blogs)
        } else {
          if (currentPage.list?.length > 0 && blogs?.length > 0) {
            state.notifyStatus = _findIndex(blogs, { id: currentPage.list[0].id })
          } else {
            state.notifyStatus = -1
          }
          currentPage.list = blogs
        }
        if (currentPage.list?.length === 0) {
          currentPage.noData = true
        } else {
          currentPage.noData = false
        }
        if (blogs?.length < (currentPage?.limit || 20)) {
          // 是否还存在数据
          currentPage.hasMore = false
        }
      }
      return {
        ...state,
        loading: false,
        // focusBlogTypes: focusBlogTypes,
        currentPage: currentPage,
        pages: {
          ...state.pages,
          [`${currentTab.id}`]: currentPage
        },
        hasAuth: auth,
        userId,
        // pages: {
        //   ...state.pages,
        //   [`${currentTab.id}`]: {
        //     params: {
        //       blogTypes: currentTab.id > 0 ? currentTab.id : '',
        //       dataType: currentTab.id > 0 ? '1' : currentTab.type,
        //       lastTime: ''
        //     },
        //     list: [],
        //     scrollTop: 0,
        //     hasMore: true
        //   }
        // }
      }
    }
    case BLOG_LIST_FAILURE: {
      return {
        ...state,
        loading: false
      }
    }

    case BLOG_COMMENT_LIST: {
      return {
        ...state,
        loading: true
      }
    }

    case BLOG_COMMENT_LIST_SUCCESS: {
      const { result, flag } = action
      let currentTab = state.focusBlogTypes[state.activeIndex]
      let currentPage = _cloneDeep(state.pages[`${currentTab.id}`])

      if (result.code === '1') {
        let comments = result.data?.comments || []
        if (comments.length > 0) {
          currentPage.params.lastTime = comments[comments.length - 1].comment_time
        }

        if (flag) {
          currentPage.list = (currentPage.list || []).concat(comments)
        } else {
          currentPage.list = comments
        }
        if (currentPage.list?.length === 0) {
          currentPage.noData = true
        } else {
          currentPage.noData = false
        }
        if (comments?.length <= 0) {
          currentPage.hasMore = false
        } else {
          currentPage.hasMore = true
        }
        // if (comments?.length < (currentPage?.limit || 20)) {
        //   // 是否还存在数据
        //   currentPage.hasMore = false
        // }
      }
      return {
        ...state,
        currentPage: currentPage,
        pages: {
          ...state.pages,
          [`${currentTab.id}`]: currentPage
        },
        loading: false
      }
    }

    case BLOG_COMMENT_LIST_FAILURE: {
      return {
        ...state,
        loading: false
      }
    }

    case FETCH_ATTEND_LIST: {
      return {
        ...state,
        loading: true
      }
    }
    case FETCH_ATTEND_LIST_SUCCESS: {
      const { result, flag } = action
      if (result.code === '1') {
        let data = result.data?.attention || []
        if (flag === '1') {
          // 查询已关注列表
          state.attentionList = data.map((item) => {
            return {
              isFollowed: true,
              ...item
            }
          })
          state.attentionTotal = data.length
        } else if (flag === '0') {
          // 推荐关注列表
          state.attentionTotal === 0 // 已关注为0
          state.attentionList = data.map((item) => {
            return {
              isFollowed: false,
              ...item
            }
          })
        } else {
          state.attentionList = [...state.attentionList, ...data.map(v => ({...v, isFollowed: true}))]
        }
        
        // if (type === '1') {
        //   if (result.data.attention?.length > 0) {
        //     state.attentionList = result.data.attention || []
        //     state.showAttendanceList = true
        //   }
        // } else if (type === '0') {
        //   state.attentionList = result.data.attention || []
        // }
      }
      return {
        ...state,
        loading: false
      }
    }

    case UPDATE_USER_ATTENTION: {
      return {
        ...state,
        loading: true
      }
    }

    case UPDATE_USER_ATTENTION_SUCCESS: {
      const { result, id } = action
      if (result.code === '1') {
        state.attentionList = state.attentionList.map((item) => {
          return {
            ...item,
            isFollowed: item.id === id ? !item.isFollowed : item.isFollowed
          }
        })
      }
      return {
        ...state,
        loading: false
      }
    }
    case UPDATE_USER_ATTENTION_FAILURE: {
      return {
        ...state,
        loading: false
      }
    }
    default:
      return state
  }
}

/**
 * 修改日报内容
 * @param {*} params
 */
export const dispatchChangeState = params => ({ type: CHANGE_STATE, params })

/**
 * 获取日报类型列表
 */
export const dispatchBlogTypes = () => {
  return {
    types: [BLOG_TYPES, BLOG_TYPES_SUCCESS, BLOG_TYPES_FAILURE],
    promise: fetch =>
      fetch({
        url: '/app/blog/v8/getBlogType.action'
      })
  }
}

/**
 * 日报类型初始化
 * @param {*} params
 */
export const dispatchBlogTypeInit = params => ({ type: BLOG_TYPE_INIT, params })

/**
 * 日报页面初始化
 */
export const dispatchBlogInit = params => {
  return async (dispatch, getState) => {
    let state = _cloneDeep(getState().Blog)
    let currentTab = state.focusBlogTypes[params || state.activeIndex]
    if (currentTab) {
      let currentPage = state.pages[`${currentTab.id}`]
      if ((currentPage && currentPage.scrollTop === 0) || !currentPage) {
        // 本地不存在缓存数据或存在数据且scrollTop为0时，重新加载数据
        let currentParams = {
          params: {
            blogTypes: currentTab.id > 0 ? currentTab.id : '',
            dataType: currentTab.id > 0 ? '1' : currentTab.type,
            lastTime: ''
          },
          list: [],
          noData: false,
          hasMore: true,
          pageSize: 0,
          limit: 20,
          // 设置加载状态
          status: 1,
          scrollTop: 0
        }
        await dispatch({
          type: CHANGE_STATE,
          params: {
            currentPage: currentParams,
            pages: {
              ...state.pages,
              [`${currentTab.id}`]: currentParams
            }
          }
        })
        if (currentTab.id === '-5') {
          // 评论特殊处理
          await dispatch(dispatchBlogCommentList())
        }/*  else if (currentTab.id === '-2') {
          // 获取关注data
          // 从缓存中获取关注列表
          // let cache = Taro.getStorageSync(`blog-attendList-${state.userId}`)
          // if (cache) {
          //   // 缓存中存在关注列表，直接回显
          // }
          // 先获取关注的列表，如果为空，获取推荐关注列表
          let result = await dispatch(dispatchFetchAttendList('1'))
          if (result.code === '1') {
            if (result.data?.attention?.length === 0) {
              // 推荐关注列表
              await dispatch({
                type: CHANGE_STATE,
                params: {
                  attentionTotal: 0,
                  showAttendanceList: false
                }
              })
              await dispatch(dispatchFetchAttendList('0'))
            } else {
              // 获取日报列表
              await dispatch({
                type: CHANGE_STATE,
                params: {
                  attentionTotal: result.data?.attention?.length,
                  showAttendanceList: true
                }
              })
              await dispatch(dispatchBlogList())
            }
          }
        }  */
        else if (currentTab.id !== '-2') {
          // 除了我的关注
          await dispatch(dispatchBlogList())
        }
      } else {

      }
    }
  }
}

/**
 * 获取日报内容列表
 */
export const dispatchBlogList = (flag) => {
  return async (dispatch, getState) => {
    let state = _cloneDeep(getState().Blog)
    let currentTab = state.focusBlogTypes[state.activeIndex]
    let currentPage = state.currentPage
    let params = {
      // blogTypes: currentTab.id > 0 ? currentTab.id : '',
      // dataType: currentTab.id > 0 ? '1' : currentTab.type,
      // lastTime: flag ? currentTab.lastTime : '',
      // blogMenuId: '6778072811795709662',
      // request_type: 2,
      'params.blog_types': currentTab.id > 0 ? currentTab.id : '',
      'params.request_type':  2,
      'params.data_type': currentTab.id > 0 ? '1' : currentTab.type,
      'params.latest_time': flag ? currentPage.params?.lastTime : '',
      'params.blogMenuId': '6778072811795709662',
    }
    if (currentTab.id === '-2') {
      params = {
        'params.data_type': '5',
        'params.request_type': 2,
        'params.blogMenuId': '6778072811795709662'
      }
      if (flag) {
        params['params.latest_time'] = currentPage.params?.lastTime
      }
    }

    const response = await dispatch({
      types: [BLOG_LIST, BLOG_LIST_SUCCESS, BLOG_LIST_FAILURE],
      promise: fetch =>
        fetch({
          url: '/app/blog/v8/web/getBlogListInfo.action',
          params: params,
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }),
      flag: flag
    })
    // 重新读取一遍更新后的数据
    state = _cloneDeep(getState().Blog)
    currentPage = state.currentPage
    if (currentPage.list?.length > 0 && response?.data?.blogs?.length > 0) {
      setTimeout(() => {
          dispatch({
            type: CHANGE_STATE,
            params: {
              notifyStatus: -1,
            }
          })
      }, 1000)
    }

    return response
  }
}

/**
 * 获取评论内容列表
 */
export const dispatchBlogCommentList = (params = {}) => {
  return async (dispatch, getState) => {
    let state = _cloneDeep(getState().Blog)
    // let currentTab = state.focusBlogTypes[state.activeIndex]
    let currentPage = state.currentPage
    let con = {
      'request_type': '2',
      'flag': 1,
      'blogMenuId': '6778072811795709662',
      'hasComment': '0'
    }
    if (params.flag) {
      con['oldest_time'] = currentPage.params?.lastTime
    }
    return dispatch({
      types: [BLOG_COMMENT_LIST, BLOG_COMMENT_LIST_SUCCESS, BLOG_COMMENT_LIST_FAILURE],
      promise: fetch =>
        fetch({
          // url: '/app/blog/v8/web/getCommentListUpdate.action',
          url: '/app/blog/v8/getCommentListUpdate.do',
          params: con,
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }),
      flag: params.flag
    })
  }
}

/**
 * 获取关注列表数据
 * @param {*} params 
 * @returns 
 */
export const dispatchFetchAttendList = (type) => {
  return {
    types: [FETCH_ATTEND_LIST, FETCH_ATTEND_LIST_SUCCESS, FETCH_ATTEND_LIST_FAILURE],
    promise: fetch =>
      fetch({
        url: '/app/blog/v8/getMyBlogAttention.action',
        params: {
          'params.attention_type': type
        },
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }),
    flag: type
  }
}


export const dispatchSaveBlogComment = (params = {}) => {
  return {
    types: [SAVE_BLOG_COMMENT, SAVE_BLOG_COMMENT_SUCCESS, SAVE_BLOG_COMMENT_FAILURE],
    promise: fetch =>
      fetch({
        url: '/app/blog/v8/sendBlogComment.do',
        params: params,
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }),
  }
}

export const dispatchFetchBlogCommentById = (params = {}) => {
  return {
    types: [FETCH_BLOG_COMMENT_BY_ID, FETCH_BLOG_COMMENT_BY_ID_SUCCESS, FETCH_BLOG_COMMENT_BY_ID_FAILURE],
    promise: fetch =>
      fetch({
        url: '/app/blog/v8/web/getCommentsByInfoIds.action',
        params: params,
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }),
  }
}

export const dispatchUpdateUserAttention = (params = {}) => {
  return {
    types: [UPDATE_USER_ATTENTION, UPDATE_USER_ATTENTION_SUCCESS, UPDATE_USER_ATTENTION_FAILURE],
    promise: fetch =>
      fetch({
        url: '/app/blog/v8/updateBlogAttentionForEmployee.action',
        params: params,
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }),
      id: params['params.user_id']
  }
}
const EXTERAL_LOGIN = "EXTERNAL/EXTERAL_LOGIN"
const EXTERAL_LOGIN_SUCCESS = "EXTERNAL/EXTERAL_LOGIN_SUCCESS"
const EXTERAL_LOGIN_FAILURE = "EXTERNAL/EXTERAL_LOGIN_FAILURE"


const INITIAL_STATE = {
  loading: false, // 进度条
}

export default function reducer(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    default:
      return state
  }
}

export const dispatchExternalLogin = (params) => {
  return {
    types: [EXTERAL_LOGIN, EXTERAL_LOGIN_SUCCESS, EXTERAL_LOGIN_FAILURE],
    promise: fetch =>
      fetch({
        host: HOST, // eslint-disable-line
        url: '/weixin/mini/wxMiniVisitorLogin',
        params: params,
        showToast: !0
      })
  }
}



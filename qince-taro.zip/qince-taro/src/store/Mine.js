import Taro from "@tarojs/taro"

const CHANGE_STATE = "MINE/CHANGE_STATE"
const INIT = "MINE/INIT"

const INIT_INFO = "MINE/INIT_INFO"
const INIT_INFO_SUCCESS = "MINE/INIT_INFO_SUCCESS"
const INIT_INFO_FAILURE = "MINE/INIT_INFO_FAILURE"

const CHANGE_PASSWORD = "MINE/CHANGE_PASSWORD"
const CHANGE_PASSWORD_SUCCESS = "MINE/CHANGE_PASSWORD_SUCCESS"
const CHANGE_PASSWORD_FAILURE = "MINE/CHANGE_PASSWORD_FAILURE"

const LOUGOUT_ACCOUNT = "MINE/LOUGOUT_ACCOUNT" 
const LOUGOUT_ACCOUNT_SUCCESS = "MINE/LOUGOUT_ACCOUNT_SUCCESS"
const LOUGOUT_ACCOUNT_FAILURE = "MINE/LOUGOUT_ACCOUNT_FAILURE"

const SCAN_LOGIN = "MINE/SCAN_LOGIN" 
const SCAN_LOGIN_SUCCESS = "MINE/SCAN_LOGIN_SUCCESS"
const SCAN_LOGIN_FAILURE = "MINE/SCAN_LOGIN_FAILURE"

const SCAN_AUTH = "MINE/SCAN_AUTH" 
const SCAN_AUTH_SUCCESS = "MINE/SCAN_AUTH_SUCCESS"
const SCAN_AUTH_FAILURE = "MINE/SCAN_AUTH_FAILURE"


const TRANSFER_ADMIN = "MINE/TRANSFER_ADMIN" 
const TRANSFER_ADMIN_SUCCESS = "MINE/TRANSFER_ADMIN_SUCCESS"
const TRANSFER_ADMIN_FAILURE = "MINE/TRANSFER_ADMIN_FAILURE"

const GET_ACCOUNTS = "MINE/GET_ACCOUNTS" 
const GET_ACCOUNTS_SUCCESS = "MINE/GET_ACCOUNTS_SUCCESS"
const GET_ACCOUNTS_FAILURE = "MINE/GET_ACCOUNTS_FAILURE"

const SWITCH_ACCOUNT = "MINE/SWITCH_ACCOUNT" 
const SWITCH_ACCOUNT_SUCCESS = "MINE/SWITCH_ACCOUNT_SUCCESS"
const SWITCH_ACCOUNT_FAILURE = "MINE/SWITCH_ACCOUNT_FAILURE"

const INITIAL_STATE = {
  loading: false, // 进度条
  userInfo: null // 用户信息
}

export default function reducer(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case CHANGE_STATE: {
      return {
        ...state,
        ...action.params
      }
    }
    case INIT: {
      return {
        ...INITIAL_STATE
      }
    }

    case INIT_INFO: {
      return {
        ...state,
        loading: true
      }
    }
    case INIT_INFO_SUCCESS: {
      const result = action && action.result
      if (result.code === "1") {
        state = {
          ...state,
          loginTimes: 0,
          userInfo: result.data
        }
      } else {
        Taro.showToast({
          mask: true,
          title: result?.message || "获取用户信息失败，请稍后重试！",
          icon: "none"
        })
      }
      return {
        ...state,
        loading: false
      }
    }
    case INIT_INFO_FAILURE: {
      Taro.showToast({
        mask: true,
        title: action?.result?.message || "获取用户信息异常，请稍后重试！",
        icon: "none"
      })
      return {
        ...state,
        loading: false
      }
    }
    default:
      return state
  }
}

/**
 * 获取用户信息
 */
export const dispatchGetUserInfo = () => {
  return {
    types: [INIT_INFO, INIT_INFO_SUCCESS, INIT_INFO_FAILURE],
    promise: fetch =>
      fetch({
        url: "/platform/param/v1/getLoginUser.do"
      })
  }
}

export const dispatchChangePassword = params => {
  return {
    types: [CHANGE_PASSWORD, CHANGE_PASSWORD_SUCCESS, CHANGE_PASSWORD_FAILURE],
    promise: fetch =>
      fetch({
        url: "/platform/sm/pwdedit/update.action",
        params: params,
        header: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
  }
}
export const dispatchInitMine = () => ({type: INIT, params: {}})

export const dispatchLogout = params => {
  return {
    types: [LOUGOUT_ACCOUNT, LOUGOUT_ACCOUNT_SUCCESS, LOUGOUT_ACCOUNT_FAILURE],
    promise: fetch =>
      fetch({
        url: "/sysapp/logoutRecord/logoutApply.do",
        params: params
      })
  }
}

export const dispatchScanLogin = (params) => {
  return {
    types: [SCAN_LOGIN, SCAN_LOGIN_SUCCESS, SCAN_LOGIN_FAILURE],
    promise: fetch =>
      fetch({
        url: "/client/authQrCode.action",
        params: params,
        header: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
  }
}

export const dispatchScanAuth = (params) => {
  return {
    types: [SCAN_AUTH, SCAN_AUTH_SUCCESS, SCAN_AUTH_FAILURE],
    promise: fetch =>
      fetch({
        url: "/sysapp/org/openApiLimit/confirmCode.do",
        params: params,
        header: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
  }
}

export const dispatchTransferAdmin = (params) => {
  return {
    types: [TRANSFER_ADMIN, TRANSFER_ADMIN_SUCCESS, TRANSFER_ADMIN_FAILURE],
    promise: fetch =>
      fetch({
        url: "/platform/sm/appadmin/client/v1/transferAdmin.action",
        params: params,
        header: {
          'Content-type': 'application/x-www-form-urlencoded'
        }
      })
  }
}

export const dispatchAccountList = (params) => {
  return {
    types: [GET_ACCOUNTS, GET_ACCOUNTS_SUCCESS, GET_ACCOUNTS_FAILURE],
    promise: fetch =>
      fetch({
        url: "/sysapp/apaas/employee/queryPersonnelMultiAccount.do",
        params: params
      })
  }
}

export const dispatchSwitchAccount = (params) => {
  return {
    types: [SWITCH_ACCOUNT, SWITCH_ACCOUNT_SUCCESS, SWITCH_ACCOUNT_FAILURE],
    promise: fetch =>
      fetch({
        url: "/platform/portal/switchAccount.do",
        params: params
      })
  }
}


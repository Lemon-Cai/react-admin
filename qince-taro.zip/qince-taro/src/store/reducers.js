import { combineReducers } from 'redux'
import Login from './Login'
import Blog from './Blog'
import Mine from './Mine'
import Home from './Home'

export default combineReducers({
  Login,
  Blog,
  Mine,
  Home
})
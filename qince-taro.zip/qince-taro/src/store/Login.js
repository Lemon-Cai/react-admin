import Taro from '@tarojs/taro'
import Encrypt from '@/utils/Encrypt'

const CHANGE_STATE = 'LOGIN/CHANGE_STATE'

const CHECK_LOGIN = 'LOGIN/CHECK_LOGIN'
const CHECK_LOGIN_SUCCESS = 'LOGIN/CHECK_LOGIN_SUCCESS'
const CHECK_LOGIN_FAILURE = 'LOGIN/CHECK_LOGIN_FAILURE'

const PHONE_LOGIN = 'LOGIN/PHONE_LOGIN'
const PHONE_LOGIN_SUCCESS = 'LOGIN/PHONE_LOGIN_SUCCESS'
const PHONE_LOGIN_FAILURE = 'LOGIN/PHONE_LOGIN_FAILURE'

const LOGIN = 'LOGIN/LOGIN'
const LOGIN_SUCCESS = 'LOGIN/LOGIN_SUCCESS'
const LOGIN_FAILURE = 'LOGIN/LOGIN_FAILURE'

const SEND_VERIFY = 'LOGIN/SEND_VERIFY'
const SEND_VERIFY_SUCCESS = 'LOGIN/SEND_VERIFY_SUCCESS'
const SEND_VERIFY_FAILURE = 'LOGIN/SEND_VERIFY_FAILURE'

const FORGOT_PASSWORD = 'LOGIN/FORGOT_PASSWORD'
const FORGOT_PASSWORD_SUCCESS = 'LOGIN/FORGOT_PASSWORD_SUCCESS'
const FORGOT_PASSWORD_FAILURE = 'LOGIN/FORGOT_PASSWORD_FAILURE'

const MORE_ACCOUNT = 'LOGIN/MORE_ACCOUNT'
const MORE_ACCOUNT_SUCCESS = 'LOGIN/MORE_ACCOUNT_SUCCESS'
const MORE_ACCOUNT_FAILURE = 'LOGIN/MORE_ACCOUNT_FAILURE'

const SET_PASSWORD = 'LOGIN/SET_PASSWORD'
const SET_PASSWORD_SUCCESS = 'LOGIN/SET_PASSWORD_SUCCESS'
const SET_PASSWORD_FAILURE = 'LOGIN/SET_PASSWORD_FAILURE'

const INITIAL_STATE = {
  loading: false, // 进度条
  tenantCode: '', // 企业账号
  userName: '', // 个人账号
  password: '', // 密码
  isAgree: false, // 同意并阅读使用协议
  loginTimes: Taro.getStorageSync('loginTimes') || 0 // 登录次数
}

export default function reducer(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case CHANGE_STATE: {
      return {
        ...state,
        ...action.params
      }
    }
    case LOGIN: {
      Taro.showLoading({
        mask: true
      })
      return {
        ...state,
        loading: true
      }
    }
    case LOGIN_SUCCESS: {
      let result = action?.result
      let _loginTimes = state.loginTimes

      Taro.hideLoading()
      if (!result) {
        Taro.showToast({
          title: '请求超时，请稍后再试',
          icon: 'none',
          mask: true
        })
        _loginTimes += 1
      } else if (result?.code === '1') {
        _loginTimes = 0
        state.tenantCode = ''
        state.userName = ''
        state.password = ''

        // Taro.removeStorageSync('loginTimes')
        Taro.setStorageSync('appsvrUrl', result?.appsvrUrl || '')
        Taro.setStorageSync('openId', result?.openId || '')
        Taro.setStorageSync('qince-token', result?.token)

        Taro.switchTab({
          url: '/pages/Home/index'
        })
      } else {
        Taro.showModal({
          content: result?.message || '登录失败，请稍后重试',
          showCancel: false,
        })
        _loginTimes += 1
      }
      return {
        ...state,
        loginTimes: _loginTimes,
        loading: false
      }
    }
    case LOGIN_FAILURE: {
      Taro.removeStorageSync('qince-token')
      Taro.hideLoading()
      Taro.showToast({
        title: '服务异常，请稍后重试！',
        icon: 'none',
        mask: true
      })
      return {
        ...state,
        loading: false
      }
    }
    case PHONE_LOGIN: {
      Taro.showLoading({
        mask: true
      })
      return {
        ...state,
        loading: true
      }
    }
    case PHONE_LOGIN_SUCCESS: {
      Taro.hideLoading()
      let result = action.result
      if (result.code === '1') {
        state.tenantCode = ''
        state.userName = ''
        state.password = ''
        // Taro.removeStorageSync('loginTimes')
        Taro.setStorageSync('appsvrUrl', result?.data?.appsvr || '')
        Taro.setStorageSync('openId', result?.data?.openId || '')
        if (result.data?.multiAccountList?.length > 0) {
          Taro.navigateTo({
            url: 'select',
            success: function(res) {
              res?.eventChannel?.emit('accountList', { codeList: result.data?.multiAccountList })
            }
          })
        } else {
          Taro.setStorageSync('qince-token', result?.data?.token)
          Taro.switchTab({
            url: '/pages/Home/index'
          })
        }
      } else {
        Taro.showModal({
          content: result?.message || '微信快捷登录失败，请稍后重试',
          showCancel: false,
        })
      }
      return {
        ...state,
        loading: false
      }
    }
    case PHONE_LOGIN_FAILURE: {
      Taro.hideLoading()
      Taro.removeStorageSync('qince-token')
      Taro.showToast({
        mask: true,
        title: '服务器忙，请稍后重试！',
        icon: 'none'
      })
      return {
        ...state,
        loading: false
      }
    }
    case MORE_ACCOUNT: {
      Taro.showLoading({
        mask: true
      })
      return {
        ...state,
        loading: true
      }
    }
    case MORE_ACCOUNT_SUCCESS: {
      Taro.hideLoading()
      let result = action.result
      if (result.code === '1') {
        Taro.setStorageSync('qince-token', result?.data)
        Taro.switchTab({
          url: '/pages/Home/index'
        })
      } else {
        Taro.showToast({
          mask: true,
          title: result?.message || '登录失败，请稍后重试',
          icon: 'none'
        })
      }
      return {
        ...state,
        loading: false
      }
    }
    case MORE_ACCOUNT_FAILURE: {
      Taro.hideLoading()
      Taro.removeStorageSync('qince-token')
      Taro.showToast({
        mask: true,
        title: '服务器忙，请稍后重试！',
        icon: 'none'
      })
      return {
        ...state,
        loading: false
      }
    }

    case CHECK_LOGIN: {
      return {
        ...state,
        loading: true
      }
    }
    case CHECK_LOGIN_SUCCESS: {
      let result = action.result
      if (result.code === '1') {
        Taro.switchTab({
          url: '/pages/Home/index'
        })
      }
      return {
        ...state,
        loading: false
      }
    }
    case LOGIN_FAILURE: {
      Taro.removeStorageSync('qince-token')
      Taro.showToast({
        mask: true,
        title: '服务器忙，请稍后重试！',
        icon: 'none'
      })
      return {
        ...state,
        loading: false
      }
    }
    default:
      return state
  }
}

/**
 * 用户登录
 * @param {*} params
 */
export const dispatchLogin = () => {
  return async (dispatch, getState) => {
    const response = await Encrypt.getAsrPublicKey()
    if (response?.data?.code === '1') {
      let state = getState().Login
      if (!state.tenantCode) {
        Taro.showToast({
          mask: true,
          title: '请输入企业账号',
          icon: 'none'
        })
        return
      }
      if (!state.userName) {
        Taro.showToast({
          mask: true,
          title: '请输入个人账号',
          icon: 'none'
        })
        return
      }
      if (!state.password) {
        Taro.showToast({
          mask: true,
          title: '请输入密码',
          icon: 'none'
        })
        return
      }
      const { password } = Encrypt.rsaEncode(state.password, response?.data?.data || '')
      // 微信登录
      const { code } = await Taro.login()
      // 帐号信息
      const accountInfo = Taro.getAccountInfoSync()
      return dispatch({
        types: [LOGIN, LOGIN_SUCCESS, LOGIN_FAILURE],
        promise: fetch =>
          fetch({
            host: HOST, // eslint-disable-line
            url: '/weixin/mini/login',
            params: {
              password,
              tenantCode: state.tenantCode,
              userName: state.userName,
              appId: accountInfo.miniProgram.appId, // eslint-disable-line
              code
            }
          })
      })
    }
  }
}

/**
 * 检测token是否有效
 */
export const dispatchCheckLogin = params => {
  return {
    types: [CHECK_LOGIN, CHECK_LOGIN_SUCCESS, CHECK_LOGIN_FAILURE],
    promise: fetch =>
      fetch({
        url: `/login/loginByMiniprogram/checkToken.do?paramToken=${
          params?.token
        }&openId=${Taro.getStorageSync('openId') || ''}&userId=${params?.userId || ''}`
      })
  }
}
// 微信小程序快捷登录
export const dispatchPhoneLogin = params => {
  return {
    types: [PHONE_LOGIN, PHONE_LOGIN_SUCCESS, PHONE_LOGIN_FAILURE],
    promise: fetch =>
      fetch({
        host: HOST, // eslint-disable-line
        url: '/weixin/mini/loginByMobile',
        params: params,
        showToast: !0
      })
  }
}
// 找回密码  发送验证码
export const dispatchSendVerify = params => {
  return {
    types: [SEND_VERIFY, SEND_VERIFY_SUCCESS, SEND_VERIFY_FAILURE],
    promise: fetch =>
      fetch({
        url: '/platform/forget/checkMobile.do',
        params: params
      })
  }
}
// 修改密码
export const dispatchSubmitChangePassword = params => {
  return {
    types: [FORGOT_PASSWORD, FORGOT_PASSWORD_SUCCESS, FORGOT_PASSWORD_FAILURE],
    promise: fetch =>
      fetch({
        url: '/platform/forget/saveWebForgotPassword.do',
        params: params
      })
  }
}
// 多账号确认登陆
export const dispatchSubmitMoreAccount = params => {
  return {
    types: [MORE_ACCOUNT, MORE_ACCOUNT_SUCCESS, MORE_ACCOUNT_FAILURE],
    promise: fetch =>
      fetch({
        url: '/login/loginByMiniprogram/multiAccountLogin.do',
        params: params
      })
  }
}

// 重新设置密码  密码强度过低
export const dispatchSetPassword = params => {
  return {
    types: [SET_PASSWORD, SET_PASSWORD_SUCCESS, SET_PASSWORD_FAILURE],
    promise: fetch =>
      fetch({
        url: '/platform/sm/pwdedit/update.action',
        params: params,
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      })
  }
}

/**
 * 修改表单内容
 * @param {*} params
 */
export const dispatchChangeState = params => ({ type: CHANGE_STATE, params })

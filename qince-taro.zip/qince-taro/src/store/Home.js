import Taro from '@tarojs/taro'
import _cloneDeep from 'lodash/cloneDeep'

const INIT = 'HOME/INIT'
const CHANGE_STATE = 'HOME/CHANGE_STATE'

const CHANGE_SAFETY = 'HOME/CHANGE_SAFETY'
// const CHANGE_SAFETY_SUCCESS = 'HOME/CHANGE_SAFETY_SUCCESS'
// const CHANGE_SAFETY_FAIL = 'HOME/CHANGE_SAFETY_FAIL'

const HOME = 'HOME/CLIENTAUTH_INIT'
const HOME_SUCCESS = 'HOME/CLIENTAUTH_SUCCESS'
const HOME_FAILURE = 'HOME/CLIENTAUTH_FAILURE'

// 系统初始化
const FETCH_SYSTEM_INIT = `HOME/FETCH_SYSTEM_INIT`
const FETCH_SYSTEM_INIT_SUCCESS = `HOME/FETCH_SYSTEM_INIT_SUCCESS`
const FETCH_SYSTEM_INIT_FAILURE = `HOME/FETCH_SYSTEM_INIT_FAILURE`

// 获取勤奋度 以及 公告数据
const FETCH_DYNAMIC = `HOME/FETCH_DYNAMIC`
const FETCH_DYNAMIC_SUCCESS = `HOME/FETCH_DYNAMIC_SUCCESS`
const FETCH_DYNAMIC_FAILURE = `HOME/FETCH_DYNAMIC_FAILURE`

// // 读取系统参数
// const FETCH_SYSTEM_PARAMS = `HOME/FETCH_SYSTEM_PARAMS`
// const FETCH_SYSTEM_PARAMS_SUCCESS = `HOME/FETCH_SYSTEM_PARAMS_SUCCESS`
// const FETCH_SYSTEM_PARAMS_FAILURE = `HOME/FETCH_SYSTEM_PARAMS_FAILURE`

// // 读取系统参数
// const FETCH_USER_INFO = `HOME/FETCH_USER_INFO`
// const FETCH_USER_INFO_SUCCESS = `HOME/FETCH_USER_INFO_SUCCESS`
// const FETCH_USER_INFO_FAILURE = `HOME/FETCH_USER_INFO_FAILURE`

const INITIAL_STATE = {
  loading: false, // 加载状态,
  // 常用功能
  // 公告信息
  // bbsMessage: {},
  // 工作助手
  // userWorkhelper: [],
  // 页面全部数据
  userInfo: {},
  homeData: [],
  // 全部-功能菜单
  allMenuList: [],
  // 自定义工作台菜单
  usedMenuList: []
}

export default function home(state = INITIAL_STATE, action) {
  switch (action.type) {
    case INIT: {
      return {
        ...INITIAL_STATE
      }
    }
    case CHANGE_STATE: {
      return {
        ...state,
        ...action.params
      }
    }
    case CHANGE_SAFETY: {
      const stateClone = _cloneDeep(state)
      stateClone.userInfo.IsSatisfy = '1'

      return {
        ...stateClone
      }
    }
    case FETCH_SYSTEM_INIT: {
      // Taro.showLoading()
      return { ...state }
    }
    case FETCH_SYSTEM_INIT_SUCCESS: {
      let { result } = action
      let params = {}
      // Taro.hideLoading()
      if (result.code === '1') {
        const _menus = result.data?.menus || []
        function _arrTotree(arr, id) {
          let _arr = []
          arr.forEach(item => {
            if (item?.pid === id) {
              _arr.push({ ...item, menuList: _arrTotree(arr, item.id) })
            }
          })
          return _arr
        }

        // function _treeToArr(tree) {
        //   let arr = []
        //   for (let i = 0; i < tree?.length; i++) {
        //     const treeItem = tree[i]
        //     if (Array.isArray(treeItem?.menuList) && treeItem.menuList.length) {
        //       arr = arr.concat(_treeToArr(treeItem.menuList))
        //     } else {
        //       arr.push(treeItem)
        //     }
        //   }
        //   return arr
        // }

        // const menu_list = _arrTotree(_menus, '-1').map(item => {
        //   return { ...item, menuList: _treeToArr(item?.menuList || []) }
        // })

        params = {
          menus: _menus,
          userInfo: result.data?.baseinfo || {},
          app_param: result.data?.app_param || {},
          hasDepart: result.data?.depart_report || '',
          shortcut: result.data?.short_add || [],
          allMenuList: _arrTotree(_menus, '-1')
        }
        // cookie.set('userId', status.baseinfo.userId)
        Taro.setStorageSync('qince-loginInfo', params)
        // 缓存当前客户模式
        Taro.setStorageSync('qince-cm-mode', params.app_param?.cm?.cm_trade_type || '1')
      } else {
        params = {
          ...INITIAL_STATE
        }
      }
      return {
        ...state,
        ...params
      }
    }
    case FETCH_SYSTEM_INIT_FAILURE: {
      return { ...state }
    }
    case HOME: {
      Taro.showLoading({ title: '加载中...', mask: true })
      return { ...state }
    }
    case HOME_SUCCESS: {
      Taro.hideLoading()
      const { result = {} } = action
      const { data = [], message = '系统繁忙，请稍后再试！' } = result
      // 卡片类型 (卡片类型：1-工作助手，2-我的常用，3-客户跟进，4-数据上报，5-办公协作，6-获客， 7-DMS)
      // 全部功能
      // const allMenuList = []
      // 首页渲染card
      const usedMenuList = []
      Array(data) &&
        data.length &&
        data.forEach(item => {
          if (['1', '2'].includes(item?.icardType)) {
            usedMenuList.push(item)
          } else {
            // allMenuList.push(item)
          }
        })
      return {
        ...state,
        homeData: data,
        usedMenuList,
        message: message
        // allMenuList
      }
    }
    case HOME_FAILURE: {
      Taro.hideLoading()
      return { ...state }
    }
    default:
      return state
  }
}

// 初始化首页数据
export const dispatchInit = () => ({
  type: INIT,
  params: {}
})

/**
 * 修改Store
 * @param {*} params
 */
export const dispatchChangeState = params => ({ type: CHANGE_STATE, params })

/**
 * 获取主界面数据
 */
export const dispatchHome = params => {
  return {
    types: [HOME, HOME_SUCCESS, HOME_FAILURE],
    promise: fetch =>
      fetch({
        url: '/workbench/index.do',
        params: params,
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        }
      })
  }
}

// 获取勤奋度 以及 公告数据
export const dispatchDynamicData = params => {
  return {
    types: [FETCH_DYNAMIC, FETCH_DYNAMIC_SUCCESS, FETCH_DYNAMIC_FAILURE],
    promise: fetch =>
      fetch({
        url: '/client/v1/getMainDynamicData.do',
        params: params
        // header: {
        //   'content-type': 'application/x-www-form-urlencoded'
        // }
      })
  }
}

// 系统初始化
export const dispatchFetchSystemInit = () => {
  return {
    types: [FETCH_SYSTEM_INIT, FETCH_SYSTEM_INIT_SUCCESS, FETCH_SYSTEM_INIT_FAILURE],
    promise: fetch =>
      fetch({
        url: '/weixin/menu/getWeixinMenuInfo.do'
      })
  }
}

// 获取客户模式
export const dispatchFetchCustomerMode = () => {
  return {
    types: [],
    promise: fetch =>
      fetch({
        url: '/app/cm/weixin/cmUseDealerStoreV2.action'
      })
  }
}
export const changePasswordSatisfy = () => {
  return {
    type: CHANGE_SAFETY
  }
}

import { Component } from 'react'
import { Provider } from 'react-redux'

import configStore from './store'

import './app.less'

const store = configStore()

class App extends Component {
  componentDidMount() {
    console.log('componentDidMount')
  }

  componentDidShow() {
    // Taro.getNetworkType({
    // 	success: function (res) {
    // 		var networkType = res.networkType
    // 		if (networkType !== 'unknown' && networkType !== 'none') {
    // 			let form1 = Taro.getStorageSync('qince-form1')
    //       let form2 = Taro.getStorageSync('qince-form2')
    //       Taro.showToast({
    // 				title: `当前网络状态为：${networkType}，将上传本地缓存数据到服务器！`,
    // 				icon: 'none'
    // 			})
    //       setTimeout(() => {
    //         Taro.showToast({
    //           title: `form1数据：${JSON.stringify(form1)}，form2数据：${JSON.stringify(form2)}`,
    //           icon: 'none',
    //           duration: 4000
    //         })
    //       }, 3000)
    // 		} else {
    //       Taro.showToast({
    // 				title: '当前网络状态不好，不会执行上传操作',
    // 				icon: 'none',
    // 				duration: 2000
    // 			})
    // 		}
    // 	}
    // })
    // Taro.onNetworkStatusChange(res => {
    //   let networkType = res.networkType
    //   if (networkType !== 'unknown' && networkType !== 'none') {
    //     let form1 = Taro.getStorageSync('qince-form1')
    //     let form2 = Taro.getStorageSync('qince-form2')
    //     Taro.showToast({
    //       title: `网络改变，form1数据：${JSON.stringify(form1)}，form2数据：${JSON.stringify(form2)}`,
    //       icon: 'none',
    //       duration: 2000
    //     })
    //   }
    // })
  }

  componentDidHide() {
    console.log('componentDidHide')
  }

  // this.props.children 是将要会渲染的页面
  render() {
    return <Provider store={store}>{this.props.children}</Provider>
  }
 }

export default App

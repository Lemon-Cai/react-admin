import Taro, { getCurrentInstance, useDidShow } from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { WebView } from '@tarojs/components'

import { Page } from '@/components/Page'

const getURLParameters = url =>
  (url.match(/([^?=&]+)(=([^&]*))/g) || []).reduce(
    // eslint-disable-next-line
    (a, v) => ((a[v.slice(0, v.indexOf('='))] = v.slice(v.indexOf('=') + 1)), a),
    {}
);

export default () => {
  // 获取webview上title、url
  const [state, setState] = useState({
    title: '',
    url: ''
  })

  useDidShow(() => {
    handleData({
      message: null
    })
  })

  // 初始化
  useEffect(() => {
    const { router } = getCurrentInstance()
    const corpId = 'ww94b1f6c5820ebec9'
    const token = Taro.getStorageSync('qince-token')
    let url = decodeURIComponent(router.params.url || '')
    url = url.includes('?') ? `${url}&corpId=${corpId}&token=${token}&isFromApp=1` : `${url}?corpId=${corpId}&token=${token}&isFromApp=1`
    
    url = url.replace('/app/user_defined/v2/impl/gaea/form_showForm.action', '/sysapp/react/h5/superform.html#/add')

    const params = getURLParameters(url)
    if (params.funcId) {
      url = `${url}&functionId=${params.funcId}`
    }
    console.log(url, 'url')

    setState({
      title: decodeURIComponent(router.params.title || ''),
      url: url
    })
    Taro.setNavigationBarTitle({ title: decodeURIComponent(router.params.title || '') })
  }, []) // eslint-disable-line

  const handleData = (val) => {
    let pages = Taro.getCurrentPages()
    if (pages.length > 1) {
      let beforePage = pages[pages.length - 2]
      beforePage.setData(val)
    }
  }

  const handleMessage = (e) => {
    const { data } = e.detail
    if (Array.isArray(data)) {
      const messages = data.map(item => {
        try {
          const object = JSON.parse(item)
          return object
        } catch (error) {
          return item
        }
      })
      handleData({message: messages[0]})
    }
  }

  return (
    <Page>
      <WebView src={state.url} onMessage={handleMessage} />
    </Page>
  )
}

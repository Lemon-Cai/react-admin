/*
 * @Author: CaiPeng
 * @Date: 2022-10-27 14:35:47
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 17:02:36
 * @FilePath: \qince-taro\src\app\Blog\Register\index.js
 * @Description: 
 */
import Taro, { useReady } from '@tarojs/taro'
import { WebView } from '@tarojs/components'

import { useState } from 'react'

// 注册
const Register = function () {
  const [url, setUrl] = useState('')

  useReady(() => {
    const host = Taro.getStorageSync('appsvrUrl')
    setUrl(`${host.endsWith('/') ? host : (host + '/')}/auth/mobile/promotion.html?from=500012`)
  })


  return url && (
    <WebView src={url} />
  )
}

export default Register
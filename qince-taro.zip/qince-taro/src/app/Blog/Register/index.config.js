export default definePageConfig({
  navigationBarTitleText: '外勤365移动销售管理平台',
})
// @flow
import { Image, View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

const Img = styled(Image)`
  display: inline-block;
  width: 80px;
  height: 80px;
  /* background: url(${props => props.src}) no-repeat; */
  /* background-size: contain;
  background-position: center; */
  border: 1px solid #e0e0e0;
  margin-right: 5px;
`

export default function ImageView({ images = [] }) {
  return (
    <View>
      {images.map((img, index) => (
        <Img key={index} src={img} mode='aspectFit' />
      ))}
    </View>
  )
}

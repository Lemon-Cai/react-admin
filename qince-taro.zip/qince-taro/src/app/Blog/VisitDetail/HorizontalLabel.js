// @flow
import { Text, View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

const Root = styled(View)`
  background-color: #fff;
  padding-bottom: 10px;
  display: flex;
  align-items: center;
`

const Label = styled(View)`
  font-size: 12px;
  color: #666;
`

const StyledText = styled(Text)`
  font-size: 13px;
  color: #1a1a1a;
  flex: 1;
  display: flex;
  justify-content: ${props => props.align};
`

export default function HorizontalLabel({ label, value, align = 'flex-start' }) {
  return (
    <Root>
      <Label>{label}</Label>
      <StyledText align={align}>{value}</StyledText>
    </Root>
  )
}

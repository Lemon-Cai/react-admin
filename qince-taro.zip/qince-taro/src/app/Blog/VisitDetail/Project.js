// @flow
import { styled } from 'linaria/lib/react'
import { Text, View } from '@tarojs/components'

const Root = styled(View)`
  display: flex;
  align-items: center;
  position: relative;
  margin-bottom: ${props => (props.isLast ? '0' : '12px')};
`

const Point = styled(Text)`
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background-color: green;
  position: absolute;
  left: -3px;
`

const Content = styled(View)`
  padding: 8px;
  margin-left: 15px;
  font-size: 14px;
  color: #1a1a1a;
  border: 1px solid #e0e0e0;
  border-radius: 5px;
  position: relative;
  flex: 1;
  display: flex;
  align-items: center;
  &:before {
    position: absolute;
    content: '';
    width: 5px;
    height: 5px;
    background-color: #fff;
    border-top: 1px solid #e0e0e0;
    border-left: 1px solid #e0e0e0;
    transform: rotate(-45deg);
    left: -5px;
    top: 50%;
    margin-top: -3px;
  }
`

const Value = styled(View)`
  flex: 1;
`

const Time = styled(View)`
  font-size: 12px;
  color: #808080;
`

export default function Project({ value, time, isLast }) {
  return (
    <Root isLast={isLast}>
      <Point />
      <Content>
        <Value>{value}</Value>
        <Time>{time}</Time>
      </Content>
    </Root>
  )
}

/*
 * @Author: CaiPeng
 * @Date: 2023-03-21 20:11:27
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-23 09:39:48
 * @FilePath: \qince-taro\src\app\Blog\VisitDetail\index.js
 * @Description: 
 */
// @flow
import Taro, { useRouter } from '@tarojs/taro'
import { useState, useEffect } from 'react'

import { styled } from 'linaria/lib/react'
import { View } from '@tarojs/components'

import fetch from '@/utils/request'

import { Empty } from '@/components/Empty'
import { Page } from '@/components/Page'

import ImageList from '../components/ImageList'
import BackText from '../components/BackText'
import RegisterBar from '../components/RegisterBar'
import Project from './Project'
import VerticalLabel from './VerticalLabel'
import HorizontalLabel from './HorizontalLabel'

const Container = styled(View)`
  background-color: #fff;
  padding: 12px;
  margin-bottom: ${props => (props.noMargin ? '0' : '10px')};
  position: relative;
  overflow: hidden;
  &:before {
    top: 0;
    left: 0;
    display: inline-block;
    content: '';
    position: absolute;
    width: 100%;
    height: 1px;
    background-color: #e0e0e0;
    transform: scaleY(0.5);
  }
  &:after {
    bottom: 0;
    left: 0;
    display: inline-block;
    content: '';
    position: absolute;
    width: 100%;
    height: 1px;
    background-color: #e0e0e0;
    transform: scaleY(0.5);
  }
`

const DisLink = styled(View)`
  font-size: 10px;
  color: ${props => props.color};
  text-decoration: underline;
  padding-bottom: ${props => (props.hasBottom ? '10px' : '0')};
`

const Text = styled(View)`
  color: #808080;
  font-size: 12px;
`

const Content = styled(View)`
  font-size: 14px;
  color: #1a1a1a;
  padding-bottom: 10px;
`

const ListContainer = styled(View)`
  position: relative;
  margin-left: 10px;
`

const LeftLine = styled(View)`
  position: absolute;
  width: 1px;
  height: 1000px;
  left: 0;
  top: 20px;
  bottom: 0px;
  background-color: #e0e0e0;
`

export default function VisitDetail() {
  const router = useRouter()

  const [state, setState] = useState({
    customerName: '',
    visitName: '',
    visitUseTime: '',
    arriveTime: '',
    arriveOffset: 0,
    leaveTime: '',
    leaveOffset: 0,
    calcDistance: 2000,
    hasSummary: false,
    summary: '',
    summaryTime: '',
    summaryPics: [],
    projects: [],
    hasData: true,
    description: ''
  })

  useEffect(() => {
    // const params = getURLParameters(window.location.href)
    if (router?.params) {
      const { tenantid, visitid, visitor, content = '' } = router?.params
      _getVisitInfo(
        {
          'data.tenant_id': tenantid,
          'data.visit_id': visitid,
          'data.visitor': visitor
        },
        { description: decodeURIComponent(content) }
      )
    }

    return () => {}
  }, [])

  const _getVisitInfo = (params) => {
    fetch({
      url: '/app/customer_visit/shareWeixinData.action',
      params,
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }).then(response => {
      let functions = [];
      let rootUrl = '/';
      let visitData = null;
      let customerName = '';
      let visitName = '';
      let visitUseTime = '';
      let arriveTime = '';
      let arriveOffset = 0;
      let leaveTime = '';
      let leaveOffset = 0;
      let summary = '';
      let summaryTime = '';
      let pics = [];
      let hasSummary = false;
      let summaryPics = [];
      let projects = [];
      let hasData = !!response.data;
      let calcDistance = Number(response.cust_visit_position_distance) || 2000;  // 服务端传0时当2000处理
      functions = response.functions;
      rootUrl = response.root_url || '/';
      if (response.code === '1') {
        if (hasData) {
          visitData = response.data || {};
          customerName = visitData.customer_name || '';
          visitName = visitData.visitor_name || '';
          visitUseTime = visitData.time_consume || '';
          arriveTime = visitData.arrive_time || '';
          arriveOffset = Number(visitData.arrive_pos_offset);
          leaveTime = visitData.leave_time || '';
          leaveOffset = Number(visitData.leave_pos_offset);
          summary = visitData.summary || '';
          summaryTime = visitData.summary_time || '';
          pics = visitData.summary_pictures && visitData.summary_pictures.split(",").filter((pic) => pic !== '');
          hasSummary = !!summary || (pics && pics.length > 0);
          summaryPics = pics && pics.map((pic) => (
            rootUrl + pic
          ));
          projects = functions && functions.map((func) => (
            {
              name: func.function_name,
              time: func.submit_time
            }
          ));
        }
      } else {
        Taro.showToast({
          title: response.message || '数据加载异常',
          icon: null
        })
      }
      setState(prev => ({
        ...prev,
        hasData,
        customerName,
        visitName,
        visitUseTime,
        arriveTime,
        arriveOffset,
        calcDistance,   // 相对计算位置
        leaveTime,
        leaveOffset,
        hasSummary,
        summary,
        summaryTime,
        summaryPics,
        projects
      }))
    })
  }

  const setDistance = (pos, offset) => {
    let label = ''
    if (pos > offset) {
      label =
        offset < 1000
          ? `距离客户位置超出${offset}米`
          : `距离客户位置超出${parseInt(offset / 1000, 10)}公里`
    } else {
      label =
        offset < 1000
          ? `距离客户位置${offset}米内`
          : `距离客户位置${parseInt(offset / 1000, 10)}公里内`
    }
    return label
  }

  return (
    <Page>
      {/* <Helmet>
      <meta name="description" content={description} />
    </Helmet> */}
      {state.hasData ? (
        <View>
          {state.customerName && (
            <Container>
              <VerticalLabel label="客户名称" value={state.customerName} />
            </Container>
          )}
          <Container>
            {state.visitName && <HorizontalLabel label="拜访人：" value={state.visitName} />}
            {state.visitUseTime && (
              <HorizontalLabel label="拜访用时：" value={state.visitUseTime} />
            )}
            {state.arriveTime && <HorizontalLabel label="抵达时间：" value={state.arriveTime} />}
            {state.arriveTime && (
              <DisLink color={state.arriveOffset > state.calcDistance ? 'red' : 'blue'} hasBottom>
                {setDistance(state.arriveOffset, state.calcDistance)}
              </DisLink>
            )}
            {state.leaveTime && <HorizontalLabel label="离开时间：" value={state.leaveTime} />}
            {state.leaveTime && (
              <DisLink
                color={state.leaveOffset > state.calcDistance ? 'red' : 'blue'}
                hasBottom={false}
              >
                {setDistance(state.leaveOffset, state.calcDistance)}
              </DisLink>
            )}
          </Container>
          {state.hasSummary && (
            <Container>
              <HorizontalLabel
                label="拜访人："
                align="flex-end"
                value={<Text>{state.summaryTime}</Text>}
              />
              <Content>{state.summary}</Content>
              {!!(state.summaryPics || []).length && (
                <ImageList
                  smallImgList={state.summaryPics}
                  bigImgList={state.summaryPics}
                  max={5}
                />
              )}
            </Container>
          )}
          {state.projects && !!(state.projects || []).length && (
            <Container noMargin>
              <HorizontalLabel label="执行项目" />
              <ListContainer>
                <LeftLine />
                {state.projects.map(({ name, time }, index) => (
                  <Project
                    key={index}
                    value={name}
                    time={time}
                    isLast={state.projects.length === index + 1}
                  />
                ))}
              </ListContainer>
            </Container>
          )}
          <BackText />
          <RegisterBar href="http://cas.waiqin365.com/auth/mobile/promotion.html?from=500012" />
        </View>
      ) : (
        <Empty description="暂无数据" />
      )}
    </Page>
  )
}

// @flow
import { styled } from 'linaria/lib/react'
import { View } from '@tarojs/components'


const Root = styled(View)`
  background-color: #fff;
`;

const Label = styled(View)`
  font-size: 12px;
  color: #666;
`;

const Text = styled(View)`
  font-size: 13px;
  color: #1a1a1a;
  padding-top: 10px;
`;


export default function VerticalLabel({
  label, value
}){
  return (
    <Root>
      <Label>{label}</Label>
      <Text>{value}</Text>
    </Root>
  );
}
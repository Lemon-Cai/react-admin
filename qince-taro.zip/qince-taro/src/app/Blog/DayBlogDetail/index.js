import Taro, { useRouter  } from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { styled } from 'linaria/lib/react'
import { RichText, View } from '@tarojs/components'

import fetch from '@/utils/request'

import { Avatar } from '@/components/Avatar'
import { Rate } from '@/components/Rate'
import { Page } from '@/components/Page'


import BizModules from '../components/BizModules'
import Address from '../components/Address'
import PublishTime from '../components/PublishTime'
import ImageList from '../components/ImageList'
import BackText from '../components/BackText'
import RegisterBar from '../components/RegisterBar'
import Module from '../components/Module'

import { emoji } from '../utils'

const Container = styled(View)`
  padding: 12px;
  background-color: #fff;
`

const Header = styled(View)`
  display: flex;
  align-items: center;
`

const Person = styled(View)`
  flex: 1;
  padding: 1px 12px;
`

const Name = styled(View)`
  font-size: 16px;
  color: #1a1a1a;
`

const Company = styled(View)`
  font-size: 12px;
  color: #999;
  padding-top: 4px;
`

const Type = styled(View)`
  text-align: right;
`

const TypeText = styled(View)`
  font-size: 12px;
  color: #666;
  padding-top: 4px;
`

const BlogContainer = styled(View)`
  margin: 12px 0;
`

const Content = styled(View)`
  font-size: 16px;
  color: #1a1a1a;
  line-height: 1.5;
`

const VisitLink = styled(View)`
  font-size: 16px;
  color: #0275d8;
  padding-left: 5px;
  text-decoration: none;
`

const ImageListContainer = styled(View)`
  margin: 12px 0;
`

const DayBlogDetail = () => {
  
  const router = useRouter()

  const [state, setState] = useState({
    description: ''
  })

  useEffect(() => {
    // const params = getURLParameters(window.location.href)
    if (router?.params) {
      const { tenantid, infoid, content = '' } = router?.params
      _getBlogInfo(
        {
          'data.blog_id': infoid,
          'data.tenant_id': tenantid
        },
        { description: decodeURIComponent(content) }
      )
    }

    return () => {}
  }, [])

  const _getBlogInfo = (params, obj = {}) => {
    fetch({
      url: '/app/blog/shareWeixinData.action',
      params,
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }).then(response => {
      if (response.code === '1') {
        let { blog = {}, comments = [] } = response.data
        const tenantId = params['data.tenant_id'] || ''
        const smallImgs = []
        const bigImgs = []
        const pictures = blog.pictures || []
        const bizModules = blog.biz_model_value || []
        pictures.forEach(element => {
          smallImgs.push(`${element.pic}?x-oss-process=style/zk320`)
          bigImgs.push(element.pic)
        })
        const newBizModules = bizModules.map(bizModule => {
          const value = bizModule.value
          const values = value.split(',')
          const newValues = values.map(elem => {
            return {
              label: elem.split(':')[0],
              value: elem.split(':')[1] || '--'
            }
          })
          return {
            label: bizModule.label,
            value: newValues
          }
        })
        const headerInfo = {
          name: blog.publish_name || '',
          deptName: blog.dept_name || '',
          iconUrl: blog.publish_small_face || '',
          score: blog.score || 0,
          hasScore: blog.blog_type === '2' || blog.score === 0 ? false : true,
          type: blog.blog_type || '1',
          typeName: getTypeName(blog.blog_type) || '日报'
        }
        const vistLink =
          blog.blog_type === '4'
            // ? `/_react_/blog/v1/visitBlog?tenantid=${tenantId}&visitor=${blog.publish_id}&visitid=${blog.work_id}`
            ? `/app/Blog/VisitDetail/index?tenantid=${tenantId}&visitor=${blog.publish_id}&visitid=${blog.work_id}`
            : ''
        let content = blog.content || ''
        if (blog.content.indexOf('<wqhref>') !== -1) {
          let contentStr = content.split('<wqhref>')
          content = `${contentStr[0]}<a href=${contentStr[1].split('##查看详情##')[0] ||
            ''}>查看详情</a>`
        }
        setState(prev => ({
          ...prev,
          ...obj,
          headerInfo,
          vistLink,
          modules: blog.model_value || [],
          bizModules: newBizModules,
          content: content,
          address: blog.location_a || '',
          smallImgs,
          bigImgs,
          publishTime: blog.publish_time || '',
          tool: getTerminalType(blog.terminal_type) || '来自web',

        }))
      } else {
        Taro.showToast({
          title: response.message || '获取日报失败'
        })
      }
    })
  }

  const handleViewDetail = () => {
    Taro.navigateTo({
      url: state.vistLink
    })
  }

  return (
    <Page>
      {/* <Helmet>
        <meta name="description" content={state.description} />
      </Helmet> */}
      <Container>
        <Header>
          <Avatar
            image={state.headerInfo?.iconUrl}
            text={state.headerInfo?.name}
            className="wq-blog-avatar"
          />
          <Person>
            <Name>{state.headerInfo?.name}</Name>
            <Company>{state.headerInfo?.deptName}</Company>
          </Person>
          <Type>
            {state.headerInfo?.hasScore && (
              <Rate value={state.headerInfo?.score} readonly style={{ display: 'flex' }} />
            )}
            <TypeText>{state.headerInfo?.typeName}</TypeText>
          </Type>
        </Header>
        <BizModules modules={state.bizModules} />
        <BlogContainer>
          {(state.modules || []).map(({ label, value }, index) => {
            const newValue = emoji(value)
            return <Module key={index} title={label} content={newValue} />
          })}
        </BlogContainer>
        <Content>
          <RichText 
            nodes={emoji(state.content)}
          />
          {/* <View dangerouslySetInnerHTML={{ __html: emoji(state.content) }} /> */}
          {state.vistLink && (
            <VisitLink url={state.vistLink} onClick={handleViewDetail}>查看详情</VisitLink>
            // <VisitLink href={state.vistLink} target="_blank">
            //   查看详情
            // </VisitLink>
          )}
        </Content>
        {state.address && <Address text={state.address} />}
        {!!state.smallImgs?.length && (
          <ImageListContainer>
            <ImageList smallImgList={state.smallImgs} bigImgList={state.bigImgs} />
          </ImageListContainer>
        )}
        <PublishTime text={state.publishTime} tool={state.tool} />
      </Container>
      <BackText />
      <RegisterBar href="//cas.waiqin365.com/auth/mobile/promotion.html?from=500012" />
    </Page>
  )
}

const getTypeName = type => {
  switch (type) {
    case '1':
      return '日报'
    case '2':
      return '分享'
    case '4':
      return '拜访'
    case '5':
      return '周报'
    case '6':
      return '月报'
    default:
      return '日报'
  }
}

const getTerminalType = type => {
  switch (type) {
    case '1':
      return '来自iPhone'
    case '2':
      return '来自Android'
    case '3':
      return '来自web'
    case '4':
      return '来自企业微信'
    default:
      return '来自web'
  }
}

export default DayBlogDetail

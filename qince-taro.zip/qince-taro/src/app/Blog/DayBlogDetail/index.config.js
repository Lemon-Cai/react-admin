export default definePageConfig({
  navigationBarTitleText: '勤策',
})
/*
 * @Author: CaiPeng
 * @Date: 2023-03-22 13:19:48
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 16:30:50
 * @FilePath: \qince-taro\src\app\Blog\DayBlogDetail\components\Module.js
 * @Description: 
 */
// @flow
import { View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

const Root = styled(View)`
  margin-bottom: 8px;
`

const Header = styled(View)`
  font-size: 14px;
  color: #999;
`

const Content = styled(View)`
  font-size: 16px;
  color: #1a1a1a;
  margin-top: 4px;
`

export default function Module({ title, content }) {
  return (
    <Root>
      <Header>{title}</Header>
      <Content dangerouslySetInnerHTML={{ __html: content }} />
    </Root>
  )
}

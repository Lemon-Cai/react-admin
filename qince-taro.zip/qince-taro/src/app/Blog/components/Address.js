/*
 * @Author: CaiPeng
 * @Date: 2023-03-21 20:19:10
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 10:46:45
 * @FilePath: \qince-taro\src\app\Blog\DayBlogDetail\components\Address.js
 * @Description: 
 */
// @flow
import { View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'
import { Icons } from '@/components/Icons'

const Root = styled(View)`
  font-size: 13px;
  color: #808080;
  margin-top: 10px;
`

// const Icon = styled.span`
//   display: inline-block;
//   width: 7px;
//   height: 11px;
//   background: url(${positionIcon}) no-repeat;
//   background-size: 7px 11px;
//   vertical-align: -1px;
//   margin-right: 5px;
// `;

export default function Address({ text }) {
  return (
    <Root>
      <Icons value="location" />
      {text}
    </Root>
  )
}

/*
 * @Author: CaiPeng
 * @Date: 2023-03-21 20:30:36
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 19:10:25
 * @FilePath: \qince-taro\src\app\Blog\components\RegisterBar.js
 * @Description: 
 */
// @flow
import Taro from '@tarojs/taro'
import { useState } from 'react'
import { View, Image } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

import closeIcon from './closeIcon.png'
import logoIcon from './logo.png'

const Root = styled(View)`
  display: flex;
  align-items: center;
  position: fixed;
  /* bottom: calc(0px + env(safe-area-inset-bottom)); */
  bottom: 0;
  left: 0;
  right: 0;
  height: 50px;
  background-color: #fff;
  padding: 0 12px;
`

const Logo = styled(Image)`
  width: 89px;
  height: 30px;
  /* background: url(${props => props.src}) no-repeat;
  background-size: contain; */
  margin-right: 5px;
`

const Text = styled(View)`
  flex: 1;
  font-size: 13px;
  color: #4d4d4d;
  height: 25px;
  line-height: 25px;
  border-left: 1px solid #ccc;
  padding-left: 5px;
`

const Btn = styled(View)`
  display: inline-block;
  font-size: 14px;
  color: #fff;
  padding: 5px 10px;
  background-color: #ff9008;
  border-radius: 4px;
  text-decoration: none;
`

const CloseBtn = styled(View)`
  display: inline-block;
  width: 25px;
  height: 25px;
  position: absolute;
  left: 0;
  top: 0;
  background: url(${closeIcon}) no-repeat;
  background-size: contain;
`

export default function RegisterBar() {
  const [state, setState] = useState({
    isShow: true
  })

  const hideBar = () => {
    setState({ isShow: false })
  }

  const handleNavigator = () => {
    Taro.navigateTo({
      url: "/app/Blog/Register/index"
    })
  }
  return (
    <View>
      {state.isShow && (
        <Root>
          <Logo src={logoIcon} alt="外勤365" mode='aspectFit' />
          <Text>移动销售业务管理平台</Text>
          <Btn onClick={handleNavigator}>
            立即注册
          </Btn>
          <CloseBtn onClick={hideBar} />
        </Root>
      )}
    </View>
  )
}

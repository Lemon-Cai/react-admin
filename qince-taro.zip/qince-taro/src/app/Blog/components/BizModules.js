// @flow
import { View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

const Root = styled(View)`
  background-color: #f8f7f7;
  margin-top: 12px;
`

const Header = styled(View)`
  font-size: 14px;
  color: #808080;
  padding: 12px;
`

const Container = styled(View)`
  display: flex;
  flex-wrap: wrap;
  row-gap: 8px;
  padding-bottom: 12px;
`

const Block = styled(View)`
  text-align: center;
  flex: 0 0 33.33%;
`

const Num = styled(View)`
  font-size: 15px;
  color: #1a1a1a;
`

const Label = styled(View)`
  font-size: 12px;
  color: #999;
  margin-top: 6px;
`

function BizModules(props) {
  const getModules = () => {
    const { modules } = props
    const Modules =
      modules &&
      modules.map((module, index) => {
        const header = module.label
        const values = module.value || []
        const Blocks =
          values &&
          values.map(({ label, value }, idx) => (
            <Block key={idx}>
              <Num>{value}</Num>
              <Label>{label}</Label>
            </Block>
          ))
        return (
          <Root key={index}>
            <Header>{header}</Header>
            <Container>{Blocks}</Container>
          </Root>
        )
      })
    return Modules
  }

  return getModules()
}

export default BizModules

/*
 * @Author: CaiPeng
 * @Date: 2023-03-21 20:30:14
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 08:50:17
 * @FilePath: \qince-taro\src\app\Blog\DayBlogDetail\components\BackText.js
 * @Description:
 */
// @flow
import { View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

const Root = styled(View)`
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin: 20px 0 70px 0;
`

const Line = styled(View)`
  height: 1px;
  width: 60%;
  background-color: #bdbdbd;
  border: none;
`

const Text = styled(View)`
  display: inline-block;
  padding: 0 10px;
  font-size: 12px;
  color: #999;
  position: absolute;
  left: 50%;
  background-color: #f0f1f2;
  margin-left: -56px;
`

export default function BackText() {
  return (
    <Root>
      <Line />
      <Text>内容来自外勤365</Text>
    </Root>
  )
}

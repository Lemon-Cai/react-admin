/*
 * @Author: CaiPeng
 * @Date: 2023-03-21 20:23:47
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 13:18:31
 * @FilePath: \qince-taro\src\pages\Blog\components\ImageList.js
 * @Description: 
 */
// @flow
import Taro from '@tarojs/taro'
import { Image, View } from '@tarojs/components'
// import { useState } from 'react'
import { styled } from 'linaria/lib/react'

// import ImageView from './ImageView';

const Root = styled(View)`
  overflow: hidden;
`

const ImageContainer = styled(View)`
  display: inline-block;
  position: relative;
  margin-right: 3px;
`

const Img = styled(Image)`
  display: block;
  width: 80px;
  height: 80px;
  /* background: url(${props => props.src});
  background-size: cover;
  background-position: center; */
  border: 1px solid #e0e0e0;
`

const Mask = styled(View)`
  position: absolute;
  display: inline-block;
  width: 100%;
  height: 100%;
  opacity: 0.3;
  background-color: #000;
  left: 0;
  top: 0;
`

const Count = styled(View)`
  font-size: 24px;
  color: #fff;
  position: absolute;
  z-index: 1;
  top: 50%;
  left: 50%;
  margin-top: -12px;
  margin-left: -14px;
`

function ImageList({
  smallImgList = [],
  max = 3
}) {
  // const [state, setState] = useState({
  //   isOpen: false
  // })

  const openImageView = (index) => {
    // setState({ isOpen: true })
    Taro.previewImage({
      current: smallImgList[index].pic,
      urls: smallImgList
    })
  }

  // const closeView = () => {
  //   setState({ isOpen: false })
  // }

  const getImageList = imagelist => {
    const count = imagelist.length > max ? imagelist.length - max : 0
    const ImgComponents = imagelist.slice(0, max).map((img, index) => {
      return (
        <ImageContainer key={index} onClick={() => openImageView(index)}>
          <Img src={img} mode='aspectFit' />
          {index === max - 1 && !!count && <Mask />}
          {index === max - 1 && !!count && <Count>+{count}</Count>}
        </ImageContainer>
      )
    })
    return ImgComponents
  }

  return (
    <Root>
      {getImageList(smallImgList)}
      {/* {state.isOpen && <ImageView closeView={closeView} imageList={props.bigImgList} />} */}
    </Root>
  )
}

export default ImageList

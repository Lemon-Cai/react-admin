// @flow
import { useState } from 'react'
import Lightbox from 'react-image-lightbox'
import 'react-image-lightbox/style.css'

export default function ImageView({ imageList, closeView }) {
  const [state, setState] = useState({
    photoIndex: 0,
    isOpen: false
  })

  return (
    <Lightbox
      mainSrc={imageList[state.photoIndex]}
      nextSrc={imageList[(state.photoIndex + 1) % imageList.length]}
      prevSrc={imageList[(state.photoIndex + imageList.length - 1) % imageList.length]}
      onCloseRequest={closeView}
      onMovePrevRequest={() =>
        setState(prev => ({
          ...prev,
          photoIndex: (state.photoIndex + imageList.length - 1) % imageList.length
        }))
      }
      onMoveNextRequest={() =>
        setState(prev => ({
          ...prev,
          photoIndex: (state.photoIndex + 1) % imageList.length
        }))
      }
    />
  )
}

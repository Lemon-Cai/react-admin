/*
 * @Author: CaiPeng
 * @Date: 2023-03-22 13:19:48
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 16:25:40
 * @FilePath: \qince-taro\src\app\Blog\DayBlogDetail\components\PublishTime.js
 * @Description: 
 */
// @flow
import { Text, View } from '@tarojs/components'
import { styled } from 'linaria/lib/react'

const Root = styled(View)`
  font-size: 12px;
  color: #808080;
  margin-top: 12px;
`

const Time = styled(Text)`
  padding-right: 5px;
`

export default function PublishTime({ text, tool }) {
  return (
    <Root>
      <Time>{text}</Time>
      {tool && <Text>{tool}</Text>}
    </Root>
  )
}

/*
 * @Author: CaiPeng
 * @Date: 2023-03-22 09:07:41
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-22 13:12:50
 * @FilePath: \qince-taro\src\app\Blog\utils\index.js
 * @Description: 
 */
import emoji from './emoji';

const round = (n, decimals = 0) => Number(`${Math.round(`${n}e${decimals}`)}e-${decimals}`);
const getURLParameters = url =>
  (url.match(/([^?=&]+)(=([^&]*))/g) || []).reduce(
    // eslint-disable-next-line
    (a, v) => ((a[v.slice(0, v.indexOf('='))] = v.slice(v.indexOf('=') + 1)), a),
    {}
);
export { round, getURLParameters, emoji }
const emojiArr = [
  { id: "1", icon: "1.png", value: "[微笑]" },
  { id: "2", icon: "2.png", value: "[撇嘴]" },
  { id: "3", icon: "3.png", value: "[色]" },
  { id: "4", icon: "4.png", value: "[发呆]" },
  { id: "5", icon: "5.png", value: "[得意]" },
  { id: "6", icon: "6.png", value: "[流泪]" },
  { id: "7", icon: "7.png", value: "[害羞]" },
  { id: "8", icon: "8.png", value: "[闭嘴]" },
  { id: "9", icon: "9.png", value: "[睡]" },
  { id: "10", icon: "10.png", value: "[大哭]" },
  { id: "11", icon: "11.png", value: "[尴尬]" },
  { id: "12", icon: "12.png", value: "[发怒]" },
  { id: "13", icon: "13.png", value: "[调皮]" },
  { id: "14", icon: "14.png", value: "[呲牙]" },
  { id: "15", icon: "15.png", value: "[惊讶]" },
  { id: "16", icon: "16.png", value: "[难过]" },
  { id: "17", icon: "17.png", value: "[酷]" },
  { id: "18", icon: "18.png", value: "[冷汗]" },
  { id: "19", icon: "19.png", value: "[抓狂]" },
  { id: "20", icon: "20.png", value: "[吐]" },
  { id: "21", icon: "21.png", value: "[偷笑]" },
  { id: "22", icon: "22.png", value: "[可爱]" },
  { id: "23", icon: "23.png", value: "[白眼]" },
  { id: "24", icon: "24.png", value: "[傲慢]" },
  { id: "25", icon: "25.png", value: "[饥饿]" },
  { id: "26", icon: "26.png", value: "[困]" },
  { id: "27", icon: "27.png", value: "[惊恐]" },
  { id: "28", icon: "28.png", value: "[流汗]" },
  { id: "29", icon: "29.png", value: "[憨笑]" },
  { id: "30", icon: "30.png", value: "[大兵]" },
  { id: "31", icon: "31.png", value: "[奋斗]" },
  { id: "32", icon: "32.png", value: "[咒骂]" },
  { id: "33", icon: "33.png", value: "[疑问]" },
  { id: "34", icon: "34.png", value: "[嘘]" },
  { id: "35", icon: "35.png", value: "[晕]" },
  { id: "36", icon: "36.png", value: "[折磨]" },
  { id: "37", icon: "37.png", value: "[衰]" },
  { id: "38", icon: "38.png", value: "[骷髅]" },
  { id: "39", icon: "39.png", value: "[敲打]" },
  { id: "40", icon: "40.png", value: "[再见]" },
  { id: "41", icon: "41.png", value: "[擦汗]" },
  { id: "42", icon: "42.png", value: "[抠鼻]" },
  { id: "43", icon: "43.png", value: "[鼓掌]" },
  { id: "44", icon: "44.png", value: "[糗大了]" },
  { id: "45", icon: "45.png", value: "[坏笑]" },
  { id: "46", icon: "46.png", value: "[左哼哼]" },
  { id: "47", icon: "47.png", value: "[右哼哼]" },
  { id: "48", icon: "48.png", value: "[哈欠]" },
  { id: "49", icon: "49.png", value: "[鄙视]" },
  { id: "50", icon: "50.png", value: "[委屈]" },
  { id: "51", icon: "51.png", value: "[快哭了]" },
  { id: "52", icon: "52.png", value: "[阴险]" },
  { id: "53", icon: "53.png", value: "[亲亲]" },
  { id: "54", icon: "54.png", value: "[吓]" },
  { id: "55", icon: "55.png", value: "[可怜]" },
  { id: "56", icon: "56.png", value: "[菜刀]" },
  { id: "57", icon: "57.png", value: "[西瓜]" },
  { id: "58", icon: "58.png", value: "[啤酒]" },
  { id: "59", icon: "59.png", value: "[篮球]" },
  { id: "60", icon: "60.png", value: "[乒乓]" },
  { id: "61", icon: "61.png", value: "[咖啡]" },
  { id: "62", icon: "62.png", value: "[饭]" },
  { id: "63", icon: "63.png", value: "[猪头]" },
  { id: "64", icon: "64.png", value: "[玫瑰]" },
  { id: "65", icon: "65.png", value: "[凋谢]" },
  { id: "66", icon: "66.png", value: "[示爱]" },
  { id: "67", icon: "67.png", value: "[爱心]" },
  { id: "68", icon: "68.png", value: "[心碎]" },
  { id: "69", icon: "69.png", value: "[蛋糕]" },
  { id: "70", icon: "70.png", value: "[闪电]" },
  { id: "71", icon: "71.png", value: "[炸弹]" },
  { id: "72", icon: "72.png", value: "[刀]" },
  { id: "73", icon: "73.png", value: "[足球]" },
  { id: "74", icon: "74.png", value: "[瓢虫]" },
  { id: "75", icon: "75.png", value: "[便便]" },
  { id: "76", icon: "76.png", value: "[月亮]" },
  { id: "77", icon: "77.png", value: "[太阳]" },
  { id: "78", icon: "78.png", value: "[礼物]" },
  { id: "79", icon: "79.png", value: "[拥抱]" },
  { id: "80", icon: "80.png", value: "[强]" },
  { id: "81", icon: "81.png", value: "[弱]" },
  { id: "82", icon: "82.png", value: "[握手]" },
  { id: "83", icon: "83.png", value: "[胜利]" },
  { id: "84", icon: "84.png", value: "[抱拳]" },
  { id: "85", icon: "85.png", value: "[勾引]" },
  { id: "86", icon: "86.png", value: "[拳头]" },
  { id: "87", icon: "87.png", value: "[差劲]" },
  { id: "88", icon: "88.png", value: "[爱你]" },
  { id: "89", icon: "89.png", value: "[NO]" },
  { id: "90", icon: "90.png", value: "[OK]" }
];

let facemap = {};
let emojimap = {};

for(var i = 0; i < emojiArr.length; i++){
	var item = emojiArr[i];
	facemap[item.value] = item.icon;
	emojimap[item.id] = item.value;
};

export default function emoji(content){
  if (typeof content === 'string') {
    let newContent = content.replace(/\[[^[\]]*?\]/g, function($0) {
      var url = facemap[$0];
      if (process.env.NODE_ENV === 'production' && url) {
        return '<img style="width:22px;height:22px;vertical-align:text-bottom;" src="/common_new/component/faces/images/im_ee_' + url + '" alt="' + $0 + '" />';
      }
      return $0;
    });
    return newContent;
  }
  return content
};




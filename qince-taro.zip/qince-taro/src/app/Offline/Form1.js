import { useState } from 'react'
import Taro from '@tarojs/taro'
import { Input } from '@tarojs/components'

import { Page } from '@/components/Page'
import { Form, FormItem } from '@/components/Form'
import { Button } from '@/components/Button'

export default props => {
  const [state, setState] = useState({
    code: '',
    name: ''
  })

  const handleChange = params => {
    setState(prevState => ({
      ...prevState,
      ...params
    }))
  }

  const handleClick = () => {
    Taro.getNetworkType({
			success: function (res) {
				// 返回网络类型, 有效值：
				// wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
				var networkType = res.networkType
				if (networkType === 'unknown' || networkType === 'none') {
					Taro.showToast({
						title: '当前网络状态不好，数据提交在本地成功！',
						icon: 'none',
						duration: 2000,
						success: () => {
							Taro.setStorageSync('qince-form1', state)
							Taro.navigateBack()
						}
					})
				} else {
					Taro.showToast({
						title: `当前网络状态为：${networkType}，提交服务器成功！`,
						icon: 'none',
						duration: 2000,
						success: () => {
							Taro.setStorageSync('qince-form1', state)
							Taro.navigateBack()
						}
					})
				}
			}
		})
  }

  return (
    <Page>
      <Form footer={<Button type="primary" onClick={handleClick}>提交</Button>}>
        <FormItem title="微信号">
          <Input
            name="code"
            className="weui-input"
            placeholder="填写本人微信号"
            placeholderClass="weui-input__placeholder"
            value={state.code}
            onInput={e => handleChange({ code: e.target.value })}
          />
        </FormItem>
        <FormItem title="昵称">
          <Input
            name="name"
            className="weui-input"
            placeholder="填写本人微信号的昵称"
            placeholderClass="weui-input__placeholder"
            value={state.name}
            onInput={e => handleChange({ name: e.target.value })}
          />
        </FormItem>
      </Form>
    </Page>
  )
}

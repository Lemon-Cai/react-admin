import Taro from '@tarojs/taro'

import { Page } from '@/components/Page'
import { Cells, CellsTitle, Cell, CellBody, CellFooter } from '@/components/Cell'

export default props => {
  const handleClick = (params) => {
    console.log('handleClick')
    Taro.navigateTo(params)
  }

  const handleArrive = () => {

  }

  const handleLeave = () => {
    
  }

  return (
    <Page>
      <CellsTitle>勤策离线测试demo</CellsTitle>
      <Cells>
        <Cell access onClick={() => handleArrive}>
          <CellBody>抵达</CellBody>
          <CellFooter />
        </Cell>
        <Cell access onClick={() => handleClick({title: '测试表单1', url: '/pages/offline/Form1'})}>
          <CellBody>测试表单1</CellBody>
          <CellFooter />
        </Cell>
        <Cell access onClick={() => handleClick({title: '测试表单2', url: '/pages/offline/Form2'})}>
          <CellBody>测试表单2</CellBody>
          <CellFooter />
        </Cell>
        <Cell access onClick={() => handleLeave}>
          <CellBody>离开</CellBody>
          <CellFooter />
        </Cell>
      </Cells>
    </Page>
  )
}

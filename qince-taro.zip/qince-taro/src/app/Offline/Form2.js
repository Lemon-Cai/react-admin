import { useState } from 'react'
import Taro from '@tarojs/taro'
import { Input } from '@tarojs/components'
import { toast } from '@/utils/dialog'

import { Page } from '@/components/Page'
import { Form, FormItem } from '@/components/Form'
import { Button } from '@/components/Button'

export default props => {
  const [state, setState] = useState({
    field1: '',
    field2: ''
  })

  const handleChange = params => {
    setState(prevState => ({
      ...prevState,
      ...params
    }))
  }

  const handleClick = () => {
    Taro.getNetworkType({
			success: function (res) {
				// 返回网络类型, 有效值：
				// wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
				var networkType = res.networkType
				if (networkType === 'unknown' || networkType === 'none') {
					Taro.showToast({
						title: '当前网络状态不好，数据提交在本地成功！',
						icon: 'none',
						duration: 2000,
						success: () => {
							Taro.setStorageSync('qince-form2', state)
							Taro.navigateBack()
						}
					})
				} else {
					Taro.showToast({
						title: `当前网络状态为：${networkType}，提交服务器成功！`,
						icon: 'none',
						duration: 2000,
						success: () => {
							Taro.setStorageSync('qince-form2', state)
							Taro.navigateBack()
						}
					})
				}
			}
		})
  }

  return (
    <Page>
      <Form
        footer={
          <Button type="primary" onClick={handleClick}>
            提交
          </Button>
        }
      >
        <FormItem title="缓存测试字段1">
          <Input
            name="field1"
            className="weui-input"
            placeholder="请输入缓存测试字段1"
            placeholderClass="weui-input__placeholder"
            value={state.field1}
            onInput={e => handleChange({ field1: e.target.value })}
          />
        </FormItem>
        <FormItem title="缓存测试字段2">
          <Input
            name="field2"
            className="weui-input"
            placeholder="请输入缓存测试字段2"
            placeholderClass="weui-input__placeholder"
            value={state.field2}
            onInput={e => handleChange({ field2: e.target.value })}
          />
        </FormItem>
      </Form>
    </Page>
  )
}

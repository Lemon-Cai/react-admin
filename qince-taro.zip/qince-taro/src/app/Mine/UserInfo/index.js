import { useEffect, useState, useRef } from 'react'
import { connect } from 'react-redux'
import Taro from '@tarojs/taro'

import { Page, PageBody, PageFooter } from '@/components/Page'
import { Cells, Cell, CellHeader, CellBody, CellFooter } from '@/components/Cell/index'
import { SubmitBar } from '@/components/SubmitBar'
import { Avatar } from '@/components/Avatar'
import Employee from '@/components/Employee'

import * as actions from '@/store/Mine'

// 个人信息详情
const MineDetail = props => {
  const empRef = useRef(null)
  const { userInfo, dispatchTransferAdmin, dispatchGetUserInfo } = props
  // 头像
  const [face, setFace] = useState('')

  useEffect(() => {
    if (userInfo) {
      const path = `${userInfo.userFace}${
        userInfo?.userFace?.includes('?') ? '&' : '?'
      }x-oss-process=style/zk_face`
      try {
        Taro.getImageInfo({
          src: path,
          success: res => {
            if (res.errMsg === 'getImageInfo:ok') {
              setFace(path)
            }
          }
        })
      } catch (e) {
        console.log(e)
      }
    }
  }, [userInfo])

  const _formatDisplayValue = field => {
    if (field.options) {
      if (field.value) {
        let item = field.options.find(it => field.value === it.id)
        if (item) {
          return item.name
        }
        return ''
      }
    }
    return field.value
  }

  // 认证
  const handleCertification = () => {}

  const handleChangeAvatar = () => {
    Taro.chooseImage({
      sourceType: ['album', 'camera'],
      sizeType: ['compressed']
    })
      .then(result => {
        if (result.errMsg === 'chooseImage:ok') {
          const { tempFiles } = result

          Taro.uploadFile({
            url: `${Taro.getStorageSync('appsvrUrl') ||
              'https://xiaocui.waiqin365.com'}/platform/gaea/person/jsonUpdateFaceForH5.action`,
            filePath: tempFiles[0].path,
            name: 'file',
            withCredentials: true,
            formData: {
              file: tempFiles[0].path
            },
            header: {
              'Content-Type': 'multipart/form-data',
              Authorization: `Bearer ${Taro.getStorageSync('qince-token')}` // 上传需要单独处理cookie
            },
            success(res) {
              console.log('result:', res)
              const data = JSON.parse(res.data)
              if (data.code === '1') {
                Taro.showToast({
                  mask: true,
                  title: '头像更新成功',
                  icon: 'none'
                })
                dispatchGetUserInfo()
              } else {
                Taro.showToast({
                  mask: true,
                  title: data.message || '',
                  icon: 'none'
                })
              }
            },
            fail(e) {
              console.log('uploadFile fail:', e)
            }
          })
        }
        // let pic = [...result.tempFiles.map(o => ({ pic: o.path }))]
      })
      .catch(err => {
        console.log(err)
      })
  }

  // 点击底部按钮事件
  const handleClickFooter = item => {
    if (item.key === 'transferAdmin') {
      Taro.showModal({
        title: '提示',
        content: '移交后您将不再具有企业管理员权限！',
        success({ confirm }) {
          if (confirm) empRef?.current?.handleOpen()
        },
        fail: () => {}
      })
    }
  }

  const handleBeforeConfirm = item => {
    return new Promise(resolve => {
      Taro.showModal({
        title: '提示',
        content: `确认选择“${item.name}”为管理员吗？确认后将无法更改！`,
        success({ confirm }) {
          if (confirm) {
            Taro.showLoading()
            dispatchTransferAdmin({
              empId: item.id
            }).then(res => {
              Taro.hideLoading()
              if (res.code === '1') {
                Taro.showToast({ mask: true, title: '已成功移交!', icon: 'none' })
                setTimeout(() => {
                  // resolve(true)
                  Taro.removeStorageSync('qince-token')
                  Taro.redirectTo({
                    url: '/pages/Login/index'
                  })
                }, 1000)
              } else {
                Taro.showToast({  mask: true, title: res.message, icon: 'none' })
                resolve(false)
              }
            })
          } else {
            resolve(false)
          }
        },
        fail: () => {
          resolve(false)
        }
      })
    })
  }

  return (
    <Page>
      <PageBody>
        <Cells>
          <Cell access>
            <CellHeader></CellHeader>
            <CellBody>头像</CellBody>
            <CellFooter onClick={handleChangeAvatar}>
              <Avatar circle size="small" image={face} text={userInfo?.name} style={{marginBlock: '-7px'}} />
            </CellFooter>
          </Cell>
          <Cell>
            <CellBody>姓名</CellBody>
            <CellFooter>{userInfo?.name}</CellFooter>
          </Cell>
          {userInfo?.extOriginData?.find(i => i.code === 'realname') && (
            <Cell
              access={userInfo.isCertification !== '1'}
              onClick={() => (userInfo.isCertification !== '1' ? handleCertification() : null)}
            >
              <CellBody>认证姓名</CellBody>
              <CellFooter>
                {userInfo?.extOriginData?.find(i => i.code === 'realname')?.value}
              </CellFooter>
            </Cell>
          )}
          <Cell>
            <CellHeader></CellHeader>
            <CellBody>手机号</CellBody>
            <CellFooter>{userInfo?.mobile}</CellFooter>
          </Cell>
        </Cells>
        <Cells>
          <Cell>
            <CellBody>企业账号</CellBody>
            <CellFooter>{userInfo?.tenantCode}</CellFooter>
          </Cell>
          <Cell>
            <CellBody>所属部门</CellBody>
            <CellFooter>{userInfo?.dept_name}</CellFooter>
          </Cell>
        </Cells>
        {userInfo?.extOriginData && (
          <Cells>
            {userInfo?.extOriginData
              ?.filter(i => i.code !== 'realname')
              ?.map(item => (
                <Cell key={item.code}>
                  <CellBody>{item.name}</CellBody>
                  <CellFooter>{_formatDisplayValue(item) || '--'}</CellFooter>
                </Cell>
              ))}
          </Cells>
        )}
      </PageBody>
      {userInfo?.isAdmin === 'true' && (
        <PageFooter className="wq-border-t">
          <SubmitBar
            data={[{ key: 'transferAdmin', name: '移交管理员' }]}
            onClick={handleClickFooter}
          />

          <Employee ref={empRef} multiple={false} beforeConfirm={handleBeforeConfirm} />
        </PageFooter>
      )}
    </Page>
  )
}

const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions
}

export default connect(mapStateToProps, mapDispatchToProps)(MineDetail)

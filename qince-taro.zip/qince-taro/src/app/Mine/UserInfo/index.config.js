export default definePageConfig({
  navigationBarTitleText: '个人信息',
})
import Taro from "@tarojs/taro"
import { useEffect } from "react"
import { Button } from "@/components/Button"
import { Page } from "@/components/Page"
import { Textarea } from "@/components/Textarea"

export default () => {
  useEffect(() => {
    Taro.setNavigationBarTitle({
      title: ""
    })
  }, [])

  const handleSubmit = () => {}

  return (
    <Page>
      <Textarea></Textarea>
      <Button className="weui-btn weui-btn_primary" onClick={handleSubmit}>
        确定
      </Button>
    </Page>
  )
}

import Taro from '@tarojs/taro'
import { useState } from 'react'
import { connect } from 'react-redux'
import { View, Button } from '@tarojs/components'
import { Cells, Cell, CellHeader, CellBody } from '@/components/Cell'
import { Page } from '@/components/Page'
import { Input } from '@/components/Input'

import { styled } from 'linaria/react'
import * as actions from '@/store/Mine'

import passwordUtils from '@/utils/password'

const StyledPage = styled(Page)`
  .label-top {
    display: block;
  }
  .flex {
    display: flex;
    .icon {
    }
  }
  .flex-middle {
    align-items: center;
  }
  .flex-between {
    justify-content: space-between;
  }
  .submit-box {
    padding: 20px;
  }
`

const Index = ({ userInfo, dispatchChangePassword }) => {
  const [formData, setFormData] = useState({})

  const handleChange = (val, e) => {
    setFormData({ ...formData, [e.target.id]: val })
  }

  const handleSubmit = () => {
    if (!_validate(formData)) {
      return
    }

    let params = {
      oldPassword: formData.password,
      password: formData.newPassword,
      confpwd: formData.confirmPassword
    }
    dispatchChangePassword(params).then(res => {
      if (res.error) {
        Taro.showToast({
          mask: true,
          title: res.error,
          icon: 'none'
        })
      } else {
        Taro.showToast({
          mask: true,
          title: '修改密码成功，您需要重新登陆',
          icon: 'none'
        })
        setTimeout(() => {
          Taro.redirectTo({
            url: '/pages/Login/index'
          })
        }, 1500)
      }
    })
  }

  // 输入密码校验
  const _validate = params => {
    if (!params.newPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入新密码！',
        icon: 'none'
      })
      return
    }
    if (!params.confirmPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入确认新密码！',
        icon: 'none'
      })
      return
    }
    let result = passwordUtils.checkPassword(params.newPassword)
    if (!result.success) {
      // 低强度走之前校验
      Taro.showToast({
        mask: true,
        title: result.msg,
        icon: 'none'
      })
      return
    }
    if (params.newPassword !== params.confirmPassword) {
      Taro.showToast({
        mask: true,
        title: '新密码和确认新密码不一致！',
        icon: 'none'
      })
      return
    }
    return true
  }

  return (
    <StyledPage>
      <Cells>
        <Cell className="label-top">
          <CellHeader>新密码</CellHeader>
          <View className="flex flex-middle flex-between">
            <CellBody>
              <Input
                clear
                showEye
                password
                type="password"
                name="newPassword"
                value={formData.newPassword}
                placeholder="请输入新密码"
                onChange={handleChange}
              />
            </CellBody>
          </View>
        </Cell>
        <Cell className="label-top">
          <CellHeader>确认密码</CellHeader>
          <View className="flex flex-middle flex-between">
            <CellBody>
              <Input
                clear
                showEye
                password
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                placeholder="再次确认新密码"
                onChange={handleChange}
              />
            </CellBody>
          </View>
        </Cell>
      </Cells>
      <View>{userInfo?.pwdStrengthMsg}</View>
      <View className="submit-box">
        <Button
          // disabled={}
          type="primary"
          className="weui-btn weui-btn_primary"
          onClick={handleSubmit}
        >
          确定
        </Button>
      </View>
    </StyledPage>
  )
}

const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions
}

export default connect(mapStateToProps, mapDispatchToProps)(Index)

export default definePageConfig({
  navigationBarTitleText: '注销账号',
})
import Taro from '@tarojs/taro'
import { connect } from 'react-redux'
import { styled } from 'linaria/react'
import { View } from '@tarojs/components'

import { Page } from '@/components/Page'
import { Button } from '@/components/Button'

import * as actions from '@/store/Mine'

const StyledPage = styled(Page)`
  padding-top: 12px;
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  .qince-page {
    background-color: #fff;
    padding: 20px;
    height: 100%;
    width: 100%;
    box-sizing: border-box;
  }
  .show-mobile {
    color: #ff9008;
  }
  .tips {
    margin-top: 12px;
    padding: 12px;
    border-radius: 3px;
    background: #f0f1f2;
  }
  .btn-box {
    width: 100%;
    position: absolute;
    bottom: 50px;
    padding: 20px;
    left: 0;
  }
`

const Index = ({ userInfo, dispatchLogout }) => {
  const handleClickLogout = () => {
    Taro.showModal({
      mask: true,
      content: '确认注销帐号？',
      confirmText: '注销',
      cancelText: '取消',
      showCancel: true,
      success: () => {
        handleSendLogout()
      }
    })
  }

  const handleSendLogout = () => {
    let params = {
      token: new Date().getTime(),
      platform: '0'
    }
    dispatchLogout(params).then(res => {
      if (res?.code === '1') {
        Taro.showToast({
          mask: true,
          icon: 'none',
          title: '已向管理员发送注销申请，管理员确认后将注销账号。'
        })
      } else {
        Taro.showToast({
          mask: true,
          icon: 'none',
          title: res.message
        })
      }
    })
  }

  return (
    <StyledPage>
      <Page>
        <View className="title">注销账号</View>
        <View className="show-mobile">{userInfo?.mobile}</View>
        <View className="tips">
          如您注销账号，则当前帐号注册状态在APP、小程序留存的信息均将被清空且无法找回。
        </View>
        <View className="btn-box">
          <Button gradients={['#FF5E3A', '#FF9500']} type="primary" onClick={handleClickLogout}>
            注销账号
          </Button>
        </View>
      </Page>
    </StyledPage>
  )
}
const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions
}

export default connect(mapStateToProps, mapDispatchToProps)(Index)

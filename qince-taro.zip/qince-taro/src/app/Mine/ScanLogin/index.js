import Taro, { getCurrentInstance, useLoad } from '@tarojs/taro'
import { useState } from 'react'
import { Page } from '@/components/Page'
import { View, Button } from '@tarojs/components'
import { Icons } from '@/components/Icons'

import { connect } from 'react-redux'
import * as actions from '@/store/Mine'

import { styled } from 'linaria/lib/react'

const StyledPage = styled(Page)`
  text-align: center;

  .icon-box {
    margin-top: 40px;
    .qince-icon {
      font-size: 50px;
    }
  }
  .weui-btn {
    background: linear-gradient(90deg, #ff5e3a, #ff9500);
    color: #fff;
  }
  .footer {
    width: 100%;
    position: absolute;
    bottom: 50px;
    padding: 20px;
    .cancel-btn {
      color: #ff9008;
      margin: 16px 0;
    }
  }
`

const Index = ({ dispatchScanLogin, dispatchScanAuth }) => {
  const { router } = getCurrentInstance()

  const [scanType, setScanType] = useState('') // 1 扫码鉴权   0 扫码登录
  const [codeStr, setCodeStr] = useState('')

  useLoad(() => {
    let qrcode = decodeURIComponent(router?.params?.result || '')
    console.log(qrcode, 'qrcodeeee')
    setCodeStr(qrcode)
    if (qrcode.includes('auth')) {
      setScanType('1')
    } else {
      setScanType('0')
    }
  })

  const handleConfirm = () => {
    if (scanType === '0') {
      handleConfirmLogin()
    } else if (scanType === '1') {
      handleConfirmAuth()
    }
  }
  // 扫码鉴权
  const handleConfirmAuth = async () => {
    const params = {
      rand: codeStr.replace('authQrcode:', '')
    }
    Taro.showLoading({mask: true})
    const result = await dispatchScanAuth(params)
    Taro.hideLoading()
    if (result.code === '1') {
      Taro.showToast({
        mask: true,
        title: '授权成功',
        icon: 'success'
      })
    } else {
      Taro.showToast({
        mask: true,
        title: result.message || '',
        icon: 'none'
      })
    }
    setTimeout(() => {
      Taro.navigateBack({
        delta: 1
      })
    }, 1500)
  }

  // 扫码登录
  const handleConfirmLogin = () => {
    let params = {
      qrcode: codeStr,
      esn: '2899574409fffd13',
      simCardNum: '2',
      clientid: '',
      clientversion: '7.0.7',
      imsi: 'X0000000000100X'
    }
    Taro.showLoading({mask: true})
    dispatchScanLogin(params).then(res => {
      Taro.hideLoading()
      if (res.code === '1') {
        Taro.showToast({
          mask: true,
          title: '登陆成功',
          icon: 'success'
        })
      } else {
        Taro.showToast({
          mask: true,
          title: res.message || '',
          icon: 'none'
        })
      }
      setTimeout(() => {
        Taro.navigateBack({
          delta: 1
        })
      }, 1500)
    })
  }

  const handleCancel = () => {
    Taro.navigateBack({
      delta: 1
    })
  }

  return (
    <StyledPage>
      <View class="main-tips">
        <View class="icon-box">
          <Icons value="compute"></Icons>
        </View>
        <View>勤策电脑端{scanType === '1' ? '登录' : '鉴权'}确认</View>
      </View>
      <View className="footer">
        <Button class="weui-btn weui-btn_primary" type="primary" onClick={handleConfirm}>
          {scanType === '1' ? '登录' : '确定'}
        </Button>

        <View class="cancel-btn" onClick={handleCancel}>
          取消{scanType === '1' ? '登录' : '确定'}
        </View>
      </View>
    </StyledPage>
  )
}

const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions
}

export default connect(mapStateToProps, mapDispatchToProps)(Index)

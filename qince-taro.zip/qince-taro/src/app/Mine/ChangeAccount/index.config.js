export default definePageConfig({
  navigationBarTitleText: '切换账号',
})
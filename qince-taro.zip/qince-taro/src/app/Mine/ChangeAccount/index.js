import Taro from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import { Page } from '@/components/Page'
import { View, Image } from '@tarojs/components'

import * as actions from '@/store/Mine'
import { styled } from 'linaria/react'

const StyledPage = styled(Page)`
  .list-wrap {
    .item {
      background-color: #fff;
      padding: 12px 30px 12px 12px;
      justify-content: space-between;
      align-items: center;
      position: relative;

      .selected-icon {
        position: absolute;
        right: 8px;
        top: 22px;
      }

      .left {
        .code-area {
          font-size: 16px;
          color: #1a1c1f;
        }

        .dept-area {
          font-size: 14px;
          color: #42474d;
        }
      }

      .right {
        .flag {
          font-size: 12px;
          color: #ff9008;
          background: #fff4e6;
          border-radius: 2px;
          padding: 2px 4px;
        }
      }
    }
  }
`

const Index = ({ userInfo, dispatchAccountList, dispatchGetUserInfo, dispatchSwitchAccount }) => {
  const [selected] = useState(userInfo)
  const [list, setList] = useState({})

  useEffect(() => {
    if (userInfo) {
      let params = {
        mobile: userInfo.mobile
      }
      dispatchAccountList(params).then(res => {
        if (res.code === '1') {
          setList(res?.data || [])
        } else {
          Taro.showToast({
            mask: true,
            icon: 'none',
            text: res.message
          })
        }
      })
    }
  }, []) // eslint-disable-line

  const handleChange = item => {
    // 切换账号  刷新token
    let params = {
      tenantCode: item.tenantCode,
      userCode: item.code
    }

    dispatchSwitchAccount(params).then(res => {
      if (res.code === '0') {
        if (res.xToken) {
          Taro.setStorage({ key: 'x-token', value: res.xToken })
          dispatchGetUserInfo()
          Taro.navigateBack()
        }
      } else {
        Taro.showToast({
          mask: true,
          icon: 'none',
          text: res.message
        })
      }
    })
  }

  return (
    <StyledPage>
      <Page>
        <View className="list-wrap">
          <View className="item flex border-b">
            <View className="left">
              <View className="code-area">{userInfo.code}</View>
              <View className="dept-area">{userInfo.deptName}</View>
            </View>
            <View className="right">
              <View className="flag">手机号已认证</View>
            </View>
            {selected.code === userInfo.code && (
              <View className="selected-icon">
                <Image
                  style={{ width: '16px', height: '13px' }}
                  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAnCAYAAABEz7vjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAAJwAAAACuw5CWAAAB5UlEQVRoBe3YPU7DMBQHcL8AEi0SDL1A2TqxMHTjHEggRlhgYmLrIRgoC4gPCcE5GBhYOAEXYClqQUD6yD+qi2KS5ssfidS3tHZi9/1it3YtxDyq9wQGp50WX22sxGXmxVXWoQ6o5tLnA38MbuJwVAeEmqNEkeAOrpGgJ2qs7tLey1DeWzuYivqDRHG1mopJKOBYcNcfDa6Ze6GpNrBZqMmosfDEPVFvjHItpmIWFBMdL+6/3k2Q1YcVQVV+xIqiKg0rg6osrCyqkjAdKMAiP/d80V7m/mYTF1yELhRyn8KAGn+JS1+83brA6UQBFq5jEhWs31uo5GDvtSBaO3TwPELZdOhGIV9SURJhC2cCBYOH6SdHSqLwGuycu6anpSkU8vcE0yPexIVJnEkULOF3zD9bPxI0PonDoU73tDSNQs7TTbAtnA1UBIaCaZwt1D9YFlz4N7zAUmATFQszgbONSoTpxLlAzYTpwLlCpcLK4FyiMsGK4FyjMsPy4N6/hw2c0MrDTLRVgtWDF+W6luJ0gc7SW9o6h6UgOPtac42CJRcMDdJwuCchrIyU/OzcMDQsgLOKQo6FYDlx1lGlYBlxTlClYSk4ZygtsAScU5Q2mIJzjkI+WsPvrx/+nLe3tXY67yz6BH4BkmC3qkLjhGEAAAAASUVORK5CYII="
                  alt=""
                ></Image>
              </View>
            )}
          </View>
          {list?.map(item => (
            <View key={item.id} className="item flex border-b" onClick={() => handleChange(item)}>
              <View className="left">
                <View className="code-area">{item.code}</View>
                <View className="dept-area">{item.dept}</View>
              </View>
              <View className="right">
                <View className="flag">手机号已认证</View>
              </View>
              <View className="selected-icon" v-if="selected.code === item.code">
                <Image
                  style={{ width: '16px', height: '13px' }}
                  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAnCAYAAABEz7vjAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAANqADAAQAAAABAAAAJwAAAACuw5CWAAAB5UlEQVRoBe3YPU7DMBQHcL8AEi0SDL1A2TqxMHTjHEggRlhgYmLrIRgoC4gPCcE5GBhYOAEXYClqQUD6yD+qi2KS5ssfidS3tHZi9/1it3YtxDyq9wQGp50WX22sxGXmxVXWoQ6o5tLnA38MbuJwVAeEmqNEkeAOrpGgJ2qs7tLey1DeWzuYivqDRHG1mopJKOBYcNcfDa6Ze6GpNrBZqMmosfDEPVFvjHItpmIWFBMdL+6/3k2Q1YcVQVV+xIqiKg0rg6osrCyqkjAdKMAiP/d80V7m/mYTF1yELhRyn8KAGn+JS1+83brA6UQBFq5jEhWs31uo5GDvtSBaO3TwPELZdOhGIV9SURJhC2cCBYOH6SdHSqLwGuycu6anpSkU8vcE0yPexIVJnEkULOF3zD9bPxI0PonDoU73tDSNQs7TTbAtnA1UBIaCaZwt1D9YFlz4N7zAUmATFQszgbONSoTpxLlAzYTpwLlCpcLK4FyiMsGK4FyjMsPy4N6/hw2c0MrDTLRVgtWDF+W6luJ0gc7SW9o6h6UgOPtac42CJRcMDdJwuCchrIyU/OzcMDQsgLOKQo6FYDlx1lGlYBlxTlClYSk4ZygtsAScU5Q2mIJzjkI+WsPvrx/+nLe3tXY67yz6BH4BkmC3qkLjhGEAAAAASUVORK5CYII="
                  alt=""
                ></Image>
              </View>
            </View>
          ))}
        </View>
      </Page>
    </StyledPage>
  )
}
const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions
}

export default connect(mapStateToProps, mapDispatchToProps)(Index)

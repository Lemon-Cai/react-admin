export default definePageConfig({
  navigationBarTitleText: '修改密码',
})
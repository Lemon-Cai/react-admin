import Taro from '@tarojs/taro'
import { useState } from 'react'
import { connect } from 'react-redux'
import { View } from '@tarojs/components'

import { Cells, Cell, CellHeader, CellBody } from '@/components/Cell'
import { Page } from '@/components/Page'
import { Input } from '@/components/Input'
import { Button } from '@/components/Button'

import { styled } from 'linaria/react'
import * as actions from '@/store/Mine'
import { dispatchInit } from '@/store/Home'

import passwordUtils from '@/utils/password'

const StyledPage = styled(Page)`
  .label-top {
    display: block;
  }
  .flex {
    display: flex;
    .icon {
    }
  }
  .flex-middle {
    align-items: center;
  }
  .flex-between {
    justify-content: space-between;
  }
  .submit-box {
    padding: 20px;
  }
`

const Index = ({ userInfo, dispatchChangePassword, dispatchInitHome }) => {
  const [formData, setFormData] = useState({})

  const handleChange = (val, e) => {
    setFormData({ ...formData, [e.target.id]: val })
  }

  const handleSubmit = () => {
    if (!_validate(formData)) {
      return
    }

    let params = {
      oldPassword: formData.password,
      password: formData.newPassword,
      confpwd: formData.confirmPassword
    }
    dispatchChangePassword(params).then(res => {
      if (res.error) {
        Taro.showToast({
          mask: true,
          title: res.error,
          icon: 'none'
        })
      } else {
        dispatchInitHome()
        Taro.removeStorageSync('qince-token')
        Taro.showModal({
          content: '新密码设置成功，您需要重新登录',
          showCancel: false,
          confirmText: '确定',
          success: () => {
            Taro.redirectTo({
              url: '/pages/Login/index'
            })
          }
        })
      }
    })
  }

  // 输入密码校验
  const _validate = params => {
    if (!params.password) {
      Taro.showToast({
        mask: true,
        title: '请输入原密码！',
        icon: 'none'
      })
      return
    }

    if (!params.newPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入新密码！',
        icon: 'none'
      })
      return
    }
    if (!params.confirmPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入确认新密码！',
        icon: 'none'
      })
      return
    }
    let result = passwordUtils.checkPassword(params.newPassword)
    if (!result.success) {
      // 低强度走之前校验
      Taro.showToast({
        mask: true,
        title: result.msg,
        icon: 'none'
      })
      return
    }
    if (params.newPassword !== params.confirmPassword) {
      Taro.showToast({
        mask: true,
        title: '新密码和确认新密码不一致！',
        icon: 'none'
      })
      return
    }
    return true
  }

  return (
    <StyledPage>
      <Cells>
        <Cell className="label-top">
          <CellHeader>原密码</CellHeader>
          <View className="flex flex-middle flex-between">
            <CellBody>
              <Input
                clear
                showEye
                password
                type="password"
                name="password"
                value={formData.password}
                placeholder="请输入原密码"
                onChange={handleChange}
              />
            </CellBody>
          </View>
        </Cell>
        <Cell className="label-top">
          <CellHeader>新密码</CellHeader>
          <View className="flex flex-middle flex-between">
            <CellBody>
              <Input
                clear
                showEye
                password
                type="password"
                name="newPassword"
                value={formData.newPassword}
                placeholder="请输入新密码"
                onChange={handleChange}
              />
            </CellBody>
          </View>
        </Cell>
        <Cell className="label-top">
          <CellHeader>确认密码</CellHeader>
          <View className="flex flex-middle flex-between">
            <CellBody>
              <Input
                clear
                showEye
                password
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                placeholder="再次确认新密码"
                onChange={handleChange}
              />
            </CellBody>
          </View>
        </Cell>
      </Cells>
      <View>{userInfo?.pwdStrengthMsg}</View>
      <View className="submit-box">
        <Button gradients={['#FF5E3A', '#FF9500']} type="primary" onClick={handleSubmit}>
          提交
        </Button>
      </View>
    </StyledPage>
  )
}

const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions,
  dispatchInitHome: dispatchInit
}

export default connect(mapStateToProps, mapDispatchToProps)(Index)

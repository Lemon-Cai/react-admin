import Taro from '@tarojs/taro'

export function toast ({ title = '', icon = 'none', duration = 2000, ...others }) {
  Taro.showToast({
    title: title,
    icon: icon,
    duration: duration,
    ...others
  })
}

export function confirm ({ title = '', content, onOk, onCancel }) {
  Taro.showModal({
    title: title,
    content: content,
    success: function (res) {
      if (res.confirm) {
        onOk && onOk()
      } else if (res.cancel) {
        onCancel && onCancel()
      }
    }
  })
}
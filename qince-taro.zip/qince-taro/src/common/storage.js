import Taro from '@tarojs/taro'

export default {
  getStorage(key) {
    try {
      return Taro.getStorage(key)
    } catch (e) {}
  },
  setStorage(key, value) {
    Taro.setStorage({
      key: key,
      data: value
    })
  },
  getStorageSync(key) {
    try {
      return Taro.getStorageSync(key)
    } catch (e) {}
  },
  setStorageSync(key, value) {
    try {
      Taro.setStorageSync(key, value)
    } catch (e) {}
  }
}

import Taro, { getCurrentInstance } from '@tarojs/taro'
import { useState, useEffect } from 'react'

import { View, Image, Button } from '@tarojs/components'
import { connect } from 'react-redux'
import * as actions from '@/store/External'

import Logo from '@/assets/images/icon/authLogo.png'
import './login.less'

const Index = ({ dispatchExternalLogin }) => {
  const accountInfo = Taro.getAccountInfoSync()
  const appId = accountInfo.miniProgram.appId

  const [hasUseData, setHasUseData] = useState(false)

  const [url, setUrl] = useState('')
  const [_tenantId, setTenantId] = useState('')
  const [_userId, setUserId] = useState('')
  const [_useMiniProgramAbility, setUseMiniProgramAbility] = useState('')
  const [userInfo, setUserInfo] = useState('')

  useEffect(() => {
    const { router } = getCurrentInstance()
    const { redirectUrl, tenantId, userId, useMiniProgramAbility } = router.params
  
    setUrl(redirectUrl)
    setTenantId(tenantId)
    setUserId(userId)
    setUseMiniProgramAbility(useMiniProgramAbility || 'true')
  }, [])



  const handleExternalLogin = async params => {


    try {
      let result = await dispatchExternalLogin(params)
      if (result.code === '1') {
        Taro.setStorageSync('e_token', result.data.token || '')
        Taro.navigateTo({
          url: `/app/Webview/index?url=${encodeURIComponent(
            result.data.appsvrBizUrl.includes('?')
              ? `${result.data.appsvrBizUrl}&token=${result.data.token}&corpId=ww94b1f6c5820ebec9&appid=${appId}`
              : `${result.data.appsvrBizUrl}?token=${result.data.token}&corpId=ww94b1f6c5820ebec9&appid=${appId}`
          )}`
        })
      } else {
        Taro.showToast({
          mask: true,
          icon: 'none',
          title: result.message || '外部帐号登录失败',
        })
      }
    } catch (e) {
      this.loaded()
      this.placeholder = false
      Taro.showToast({
        title: e.message || e.error,
        mask: true,
        icon: 'none'
      })
    }
  }

  const onGetPhoneNumber = e => {
    if (e.detail.iv) {
      Taro.login().then(res => {
        const code = res.code
        handleExternalLogin({
          ...e.detail,
          code: code,
          userId: _userId,
          tenantId: _tenantId,
          redirectUrl: url,
          nickName: userInfo.nickName,
          useMiniProgramAbility: _useMiniProgramAbility,
          appId
        })
      })
    } else {
      Taro.showToast({
        title: '由于您拒绝授权，您将无法使用勤策小程序的相关功能',
        icon: 'none'
      })
    }
  }

  const onGetUserInfo = async () => {
    try {
      let result = await Taro.getUserProfile({ desc: '获取用户信息展示' })
      if (result.rawData) {
        setUserInfo(result.userInfo)
        setHasUseData(true)
      }
    } catch (err) {
      console.log(err)
    }
  }

  return (
    <View className="index">
      <View className="logo-area">
        <Image className="wq-placeholder-icon" src={Logo} />
      </View>
      <View className="text">
        {!hasUseData
          ? '您正在访问勤策小程序，我们需要获取您的微信公开信息，点击下方按钮进行授权'
          : '您正在访问勤策小程序，我们需要获取您的手机号，点击下方按钮进行授权'}
      </View>
      <View className="confirm-btn">
        {!hasUseData ? (
          <Button className="btn" onClick={onGetUserInfo}>
            授权获取
          </Button>
        ) : (
          <Button className="btn" openType="getPhoneNumber" onGetPhoneNumber={onGetPhoneNumber}>
            确认访问
          </Button>
        )}
      </View>
    </View>
  )
}

const mapDispatchToProps = {
  ...actions
}

export default connect(null, mapDispatchToProps)(Index)

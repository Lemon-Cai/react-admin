import { createContext } from 'react'

export const headerContext = createContext(null)
export const bodyContext = createContext(null)

headerContext.displayName = 'qinceAllCommonlyHeader'
bodyContext.displayName = 'qinceAllCommonlyBody'

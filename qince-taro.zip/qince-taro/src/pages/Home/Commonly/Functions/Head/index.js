import { useContext } from 'react'
import { View } from '@tarojs/components'
import { styled } from 'linaria/react'

import { Card, CardHeader, CardTitle, CardBody } from '@/components/Card'
import { Grid, GridItem } from '@/components/Grid'
import { Icons } from '@/components/Icons'

import { headerContext } from '../context'

import CommonlyJump from '../../../utils/CommonlyJump'

const StyledEdit = styled(View)`
  color: ${props => (props.editable ? '#ff9008' : '#0277fb')};
`

const StyledTip = styled(View)`
  font-size: 14px;
  padding: 0px 12px;
  color: #8c8c8c;
`

const StyledCard = styled(Card)`
  box-shadow: 0px 2px 34px -6px rgba(0, 0, 0, 0.06);
  padding: 0;
  .qince-card-header {
    padding: 12px;
  }
  .qince-card-title {
    font-size: 15px;
    color: #35393e;
  }
  .qince-card-body {
    padding: 0 0 8px 0;
  }
  .weui-grid {
    padding: 12px 4px;
  }
  .weui-grid__icon {
    width: 40px;
    height: 40px;
  }
  .weui-grid__label {
    font-size: 13px;
    color: #191c1f;
  }
`
// 全部功能 -> 我的常用
const Header = () => {
  return (
    <StyledCard>
      <CardHeader>
        <CardTitle>我的常用功能</CardTitle>
        <CardEdit />
      </CardHeader>
      <StyledTip>管理员推荐功能置顶显示，无法移除和排序</StyledTip>
      <CardBody>
        <GridCard />
      </CardBody>
    </StyledCard>
  )
}

// 渲染GridItem
const GridCard = () => {
  const {
    // 我的常用menuList
    list = [],
    // 启用编辑
    editable = false,
    // 删除常用功能item事件
    onRemoveMenu = () => {}
  } = useContext(headerContext)

  // 点击我的常用item 跳转
  const handleGridItem = (e, item) => {
    !editable && CommonlyJump(item)
  }

  return (
    <Grid column={4} gap={8} hasBorder={false}>
      {(list || []).map((item, index) => {
        return (
          <GridItem
            key={item.id || index}
            label={item.name || ''}
            icon={
              item.icon
                ? `https://res.waiqin365.com/d/${item.icon}`
                : 'https://res.waiqin365.com/d/icon/default_icon.png'
            }
            badge={
              editable && item?.isRecommend !== '1' ? (
                <Icons
                  value="minus-circle-fill"
                  style={{ color: '#fa5151', fontSize: '24px' }}
                  onClick={e => onRemoveMenu(e, item, index)}
                />
              ) : (
                ''
              )
            }
            onClick={e => handleGridItem(e, item)}
          ></GridItem>
        )
      })}
    </Grid>
  )
}

// 编辑状态切换
const CardEdit = () => {
  const {
    // 启用编辑
    editable = false,
    // 启用编辑事件
    onToggleEdit = () => {}
  } = useContext(headerContext)

  // 点击编辑
  const handleClickEdit = () => {
    onToggleEdit(editable ? 'finish' : '')
  }

  return (
    <StyledEdit editable={editable} onClick={handleClickEdit}>
      {editable ? '完成' : '编辑'}
    </StyledEdit>
  )
}

export default Header

export default definePageConfig({
  navigationBarTitleText: '全部功能'
})
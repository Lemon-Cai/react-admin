import React, { useContext } from 'react'
import { View, Image } from '@tarojs/components'
import { styled } from 'linaria/react'

import { Cells, CellsTitle, Cell, CellHeader, CellBody, CellFooter } from '@/components/Cell'

import { bodyContext } from '../context'

import CommonlyJump from '../../../utils/CommonlyJump'

const StyledIcon = styled(Image)`
  display: block;
  width: 22px;
  height: 22px;
  margin-right: 8px;
`

const StyledEdit = styled(View)`
  border: ${props => (props.readOnly ? '' : '1px solid #ff9008')};
  width: 45px;
  height: 24px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 12px;
  border-radius: 3px;
  color: ${props => (props.readOnly ? '' : '#ff9008')};
`

// 我的常用功能-全部功能-全部菜单列表
const Body = () => {
  const { list } = useContext(bodyContext)

  return (list || []).map((item = {}, index) => {
    const { menuList = [], name = '' } = item
    return (
      <React.Fragment key={index}>
        <CellsTitle>{name}</CellsTitle>
        <Cells>
          {menuList?.map((menuItem, idx) => {
            return <Menu key={menuItem?.menuId || idx} menuItem={menuItem} />
          })}
        </Cells>
      </React.Fragment>
    )
  })
}

// 每一行
const Menu = ({ menuItem }) => {
  const {
    // 启用编辑
    editable = false,
    // 我的常用项
    myFeatures = [],
    // 添加菜单
    onAddMenu = () => {}
  } = useContext(bodyContext)

  // 是否已存在
  const hasExist = myFeatures.some(o => o?.id === menuItem?.id)

  // 打开菜单
  const handleClick = () => {
    !editable && CommonlyJump(menuItem)
  }

  // 添加常用菜单
  const handleAddMenuItem = item => {
    if (!hasExist) {
      onAddMenu(item)
    }
  }

  return (
    <Cell access={!editable} onClick={handleClick}>
      <CellHeader>
        <StyledIcon
          className="icon"
          src={
            menuItem.icon
              ? `https://res.waiqin365.com/d/${menuItem.icon}`
              : 'https://res.waiqin365.com/d/icon/default_icon.png'
          }
          mode="scaleToFill"
        />
      </CellHeader>
      <CellBody>{menuItem?.formatName || menuItem?.name}</CellBody>
      <CellFooter>
        {editable && (
          <StyledEdit readOnly={hasExist} onClick={() => handleAddMenuItem(menuItem)}>
            {hasExist ? '已添加' : '添加'}
          </StyledEdit>
        )}
      </CellFooter>
    </Cell>
  )
}

export default Body

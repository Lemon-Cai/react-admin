import React, { useState, useEffect, useRef } from 'react'
import PinyinMatch from 'pinyin-match'
import { getCurrentPages } from '@tarojs/taro'
import { View, Text, Input } from '@tarojs/components'
import { styled } from 'linaria/react'

import fetch from '@/utils/request'

import { Page, PageBody } from '@/components/Page'
import { Space } from '@/components/Space'
import { Icons } from '@/components/Icons'
import { Empty } from '@/components/Empty'

import { headerContext, bodyContext } from './context'

import Header from './Head'
import Body from './Body'

const ShowStyled = styled(View)`
  display: ${props => (props?.show ? 'inline' : 'none')};
`

const FlexStyled = styled(View)`
  display: flex;
  align-items: center;
  .qince-cancel {
    color: #f09638;
    margin-right: 8px;
  }
`

const StyledHighlight = styled(Text)`
  color: #ff9008;
`

const StyledInput = styled(View)`
  border-radius: 4px;
  background-color: #fff;
  display: flex;
  flex: 1;
  align-items: center;
  padding: 4px 8px;
  margin: 8px;
  .qince-icon-search {
    color: #999;
    font-size: 12px;
    margin-right: 8px;
  }

  .qince-icon-clear {
    color: #ccc;
    z-index: 99;
    margin-left: 8px;
  }

  input {
    padding: 4px 0;
    width: 100%;
    height: 1.42857143em;
    border: 0;
    font-size: 14px;
    line-height: 1.42857143em;
    box-sizing: content-box;
    background: transparent;
  }
`
// 全部功能
const Functions = () => {
  // 常用id
  const [usualId, setUsualId] = useState('')
  // 是否编辑
  const [editable, setEditable] = useState(false)
  // 全部菜单
  const [allFeatures, setAllFeatures] = useState([])
  // 我的常用菜单list
  const [menuList, setMenuList] = useState([])
  // 是否聚焦
  const [isFocus, setIsFocus] = useState(false)
  // 筛选后的菜单
  const [filterFeatures, setFilterFeatures] = useState([])
  // 搜索值
  const [searchVal, setSearchVal] = useState('')

  const { eventChannel, success } = useEventChannel(null)

  // 页面重新消息
  useDidUpdateEffect(() => {
    eventChannel.on('_props', _props => {
      setAllFeatures(_props.allFeatures)
      setMenuList(_props.menuList.map(item => ({ ...item, id: item?.menuId })))
      setUsualId(_props.usualId)
      setEditable(_props.isEditable)
    })
  }, [success]) // eslint-disable-line

  // 启用编辑/编辑换成
  const handleToggleEdit = type => {
    switch (type) {
      case 'finish':
        dispatchChangeCommonly(usualId, menuList, eventChannel)
      default:
        setEditable(!editable)
        break
    }
  }

  // 删减部分常用
  const handleRemoveMenu = (e, item) => {
    e.stopPropagation()
    const _menuList = menuList?.filter(o => o?.id !== item.id)
    setMenuList(_menuList)
  }

  // 添加到我的常用项
  const handleAddMenu = item => {
    setMenuList([...menuList, item])
  }

  const handleInputChange = e => {
    const val = e.target.value
    setSearchVal(val)
    // 并发更新
    React.startTransition(() => {
      const _filterFeatures = allFeatures
        .map(feature => {
          const _filter = []
          feature?.menuList?.forEach(item => {
            let position = PinyinMatch.match(item?.name, val)
            if (position) {
              _filter.push({
                ...item,
                formatName: (
                  <>
                    {item.name.slice(0, position[0])}
                    <StyledHighlight>
                      {item.name.slice(position[0], position[1] + 1)}
                    </StyledHighlight>
                    {item.name.slice(position[1] + 1)}
                  </>
                )
              })
            }
          })
          if (_filter.length) {
            return { ...feature, menuList: _filter }
          }
          return null
        })
        .filter(o => !!o)
      setFilterFeatures(_filterFeatures)
    }, 1000)
  }

  // 聚焦
  const handleFocus = () => {
    setIsFocus(true)
  }

  // 取消
  const handleCancel = () => {
    setIsFocus(false)
    setSearchVal('')
    setFilterFeatures([])
  }

  // 清空
  const handleClear = () => {
    setSearchVal('')
    setFilterFeatures([])
  }

  if (!usualId) return
  return (
    <Page>
      <FlexStyled>
        <StyledInput>
          <Icons value="search" />
          <Input
            alwaysSystem
            value={searchVal}
            placeholder="搜索功能"
            placeholderStyle="font-size: 13px;"
            onFocus={handleFocus}
            onInput={handleInputChange}
          />
          <ShowStyled show={!!searchVal}>
            <Icons value="clear" color="#ccc" onClick={handleClear} />
          </ShowStyled>
        </StyledInput>
        <ShowStyled show={isFocus}>
          <View className="qince-cancel" onClick={handleCancel}>
            取消
          </View>
        </ShowStyled>
      </FlexStyled>
      <PageBody>
        <ShowStyled show={!isFocus}>
          <Space block direction="vertical">
            <headerContext.Provider
              value={{
                editable,
                list: menuList,
                onToggleEdit: handleToggleEdit,
                onRemoveMenu: handleRemoveMenu
              }}
            >
              <Header />
            </headerContext.Provider>
          </Space>
        </ShowStyled>
        <ShowStyled show={!!searchVal && filterFeatures?.length === 0}>
          <Space block direction="vertical">
            <Empty description="无搜索结果" />
          </Space>
        </ShowStyled>
        <Space block direction="vertical">
          <bodyContext.Provider
            value={{
              editable,
              list: isFocus ? filterFeatures : allFeatures,
              myFeatures: menuList,
              onAddMenu: handleAddMenu
            }}
          >
            <Body />
          </bodyContext.Provider>
        </Space>
      </PageBody>
    </Page>
  )
}

// 添加常用项到我的常用
const dispatchChangeCommonly = (usualId, menuList, eventChannel) => {
  const fetchObj = {
    url: '/workbench/icard/menu/datachange.do',
    params: {
      hideList: [],
      icardId: usualId,
      showList: menuList?.map(o => o?.id)
    }
  }
  fetch(fetchObj).then(result => {
    if (result?.code === '1') {
      // 持续监听页面重新消息
      eventChannel.emit('_props', { menuList: menuList })
    }
  })
}

const useEventChannel = () => {
  const [value, setValue] = useState('')
  const [success, setSuccess] = useState('')
  useEffect(() => {
    // 持续监听页面重新消息
    const pages = getCurrentPages()
    const current = pages[pages.length - 1]
    const eventChannel = current.getOpenerEventChannel()
    setValue(eventChannel)
    setSuccess('true')
  }, []) // eslint-disable-line
  return { eventChannel: value, success: success }
}

// 自定义hook 初始化不调用
function useDidUpdateEffect(fn, inputs) {
  const didMountRef = useRef(false)
  useEffect(() => {
    if (didMountRef.current) fn()
    else didMountRef.current = true
  }, inputs) // eslint-disable-line
}

export default Functions

import { useState, memo } from 'react'
import Taro from '@tarojs/taro'
import { styled } from 'linaria/react'

import { Card, CardHeader, CardTitle, CardBody } from '@/components/Card'
import { Grid, GridItem } from '@/components/Grid'

import CommonlyJump from '../utils/CommonlyJump'

const StyledCard = styled(Card)`
  box-shadow: 0px 2px 34px -6px rgba(0, 0, 0, 0.06);
  padding: 0;
  .qince-card-header {
    padding: 12px;
  }
  .qince-card-title {
    font-size: 15px;
    color: #35393e;
  }
  .qince-card-body {
    padding: 0 0 8px 0;
  }
  .weui-grid {
    padding: 12px 4px;
  }
  .weui-grid__icon {
    width: 40px;
    height: 40px;
  }
  .weui-grid__label {
    font-size: 13px;
    color: #191c1f;
  }
`

export default memo(({ usualFeatures = {}, allMenuList = [] }) => {
  const [_usualFeatures, setUsualFeatures] = useState(() => usualFeatures)

  const { menuList = [] } = _usualFeatures

  // 前往全部页面
  const handleToAll = flag => {
    Taro.navigateTo({
      url: '/pages/Home/Commonly/Functions/index',
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('_props', {
          allFeatures: allMenuList,
          menuList: menuList,
          usualId: _usualFeatures?.id || '',
          isEditable: flag
        })
      },
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        _props: function(data) {
          const { menuList: menus = [] } = data
          setUsualFeatures(pre => ({ ...pre, menuList: menus }))
        }
      }
    })
  }

  // 点击跳转菜单
  const handleGridItem = item => {
    CommonlyJump(item)
  }

  return (
    <StyledCard>
      <CardHeader>
        <CardTitle>我的常用功能</CardTitle>
      </CardHeader>
      <CardBody>
        <Grid column={4} gap={8} hasBorder={false}>
          {(menuList || []).map((item, index) => {
            return (
              <GridItem
                key={item.id || index}
                label={item.name || ''}
                icon={
                  item.icon
                    ? `https://res.waiqin365.com/d/${item.icon}`
                    : 'https://res.waiqin365.com/d/icon/default_icon.png'
                }
                onClick={() => handleGridItem(item)}
              />
            )
          })}
          <GridItem
            label="添加"
            icon="https://res.waiqin365.com/d/icon/add.png"
            onClick={() => handleToAll(true)}
          />
          <GridItem
            label="全部功能"
            icon="https://res.waiqin365.com/d/icon/merge.png"
            onClick={() => handleToAll(false)}
          />
        </Grid>
      </CardBody>
    </StyledCard>
  )
})

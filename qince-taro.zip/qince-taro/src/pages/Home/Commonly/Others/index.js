import { useState } from 'react'
import { styled } from 'linaria/react'
import { setNavigationBarTitle } from '@tarojs/taro'
import { Image } from '@tarojs/components'

import { Card, CardBody } from '@/components/Card'
import { Grid, GridItem } from '@/components/Grid'
import { Page, PageHeader, PageBody } from '@/components/Page'

import { useUpdateEffect, useEventChannel } from '../../utils/hooks'

import CommonlyJump from '../../utils/CommonlyJump'

const StyledCard = styled(Card)`
  box-shadow: 0px 2px 34px -6px rgba(0, 0, 0, 0.06);
  padding: 0;
  .qince-card-header {
    padding: 12px;
  }
  .qince-card-title {
    font-size: 15px;
    color: #35393e;
  }
  .qince-card-body {
    padding: 0px;
  }
  .weui-grid {
    padding: 12px 4px;
  }
  .weui-grid__icon {
    width: 40px;
    height: 40px;
  }
  .weui-grid__label {
    font-size: 13px;
    color: #191c1f;
  }
`

export default () => {
  const [menuList, setOthersMenuList] = useState([])

  const { eventChannel, success } = useEventChannel()

  // 持续监听页面重新消息
  useUpdateEffect(() => {
    eventChannel.on('_props', _props => {
      const { othersMenuList = [], title } = _props
      setOthersMenuList(othersMenuList)
      setNavigationBarTitle({ title: title })
    })
  }, [JSON.stringify(success)]) // eslint-disable-line

  // 点击跳转菜单
  const handleGridItem = item => {
    item?.url && CommonlyJump(item)
    // if (item?.url) {
    //   if (
    //     item.url.indexOf('.html') !== -1 ||
    //     item.url.indexOf('.action') !== -1 ||
    //     item.url.indexOf('.do') !== -1
    //   ) {
    //     let menuId = getParameter('menuId', item.url)
    //     if (menuId) {
    //       // this.$http.saveMenuLog({menuId: menuId})
    //       const params = { menuId }
    //       fetch({
    //         url: '/client/saveMenuLog.action',
    //         params,
    //         header: {
    //           'Content-Type': 'application/x-www-form-urlencoded'
    //         }
    //       })
    //     }
    //     jump({
    //       url: `${item.url}${(item.url.indexOf('?') !== -1 ? '&' : '?') + 't=' + +new Date()}`,
    //       title: item.name
    //     })
    //   } else {
    //     if (item.url.indexOf('schedule/attandence/index')) {
    //       // this.$store.commit('SET_ACTIVE_TAB', 0)
    //     }
    //     jump({
    //       url: item.url,
    //       title: item.name
    //     })
    //   }
    // } else {
    // }
  }

  return (
    <Page>
      <PageHeader style={{ backgroundColor: '#5076b7', height: 120 }}>
        <Image
          style={{
            height: '100%',
            width: '100%',
            height: 120,
            backgroundRepeat: 'no-repeat',
            objectFit: 'fill'
          }}
          mode="aspectFill"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAu4AAAEYCAMAAAA04INhAAAAmVBMVEUAAADO4PX////////R5fr0+vrL3/bR4vj////1+f/////N4ff////N4Pb////R4fb////////e7//////Q4vb////5/P/////R4/b////////Q4vfO4vX////P4vXP4vb////3+v7////Q4fb////P4fbP4ffR4/b////////R5fj////////////////K3/XK3vXP4fX///9CnehHAAAAMHRSTlMASbNfGgfmQ5wSfHaNpkVPMqcMvrxrJFDnVa1goHE35Cwdholk835WlNJr6z873dDZp8NBAAAOCUlEQVR42uzdbW+iQBSG4ZNDRxlKCWAcAxEDpJo1rdX4/3/cbm1FVLbq6kbnzHN9aZrw5aR36MiLQwAAAAAAAAAAAAAAAHBSOltOV6dNl7OUAOzW740n53ScTsa9PgHYrH9Bw330DlZLLyq438N6Biw2G9MlxjMCsNZyQpeYLAnAWtOULpFOCcBaq4uPB7AWcgeHIHdwCHIHhyB3cAhyB4cgd3AIcgeHdOWrvQi5g0Qd+Zp1MaiROwjUkW+QEX0gdxCoI98ioJKROwjUka9OeG2QOwh0nG+UV+TVtFW+sYfcQYajfBd5RUR+RF/0PNbrCLmDCIf5xrmhP0yuacMw0dBD7iDCQb4mL2mjWc7Mw9d1hdxBhHa+2TwZxLSxW84UfqCxdgcZWvm+z6tondJGs5ypA1yZcZpaFLWfsBAr3kj8uqgLosQQUWs5E9S4EOkyE+QsyYobg3XiDxQ1/IiKUCF3d+mCmcNRWSkS4jtfVZWjcPDx0V6nm7z4pXCbyV1xwrmnSZJ2vtrLOYmpMfQV7qq6a8QcyIr9MF8dMGd43h2+as9ImsN8M+YMuQPFzO8kzlG+C+YYuTtPJwLP7fv5RoNP87e3wb4IuVvl6aW3+lnv5Yl+VnBAAnXkG3CBs7vFnnrPT6cOee79fIjhXNqn1L/lq3M2yN1eL8902vML/SRgjyTqytfjALnbq/d01r8A+oHKWeTJvTNfzblC7tZaXX/UgkMSqXPqkBfI3Vo3yL3gEYnUOfWIC+RurRvkXnNJInVOXTK+Z8ZeN8jd54pE6py6Yh+5W2tFB6r3kRfF6oI/ZMJinoE8Y28mxQn2ZrLWfsjKS5Kg8IqQw/Ls3JlJpuWke1zsvGetvZCjvDC0kUZJOPTunXsW5vxP8jD7b/uqMmNfVWu1Qy4Gpt3a/N6514FR9E+UCer/tWs2M3bNtlYr5GGS0o7n3Tv3LKArBBldrd/VO/Nfj4VHtwt55Kvvzr9/eHTf3ENDVzAh3aL38SQ9Y9x0MkbtNmhCTvOKNnaZ61d1z9wTRVdIE7qBdLacrk6bLmdYydigCfl1SPu53/3KzAOc3Z26EOWCJuTEHOduErfX7shdmm3Ixqfj3Ok9dfnKDHIXZxtyFHTlniqXr7sjd3FW27KG9C1iTVvDzOW7qhhXnCb3V9oqck/RF2OQu+PjytJazDSqIIloQ2vk7vi4smxDLn1qMeHXr79K5O74uLI0Ieea2hb0KXb6iUiMK04TcvFKR7RB7q6PK0sTcpVrOqBy5O78uLLsQvbejnJXbr/egXHFaYX8K6A970WK3J0fV5ZWyCqsNe2UC0XI3flxZdkL2dvdYFKJJtffVcW44uyHXBVf72QHIx3f/QHgB+XYuLIchpzGn7lH6QM87/6gHBtXlq6QH+T1jgfl2LiyIHfk7pBb5s6yIXf7XfH97ke5y+4AuQtw5u4dyB25S3Dm3kzIHbmLcN7Oe8gducNv9u52OWkgCsDwgUPS5bOBiBQUBY0fqJ0B7//iLMUBi0ASOTEk+74/2mmnc37sPNOBTbLAnXwL7uRRcCePgjt5FNzJo+BOHgV38ii4k0fBnTwK7uRRcCePgjt5FNzJo+BOHgV38ii4k0fBnf5HjXB9sbAhJ4M73CtYGudGKKeDezHcG+Hf/3DIqvW//gHci+G+133wLwT3KpaB+/rEbwjuVQzuuYN7dYN77uBe3eCeO7hXt8zcg0RVFxLBXQriPtLpvt4I7vvK4O7iLXedwV0K4j6cJU/N50nSSZpjuO8rg7uqSLvXa8NdCuI+nvxe56WTCdz3lcZ9pm24i8C9suXiHokq3AXulS0XdxFN4C4C96qWmXsS61Oxg7sUy3388yvcD5XEPXD6VBLAXQrlnsSL4QzuL+IyU2065j6IpK1w3wf3WnXEfRfc98G9VsE9Q9zvXpfgniWeZqpJcM8Uz6rWI7hfDu616gz3Odx3wb1WHTQnq86+2MF9F9xr1UFzkAwOBXDfBfdaVZWnmb582mzeisibzeXvQVtEDGYYDIH77fWfuLf64fpSnx5aF7m37u4bGbp7d/++IWIww3BIOnf7VQ37LaGyuLfC7uXlbz6ErbPcl8G7Rua+PdyJxQy7Ienc7Ve11Q3xXhr3fjf1xUy3f4776P2XRo6+vW+bzDAcks7dflW7faGSuIetVO6t8Bz3z/1Gru7FYoblkHTu9qva4t6D0rivM7xVXZ/j/upNPmXvxGKG+RB77usb2GOoWBXg/nCfT9mdWMywGAL3Wyv9wOvSuUsjZ2Ixw2II3G+t9I8zKJ37x7zKXpnMsBhSBvdHuF9T6dw3eZVtjGbYDymeezT82YF73ork3tZtcC+Ae/R1GDeXcM9ZodyHY1WNFe7W3KOvbjCczngxc0Xm3AcuEhF1uiudezevsjuTGeZD7LkfY/8ROP3xAe5XZM19spoHIuJW+lys7MxYcI96w4EEvbmMp3C/ImvuuvPt3O8f4W6wqostdpFOR8Qt4F5264N2t3Lbvn93z63gfuWq7rHLvBdI0AzgbpANd43VvWil7LtfuarxDruoC0SiHpeZSu/AXeVlquzMXLmq390kEJHJsC0imsC99I6563Nwt1nVqNMcyOOsLU/1IriX3hF3jXebMnA3ekfUflzMXu8mj+BeesfcD19V2Xe32IjUJJkvRF47bhErvzP/3dmINOM+HY+mbjbWOdzL7/Rrd/bd7bhPts6XGi/hXn6ndma4zGTJfdDhfveb6QJ39t15vKNu/XmZ6WUxOzNwr1uHpdfjuAEY7nWLp5ng7lEXlp773Tlnpm5xEgGniHkU3Dkj0qPgzgnAHsU5M5zv7lHszMDdozKdAAx3qkeZzneHO9WjTJ/ewb471aQsn83Ezgx5UrMpcCdfgvsv9u6wKVEwCsPwY/BqoCBUVtqawLqFbTXq//9xu65i2BrrcU+N8D73F53Z2fMBryk7IDKLWr3+3LszS1q9/tzMMEsid2ZRVdx/9GXI+j9UZmgMIXcm5f7UkSnrPKrM0BhC7kzKHa5MmQuNGRpDuJlhcu64lyC7BxRmqAwhd3YEdyN40/xoAIUZGkPInR3D3ZsEdwdB698Fk2tAYYbGEHJnx3DHxcPVrQvgdrFYVD1Orh4uACjM0BhC7uwf3JvtgNwZuTPLIndmUeTOLIrcmUWRO7MocmcWRe7MosidWRS5M4sid2ZR5M4sityZRZE7O50297yT1w5ccif3elXc0VSe22275E7utSro4ui6AbmTe61qu//zm4Hcyb1Wzf/rP5M7udcqcid3iyJ3crcocid3iyJ3de7Ccxz8tuCqyP00K3GXnePgd8FXRe6n2QHcg670tAYj99PsAO5tV3pag5H7aXYA97n48DJyP83IvQ6RO7lbFLmTu0XNUcqcO6Uicif3hjVHKefSKTVLyJ3cm9Uudwelhv6XcH/8sVh8A3C3qH40Hlbpz5APIfe6VsHdOzNfwN3t9FsH1LnvT1oAFGYoDNHjbqJwOAwjQ+6y9LkjCz+be2ruWwf3dNsBFGZoDNHhbm56Zz1/MPB/P9wYcpekz/0lj3bT5n4xeWwJepp40JihMUSDexj7z2YD/9mPQ3IXpM8d47xX7tVX5v4QtET1AZ0Z+kPk3E2WJyiV5Jkhd0Ea3KtyBsrcr+5kyu4BlRn6Q+TczSzDu8bnhtwV0uLuKHO/7cuUdQCNGfpD5NzN+RR/NZ0Zct+tSdzREgZozNAfIueejbGnLCP33ZrE/btU2RU0ZqgPkXMP87enyxDb8pDcyzWK+0KqbAGNGdpD5NxNnLw9fYkNipLYkHspcm8C9xsfRcMM2RDb/BtyF6TA/efyJ7l/LvfeMzZ5oxTpzEPRc4/cBSlwXy6XAK6dctefwr0rVdaBxgzlIXLuZn15RjLtjZZjAP7ZqDdNin8id0FKP93fc+dmRnEzE/UAwHsdRB7WeVH+un7ei8h9t8a8d7eVe+hjVTp6QdHLKMWf/JDcS5F7/bkPB/jT9SjCumh0jXWDIbm/1Sjutu7dC+5I42Szf0xB7ntqFHdbNzOhj02xh1VeDIBvZvbVoD9VbeUe9bDOXALwAFwaAPxTdU8NWkTayn27bUxjpOOzcYo4BbiI3F9jTjPZunffnmaKcn/kXDgjP454mumDmvPe3dbNzPYiguR1aACY4WvCiwj2Re5N4G7iBOV4idhHkXsDuCPMUYoXAH9Yk7jbuncHkGXY05gf73hXk7jbupkBYGYO/mp6zg/vVaTNPb90qrqckrsWd5jzMd6VzfjRbOWqX4KpU1VuyL0Ywhtv1DLZIeXevRjC2yrVMtkh5WZmE2+aV8/I/aghvCVqPSP3o4bwhtf1THZIuXcvhpB7LZMdUm5miiHkXsvIndwtityPG8Jvza5l3Lt/3d496EJSNwBrEnfLNjNuu+vi0Nxu2wUj99pyhxu054fWDqj9Vzt2rIIwEERR9BWrIhICIhIIJFUSsMv//5yVnURnGZD47mnSveoWmZVE7vvNHb92LKpWjry7k/uuNBdVuzS8zJD7rrw5nwK3FLmT+75snE/BWyqe+9TGImsnZWxkjJA7ork/TrHKTosyNjJGyB3R3FVilRUpYSNjhJcZxHPXEIlskJSwkTFC7qjI/RD4aV4OkhI2EkbIHTW5n8em/yq0tm/Gu6SEjYQRckdN7rrOt65I6tZ13fqOt/mql+SN+Ai541Pu/90BuYPcYYbcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcYYTcrTwBhsLg/AeTjf0AAAAASUVORK5CYII="
        />
      </PageHeader>
      <PageBody>
        <StyledCard>
          <CardBody>
            <Grid column={4} gap={8} hasBorder>
              {(menuList || []).map((item, index) => {
                return (
                  <GridItem
                    key={item.id || index}
                    label={item.name || ''}
                    icon={
                      item.icon
                        ? `https://res.waiqin365.com/d/${item.icon}`
                        : 'https://res.waiqin365.com/d/icon/default_icon.png'
                    }
                    onClick={() => handleGridItem(item)}
                  />
                )
              })}
            </Grid>
          </CardBody>
        </StyledCard>
      </PageBody>
    </Page>
  )
}

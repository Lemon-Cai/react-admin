const definePageConfig = ({
  backgroundTextStyle: 'light',
  navigationBarBackgroundColor: '#5076b7',
  navigationBarTitleText: '',
  navigationBarTextStyle: 'white'
})

export default definePageConfig

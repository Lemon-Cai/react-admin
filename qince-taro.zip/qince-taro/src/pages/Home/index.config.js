const definePageConfig = ({
  backgroundTextStyle: 'light',
  navigationBarBackgroundColor: '#f7f7f7',
  navigationBarTitleText: '工作台',
  navigationBarTextStyle: 'black'
})

export default definePageConfig

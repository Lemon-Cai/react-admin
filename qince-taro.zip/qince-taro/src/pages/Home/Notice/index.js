import { Card, CardHeader, CardTitle } from '@/components/Card'
import { Icons } from '@/components/Icons'

export default ({ bbsMessage }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{bbsMessage?.title}</CardTitle>
        <Icons value='arrow' />
      </CardHeader>
    </Card>
  )
}

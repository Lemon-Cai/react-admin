import React, { forwardRef, useImperativeHandle } from 'react'
import { ScrollView, View } from '@tarojs/components'
import Taro from '@tarojs/taro'

import fetch from '@/utils/request'
import { LoadMore } from '@/components/LoadMore'
import { styled } from 'linaria/lib/react'

import { useControllableValue } from '../../utils/hooks'

const EndMessageStyled = styled(View)`
  .end-message {
    font-size: 13px;
    padding: 12px;
    text-align: center;
    color: #aaa;
  }
`

// list列表
const ListScroll = (props, ref) => {
  const { url = '', rowKey = 'id', queryParams = {}, children } = props

  const [refreshing, setRefreshing] = React.useState(false)

  const [listParams, setListParams] = useControllableValue(props, {
    defaultValue: {
      page: 1,
      row: 20,
      hasMore: true,
      list: []
    }
  })

  let { page, row, list, hasMore } = listParams

  useImperativeHandle(ref, () => ({
    loadList: (flag = true) => handleRefresh(flag)
  }))

  // 触底下拉加载
  const handleScrollBottom = () => {
    if (hasMore) {
      _loadList()
    }
  }

  // 下拉刷新
  const handleRefresh = (flag = true) => {
    _loadList(flag)
  }

  React.useImperativeHandle(ref, () => ({
    loadList: flag => {
      _loadList(flag)
    }
  }))

  React.useEffect(() => {
    _loadList(true)
  }, []) // eslint-disable-line

  // 页面加载
  const _loadList = flag => {
    if (flag) {
      page = 1
    } else {
      page += 1
    }
    setRefreshing(true)
    dispatchGetList({ page, row, ...queryParams }).then(reslut => {
      refreshing === 0 ? setRefreshing(false) : setRefreshing(0)
      // Taro.stopPullDownRefresh()
      if (reslut.code === '1') {
        const resList = reslut?.data[0]?.data
        const _totals = reslut?.data[0]?.totals
        const _list = page === 1 ? resList : list.concat(resList)
        if (_list.length < _totals) {
          setListParams(pre => ({
            ...pre,
            page,
            hasMore: true,
            list: _list
          }))
        } else {
          setListParams(pre => ({
            ...pre,
            page,
            hasMore: false,
            list: _list
          }))
        }
      } else {
        Taro.showToast(reslut?.message || '服务器繁忙，请稍后再试！')
      }
    })
  }

  // 列表数据
  function dispatchGetList(params) {
    return new Promise(reslut => {
      fetch({
        url: url,
        header: {
          'Content-Type': 'application/json;charset=utf-8'
        },
        params: params
      }).then(result => {
        reslut(result)
      })
    })
  }

  return (
    <ScrollView
      className="scrollView"
      scrollY
      lowerThreshold={100}
      enablePassive
      enableBackToTop
      scrollWithAnimation
      refresherEnabled
      refresherTriggered={!!refreshing}
      onScrollToLower={handleScrollBottom}
      onRefresherRefresh={handleRefresh}
    >
      {children
        ? (list || []).map((item, index) =>
            React.cloneElement(children, {
              data: item,
              item: item,
              index: index,
              key: item[rowKey] || index
            })
          )
        : null}
      {hasMore ? (
        <LoadMore status={1} />
      ) : list?.length ? (
        <EndMessageStyled>
          <View className="end-message">
            <View className="message">我也是有底线的</View>
          </View>
        </EndMessageStyled>
      ) : (
        <LoadMore status={2} />
      )}
    </ScrollView>
  )
}

export default forwardRef(ListScroll)

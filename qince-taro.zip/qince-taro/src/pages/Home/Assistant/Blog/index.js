import { useState } from 'react'
import Taro, { setNavigationBarTitle } from '@tarojs/taro'
import dayjs from 'dayjs'

import jump from '@/utils/jump'
import fetch from '@/utils/request'

import List from '../List'

import { useUpdateEffect, useEventChannel } from '../../utils/hooks'

const Blog = () => {
  const [listParams, setListParams] = useState({
    page: 1,
    row: 20,
    hasMore: true,
    list: []
  })

  const [queryParams, setQueryParams] = useState({
    workHelperCodes: []
  })

  const { eventChannel, success } = useEventChannel()

  // 持续监听页面重新消息
  useUpdateEffect(() => {
    eventChannel.on('_props', _props => {
      const { workHelperCodes = '', title = '' } = _props
      setNavigationBarTitle({ title: title })
      setQueryParams(pre => ({ ...pre, workHelperCodes: [workHelperCodes] }))
    })
  }, [JSON.stringify(success)]) // eslint-disable-line

  // 提交操作
  const handleDelete = (val, _loadList) => {
    Taro.showModal({
      title: '',
      content: '确定要批量删除吗？',
      success: function(res) {
        if (res.confirm) {
          const params = {
            messageId: (val || [])?.join(','),
            ...queryParams
          }
          fetch({
            url: '/workhelp/push/delete.do',
            header: {
              'Content-Type': 'application/json;charset=utf-8',
              Accept: 'application/json, text/plain, */*'
            },
            params: params
          }).then(result => {
            if (result?.code === '1') {
              Taro.showToast({
                mask: true,
                title: result?.message || '删除成功！',
                icon: 'none'
              })
              _loadList()
              // 持续监听页面重新消息
            } else {
              Taro.showToast({
                mask: true,
                title: result?.message || '系统繁忙，请稍后再试！',
                icon: 'none'
              })
            }
          })
        }
      }
    })
  }

  // 点击单项查看详情
  const handleClick = item => {
    Taro.setStorageSync('qince-home-blog', 'true')
    let url = item?.custom?.push_url
    if (!url.includes('.html')) {
      url = url.slice(url.indexOf('#') + 1)
    }
    if (url) {
      jump({
        url: url,
        title:
          item?.custom?.model_name === '日报'
            ? '日报'
            : `${item?.custom?.sendName ?? ''}${dayjs(item?.custom?.sendTime)?.format(
                'YYYY-MM-DD'
              )}审批`
      })
    }
  }

  const handleChange = data => {
    setListParams(data)
  }

  return (
    queryParams.workHelperCodes?.length && (
      <List
        value={listParams}
        url="/workhelp/index.do"
        queryParams={queryParams}
        onClickToView={handleClick}
        onDelete={handleDelete}
        onChange={handleChange}
      />
    )
  )
}

export default Blog

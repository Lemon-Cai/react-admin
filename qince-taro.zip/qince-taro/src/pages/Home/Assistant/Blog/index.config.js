export default definePageConfig({
  navigationBarTitleText: '待评价日报',
})

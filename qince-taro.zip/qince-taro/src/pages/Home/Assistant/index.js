import React, { useEffect } from 'react'
import Taro from '@tarojs/taro'
import { View } from '@tarojs/components'
import { styled } from 'linaria/react'
import jump from '@/utils/jump'

import { Card, CardHeader, CardTitle, CardBody } from '@/components/Card'
import { Grid, GridItem } from '@/components/Grid'

const StyledCard = styled(Card)`
  box-shadow: 0px 2px 34px -6px rgba(0, 0, 0, 0.06);
  padding: 0;
  .qince-card-header {
    padding: 12px;
  }
  .qince-card-title {
    font-size: 15px;
    color: #35393e;
  }
  .qince-card-body {
    padding: 0 0 8px 0;
  }
  .weui-grid {
    padding: 20rpx 20rpx;
  }
  .qince-assistant-title {
    font-size: 15px;
    color: #35393e;
  }
  .qince-assistant-extra {
    font-size: 12px;
    color: #0277fb;
  }
  .qince-assistant-item {
    text-align: center;
    flex: 1;
  }
  .qince-assistant-count {
    font-size: 18px;
    color: #191c1f;
    font-weight: 400;
    text-align: center;
  }
  .qince-assistant-label {
    font-size: 12px;
    color: #9da6af;
    text-align: center;
  }
  .qince-gird {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 15px 0px;
  }
  .qince-weui-grid-active {
    &:active {
      background-color: red;
    }
  }
`

const MENUID_NAME = {
  '-11': '待审批',
  '-12': '待评价日报',
  '-13': '待执行客户任务',
  '-14': '今日待拜访'
}

export default React.memo(({ userWorkhelper = [], allMenuList = [] }) => {
  const { workHelp = [], workHelpValue = [], id = '' } = userWorkhelper
  const [work, setWord] = React.useState([])

  useEffect(() => {
    setWord(
      workHelp.map(o => ({
        ...o,
        ...workHelpValue.find(u => Number(o?.menuId) === Number(u?.menuId)),
        name: MENUID_NAME[String(o?.menuId)]
      }))
    )
  }, [JSON.stringify(userWorkhelper)]) // eslint-disable-line

  const handleToSetup = () => {
    Taro.navigateTo({
      url: '/pages/Home/Setting/index',
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('_props', {
          usedMenuList: work,
          title: '编辑',
          typeParams: {
            type: 'myUsedWork',
            id
          }
        })
      },
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        _props: function(data) {
          const { showList } = data
          setWord(showList)
        }
      }
    })
  }

  const handleClick = item => {
    return function() {
      Taro.setStorageSync('qince-home', 'true')
      if (item?.menuId === -14) {
        // 今日拜访
        let url = _getMenuUrl('visit.html#/todayVisit')
        url && jump({
          url: url
          // title: item.name
        })
      } else if (item?.menuId === -13) {
        // 待执行客户任务
        const url = _getMenuUrl('cusTaskDesignate.html#/list')
        url && jump({
          url: url
          // title: item.name
        })
      } else {
        Taro.navigateTo({
          url: '/pages/Home/Assistant/Blog/index',
          success: function(res) {
            // 通过eventChannel向被打开页面传送数据
            res.eventChannel.emit('_props', {
              workHelperCodes: item?.workHelpCode,
              title: item.name
            })
          },
          events: {
            // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
            _props: function() {}
          }
        })
      }
    }
  }

  const _getMenuUrl = (search) => {
    let url = ''
    function loop (list = [], key) {
      for (const item of list) {
        if (item.menuList?.length > 0) {
          loop(item.menuList, key)
        }
        if (item?.url?.indexOf(key) > -1) {
          url = item?.url
        }
      }
    }
    loop(allMenuList, search)
    return url
  }

  return (
    <StyledCard>
      <CardHeader>
        <CardTitle className="qince-assistant-title">工作助手</CardTitle>
        <View className="qince-assistant-extra" onClick={handleToSetup}>
          编辑
        </View>
      </CardHeader>
      <CardBody>
        <Grid column={3} hasBorder={false}>
          {(work || [])
            .filter(o => o?.showState === '1')
            .map((item, index) => {
              return (
                <GridItem key={item?.id || index} onClick={handleClick(item)}>
                  <View className="qince-assistant-count">{item.totals}</View>
                  <View className="qince-assistant-label">{item.name}</View>
                </GridItem>
              )
            })}
        </Grid>
      </CardBody>
    </StyledCard>
  )
})

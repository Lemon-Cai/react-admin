import { useState, useEffect, forwardRef, useRef } from 'react'
import { styled } from 'linaria/react'
import { View } from '@tarojs/components'
import Taro, { eventCenter, getCurrentInstance } from '@tarojs/taro'

import { Page, PageBody, PageFooter } from '@/components/Page'
import { Checkbox } from '@/components/Checkbox'
import { SubmitBar } from '@/components/SubmitBar'

import {
  MediaBox,
  MediaBoxBody,
  MediaBoxCheckbox,
  MediaBoxDesc,
  MediaBoxTitle
} from '@/components/MediaBox'

import ListScroll from './ListScroll'

const StyledPage = styled(Page)`
  .qince-footer-btn {
    text-align: center;
    height: 50px;
    line-height: 50px;
    background-color: #f7f7fa;
    color: #ff9008;
    font-size: 16px;
  }
  .qince-title-time {
    font-size: 14px;
    color: gray;
    text-align: right;
  }
  .qince-mediaboxtitle {
    display: flex;
    justify-content: space-between;
    .sendName {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .qince-body {
    display: flex;
    /* overflow: auto; */
    flex-direction: column;
    scroll-view {
      flex: 1;
      height: 100%;
    }
  }
`

const StyledMediaBoxType = styled(View)`
  margin-right: 12px;
  width: 45px;
  height: 45px;
  line-height: 45px;
  text-align: center;
  font-size: 14px;
  background: #ff9008;
  color: #fff;
  border-radius: 100%;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
`

const List = props => {
  const { value = [], onCancel = () => {}, onClickToView, onDelete = () => {} } = props

  const { list } = value

  const listRef = useRef()

  const [state, setState] = useState({
    selected: [],
    checked: false, // 是否已选中
    editable: false, // 是否可编辑
    buttons: [{ key: 'batchDelete', name: '批量删除' }]
  })

  useEffect(() => {
    eventCenter.on(getCurrentInstance().router.onShow, () => {
      if (Taro.getStorageSync('qince-home-blog') === 'true') {
        _loadList()
        Taro.setStorageSync('qince-home-blog', 'false')
      }
    })
  }, []) // eslint-disable-line

  //  选择单项
  const handleCheck = val => {
    let _selected = state.selected.includes(val)
      ? state.selected.filter(item => item !== val)
      : [...state.selected, val]
    setState(prevState => ({
      ...prevState,
      selected: _selected,
      checked: _selected.length === list.length
    }))
  }

  // 全选/取消全选
  const handleCheckAll = () => {
    let _selected = state.checked ? [] : list.map(item => `${item?.custom?.messageId}`)
    setState(prevState => ({
      ...prevState,
      selected: _selected,
      checked: !state.checked
    }))
  }

  // 点击业务按钮事件
  const handleClick = item => {
    if (item.key === 'batchDelete') {
      // 点击批量删除
      setState(prevState => ({
        ...prevState,
        editable: true,
        buttons: [
          { key: 'cancel', name: '取消', type: 'warn' },
          { key: 'delete', name: '删除', type: 'primary' }
        ]
      }))
    } else if (item.key === 'cancel') {
      // 取消
      setState(prevState => ({
        ...prevState,
        editable: false,
        buttons: [{ key: 'batchDelete', name: '批量删除' }]
      }))
      onCancel(state.selected)
    } else if (item.key === 'delete') {
      onDelete(state.selected, _loadList)
    }
  }

  const handleClickToView = item => {
    if (!state.editable) {
      onClickToView && onClickToView(item)
    }
  }

  // 刷新
  const _loadList = () => {
    setState(prevState => ({
      ...prevState,
      selected: [],
      editable: false,
      buttons: [{ key: 'batchDelete', name: '批量删除' }]
    }))
    setTimeout(() => {
      listRef.current && listRef.current.loadList(true)
    }, 0)
  }

  return (
    <StyledPage>
      <PageBody className="qince-body">
        <ListScroll ref={listRef} {...props}>
          <MediaBoxItem onCheck={handleCheck} state={state} onClick={handleClickToView} />
        </ListScroll>
      </PageBody>
      {list.length ? (
        <PageFooter className="wq-border-t">
          <SubmitBar
            editable={state.editable}
            checked={state.checked}
            data={state.buttons}
            onCheck={handleCheckAll}
            onClick={handleClick}
          />
        </PageFooter>
      ) : null}
    </StyledPage>
  )
}

const MediaBoxItem = props => {
  const { item, state, onClick, onCheck } = props
  return (
    <MediaBox key={item.id} type="card" onClick={() => onClick(item)}>
      {state.editable && (
        <MediaBoxCheckbox onClick={() => onCheck(`${item?.custom?.messageId}`)}>
          <Checkbox checked={state.selected.includes(`${item?.custom?.messageId}`)} />
        </MediaBoxCheckbox>
      )}
      <StyledMediaBoxType>
        {item?.custom?.model_name === '日报' ? '日报' : '审批'}
      </StyledMediaBoxType>
      <MediaBoxBody>
        <MediaBoxTitle className="qince-mediaboxtitle">
          <View className="sendName">{item?.custom?.sendName ?? ''}</View>
          <View className="qince-title-time">{item?.custom?.sendTime ?? ''}</View>
        </MediaBoxTitle>
        <MediaBoxDesc>{item?.title ?? ''}</MediaBoxDesc>
      </MediaBoxBody>
    </MediaBox>
  )
}

export default forwardRef(List)

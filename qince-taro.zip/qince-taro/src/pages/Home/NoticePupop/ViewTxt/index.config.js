export default definePageConfig({
  navigationBarTitleText: '预览文本',
  backgroundColor: '#fff'
})

import React from 'react'
import { View } from '@tarojs/taro'

import { Page, PageBody } from '@/components/Page'

import { useUpdateEffect, useEventChannel } from '../../utils/hooks'

const ViewTxt = () => {
  const { eventChannel, success } = useEventChannel(null)

  const [text, setText] = React.useState('')

  // 持续监听页面重新消息
  useUpdateEffect(() => {
    eventChannel.on('_props', _props => {
      const { data = '' } = _props
      setText(data)
    })
  }, [JSON.stringify(success)]) // eslint-disable-line

  return (
    <Page>
      <PageBody>{text}</PageBody>
    </Page>
  )
}

export default ViewTxt

// 详情页---顶部---附件
import { View, Text } from '@tarojs/components'

import previewFile from '../previewFile'

import './index.less'

const AttachmentCard = props => {
  const {
    attachmentFiles: { downloadUrl = '', name = '', size = '', wxSize = '' }
  } = props
  console.log('downloadUrl', downloadUrl)
  // 获取文件格式后缀
  const getFormatSuffix = () => {
    let suffix = name?.substr(name?.lastIndexOf('.') + 1, name?.length - 1) || 'other'
    if (/jpg|jpeg|png|gif|bmp|pcx|exif|svg|psd|raw/.test(suffix)) {
      return 'png'
    }
    if (/doc|wps|wpt|rtf|txt|ini/.test(suffix)) {
      return 'doc'
    }
    if (/xlt|xls|excle/.test(suffix)) {
      return 'xls'
    }
    if (/xml/.test(suffix)) {
      return 'xml'
    }
    if (/zip|rar|iso|7z/.test(suffix)) {
      return 'zip'
    }
    if (/html|htm/.test(suffix)) {
      return 'html'
    }
    if (suffix === 'PDF' || suffix === 'pdf') {
      return 'pdf'
    }
    return 'other'
  }

  //  有浏览
  const handlePreviewFile = () => {
    let suffix = name?.substr(name?.lastIndexOf('.') + 1, name?.length - 1) || 'other'
    previewFile({ url: downloadUrl, suffix, name })
  }

  return (
    <View className="platform-flexbox">
      <View className="left centerClass">
        <View className={`wq-icon wq-icon-file-${getFormatSuffix()}`}></View>
      </View>

      <View className="center">
        <View className="media-panel-title">{name}</View>
        <View className="media-panel-size">{`${size || 0}KB`}</View>
      </View>
      <View className="centerClass">
        <Text className="right" onClick={handlePreviewFile}>
          查看
        </Text>
      </View>
    </View>
  )
}

export default AttachmentCard

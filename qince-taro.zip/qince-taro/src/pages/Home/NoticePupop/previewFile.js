import Taro from '@tarojs/taro'

const previewFile = ({ url, suffix, name }) => {
  if (/jpg|jpeg|png|gif|bmp|pcx|exif|svg|psd|raw|mp4/.test(suffix)) {
    const sources = [
      {
        url: decodeURIComponent(url),
        type: /mp4/.test(suffix) ? 'video' : 'image'
      }
    ]
    previewMedia({ sources })
  } else if (['txt'].includes(suffix)) {
    previewTxt({ url })
  } else if (/zip|rar|iso|7z/.test(suffix)) {
    previewUnzip({ url, name })
  } else if (/doc|docx|xls|ppt|pptx|pdf/.test(suffix)) {
    downloadFileOpenDocument({ url })
  } else {
    failPreviewToast('小程序不支持该格式文件预览！')
  }
}

// 预览视频/照片
export const previewMedia = ({ sources, ...props }) => {
  Taro.previewMedia({
    sources: sources,
    success: function() {
      console.log('预览成功')
    },
    fail: () => failPreviewToast,
    ...props
  })
}

// 下载并预览 /doc|docx|xls|ppt|pptx|pdf/
export const downloadFileOpenDocument = async ({ url }) => {
  const res = await downloadFile({ url })
  if (res?.statusCode === 200) {
    openDocument({ url: res.tempFilePath })
  } else {
    failPreviewToast()
  }
}

// 预览 /doc|docx|xls|ppt|pptx|pdf/
export const openDocument = async ({ url }) => {
  Taro.openDocument({
    showMenu: true,
    filePath: url,
    fail: () => failPreviewToast()
  })
}

export const downloadFile = ({ url }) => {
  return new Promise((reslove, reject) => {
    Taro.downloadFile({
      url: decodeURIComponent(url),
      success: function(res) {
        // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
        reslove(res)
      },
      fail: error => {
        reject(error)
      }
    })
  })
}

// 预览 txt
export const previewTxt = async ({ url }) => {
  const res = await downloadFile({ url })
  if (res?.statusCode === 200) {
    readFile({ url: res.tempFilePath })
  } else {
    failPreviewToast()
  }
}

export const readFile = ({ url }) => {
  let fs = Taro.getFileSystemManager()
  fs.readFile({
    filePath: url,
    encoding: 'utf8',
    complete(result) {
      Taro.navigateTo({
        url: '/pages/Home/NoticePupop/ViewTxt/index',
        success: function(ress) {
          // 通过eventChannel向被打开页面传送数据
          ress.eventChannel.emit('_props', {
            data: result?.data
          })
        }
      })
    }
  })
}

// 解压并预览
export const previewUnzip = async ({ url, name }) => {
  name = name.replace(/ /g, '')
  Taro.showLoading()
  const res = await downloadFile({ url })
  if (res?.statusCode === 200) {
    const fs = Taro.getFileSystemManager()
    const _path = `${Taro.env.USER_DATA_PATH}/${name}`
    fs.unzip({
      zipFilePath: res.tempFilePath,
      targetPath: _path,
      success: () => {
        fs.readdir({
          dirPath: _path,
          success: resReaddir => {
            Taro.hideLoading()
            const [_filesName, __filesName = ''] = resReaddir?.files || []
            const __suffix =
              _filesName?.substr(_filesName?.lastIndexOf('.') + 1, _filesName?.length - 1) || ''
            const ___filesName = name?.includes(__suffix) ? _filesName : __filesName
            const __path = `${_path}/${___filesName}`
            const _suffix =
              ___filesName?.substr(___filesName?.lastIndexOf('.') + 1, ___filesName?.length - 1) ||
              'other'
            console.log('___filesName', ___filesName)
            console.log('resReaddir', resReaddir)
            console.log('__path', __path)
            console.log('_suffix', _suffix)
            if (/jpg|jpeg|png|gif|bmp|pcx|exif|svg|psd|raw|mp4/.test(_suffix)) {
              const sources = [
                {
                  url: __path,
                  type: /mp4/.test(_suffix) ? 'video' : 'image'
                }
              ]
              previewMedia({ sources })
            } else if (/txt/.test(_suffix)) {
              readFile({ url: __path })
            } else if (/doc|docx|xls|ppt|pptx|pdf/.test(_suffix)) {
              openDocument({ url: __path })
            } else {
              failPreviewToast('小程序不支持该格式文件预览！')
            }
          },
          fail: () => {
            Taro.hideLoading()
            failPreviewToast()
          }
        })
      },
      fail: () => {
        Taro.hideLoading()
        failPreviewToast()
      }
    })
  } else {
    Taro.hideLoading()
    failPreviewToast()
  }
}

const failPreviewToast = (title = '预览失败！') => {
  Taro.showToast({
    title: title,
    icon: null
  })
}

export default previewFile

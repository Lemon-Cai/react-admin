import Taro from '@tarojs/taro'
import fetch from '@/utils/request'
import { useEffect, useState } from 'react'
import { Button, View, Text, ScrollView } from '@tarojs/components'
import { Page, PageBody } from '@/components/Page'
import dayjs from 'dayjs'

import AttachmentCard from './AttachmentCard'

import './index.less'

function NoticePupop() {
  const [state, setState] = useState({
    // 显隐
    visible: false,
    // 公告id
    id: ''
  })

  // 系统信息
  const [systemInfo, setSystemInfo] = useState({})

  useEffect(() => {
    const _systemInfo = async () => {
      // 获取系统信息
      const info = await Taro.getSystemInfo()
      console.log('info', info)
      setSystemInfo(info)
      _initialization()
    }
    _systemInfo()
  }, []) // eslint-disable-line

  function _initialization() {
    Taro.showLoading()
    const url = '/app/bbs/v2/web/getPopupNotice.action'
    fetch({
      url: url,
      header: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept: 'application/json, text/plain, */*'
      }
    }).then(result => {
      Taro.hideLoading()
      if (result?.data && result.data?.noticeUrl) {
        if (
          result?.data?.popupStrategy === '1'
          //  &&
          // Taro.getStorageSync('hasNoticeFlag') !== 'true'
        ) {
          // 首次展示
          // Taro.setStorageSync('hasNoticeFlag', 'true')
          setState({
            visible: true,
            id: result?.data?.bbsId || ''
          })
        } else if (result?.data?.popupStrategy === '2') {
          // 每次展示
          setState({
            visible: true,
            id: result?.data?.bbsId || ''
          })
        } else if (
          result?.data?.popupStrategy === '3' &&
          result?.data?.popupStrategy !== dayjs().format('YYYY-MM-DD')
        ) {
          setState({
            visible: true,
            id: result?.data?.bbsId || ''
          })
        }
      }
    })
  }

  return (
    state.visible && (
      <View className={`modal ${state.visible ? 'show' : 'hide'}`}>
        <View className="modal-mask" />
        <View
          className="modal-wrapper"
          style={{
            width: (systemInfo?.windowWidth * 8) / 10,
            height: (systemInfo.windowHeight * 8) / 10
          }}
        >
          <View className="modal-content">
            <BbsDetail id={state.id} onVisible={v => setState(pre => ({ ...pre, visible: v }))} />
          </View>
        </View>
      </View>
    )
  )
}

export default NoticePupop

const BbsDetail = props => {
  const { id = '', onVisible } = props
  const [noticeInfo, setNoticeInfo] = useState({})

  const [visible, setVisible] = useState(true)

  useEffect(() => {
    // 调用 getElementsInfo 函数，等待所有元素信息获取完毕后再进行判断
    if (noticeInfo?.content) {
      setTimeout(() => {
        getElementsInfo()
      }, 100)
    }
  }, [JSON.stringify(noticeInfo)]) // eslint-disable-line

  const getElementsInfo = () => {
    const query = Taro.createSelectorQuery()
    query.select('.platform-innerHTML')?.fields({ size: true })
    query.select('.qince-notes')?.fields({ size: true })
    query.select('.modal-page-body')?.fields({ size: true })
    query.select('.platform-footer')?.fields({ size: true })
    query.exec(([scrollHeight, notesHeight, bodyHeight, footerHeight]) => {
      // console.log('scrollHeight', scrollHeight)
      // console.log('notesHeight', notesHeight)
      // console.log('bodyHeight', bodyHeight)
      // console.log('footerHeight', footerHeight)
      setVisible(
        Number(scrollHeight?.height || '') +
          Number(footerHeight?.height || '') +
          Number(notesHeight?.height || '') >
          Number(bodyHeight?.height || '')
      )
    })
  }

  // 公告详情数据
  const getNoticeInfo = async () => {
    try {
      const { data = {} } = await fetch({
        url: `/app/bbs/v2/client/getNoticeInfo.action?params.id=${id}`,
        method: 'GET',
        header: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json, text/plain, */*'
        }
      })
      setNoticeInfo(data)
    } catch (error) {
      console.log('error:', error)
    }
  }

  // 我知道了
  const handleIgotIt = async () => {
    const url = '/app/bbs/v2/client/readPopupNotice.action'
    try {
      await fetch({
        url,
        params: { 'params.id': id },
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      })
      onVisible(false)
    } catch (error) {
      console.log('error:', error)
    }
  }

  useEffect(() => {
    getNoticeInfo()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const handleScroll = () => {
    if (visible) {
      setVisible(false)
    }
  }

  return (
    <Page style={{ borderRadius: 8 }}>
      <Text className="modal-title">{noticeInfo?.title}</Text>
      <PageBody className="modal-page-body">
        <ScrollView scrollY style={{ height: '100%' }} onScrollToLower={handleScroll}>
          {noticeInfo?.notes && (
            <View
              className="qince-notes"
              style={{ margin: '0 12px 8px 12px', lineHeight: '20px', textAlign: 'left' }}
            >
              {noticeInfo?.notes}
            </View>
          )}
          <View
            className="platform-innerHTML"
            dangerouslySetInnerHTML={{ __html: noticeInfo?.content }}
          />
          {/* 有附件时展示，没有直接什么也不显示 */}
          {noticeInfo?.attachmentFiles?.length > 0 && (
            <View className="platform-footer">
              {noticeInfo?.attachmentFiles.map(i => (
                <AttachmentCard attachmentFiles={i} key={i.id} />
              ))}
            </View>
          )}
        </ScrollView>
      </PageBody>
      <View className="modal-page-footer">
        <Button
          open-type="launchApp"
          appParameter
          className="modal-button"
          style={visible ? { backgroundColor: '#ffcea5', borderColor: '#ffcea5' } : {}}
          disabled={visible}
          color="warning"
          onClick={handleIgotIt}
        >
          我知道了
        </Button>
      </View>
    </Page>
  )
}

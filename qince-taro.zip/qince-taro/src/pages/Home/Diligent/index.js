import { View, Text } from '@tarojs/components'
import { styled } from 'linaria/react'

import { Card, CardHeader, CardTitle, CardBody } from '@/components/Card'
import { ProgressBar } from '@/components/ProgressBar'

const StyledCard = styled(Card)`
  box-shadow: 0px 2px 18px -6px rgba(86,33,0,0.21);
  .qince-diligent-title {
    font-size: 13px;
    color: #85909c;
  }
  .qince-diligent-percent {
    font-size: 15px;
    color: #ff6f31;
  }
  .qince-diligent-more {
    font-size: 13px;
    color: #4f565d;
  }
  .qince-diligent-body {
    padding-top: 0;
  }
`

export default () => {

  // 跳转
  const handleToView = () => {
    console.log('123');
  }

  return (
    <StyledCard>
      <CardHeader>
        <CardTitle className='qince-diligent-title'>
          我的勤奋度超过了公司<Text className='qince-diligent-percent'>70%</Text>的人
        </CardTitle>
        <View className='qince-diligent-more' onClick={handleToView}>查看详情</View>
      </CardHeader>
      <CardBody className='qince-diligent-body'>
        <ProgressBar percent={80} />
      </CardBody>
    </StyledCard>
  )
}

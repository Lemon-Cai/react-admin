import React from 'react'

import useUpdateEffect from './useUpdateEffect'

const useControllableValue = (props = {}, options = {}) => {
  const {
    defaultValue,
    defaultValuePropName = 'defaultValue',
    valuePropName = 'value',
    trigger = 'onChange'
  } = options

  const value = props[valuePropName]

  const [state, setState] = React.useState(() => {
    if (valuePropName in props) {
      return value
    }
    if (defaultValuePropName in props) {
      return props[defaultValuePropName]
    }
    return defaultValue
  })

  /* init 的时候不用执行了 */
  useUpdateEffect(() => {
    if (valuePropName in props) {
      setState(value)
    }
  }, [value, valuePropName])

  const handleSetState = React.useCallback(
    v => {
      if (!(valuePropName in props)) {
        setState(v)
      }
      if (props[trigger]) {
        props[trigger](v)
      }
    },
    [props, valuePropName, trigger]
  )

  return [state, handleSetState]
}

export default useControllableValue

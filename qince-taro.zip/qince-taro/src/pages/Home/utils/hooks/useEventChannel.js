import React from 'react'
import { getCurrentPages } from '@tarojs/taro'

const useEventChannel = () => {
  const [value, setValue] = React.useState('')
  const [success, setSuccess] = React.useState('')
  React.useEffect(() => {
    // 持续监听页面重新消息
    const pages = getCurrentPages()
    const current = pages[pages.length - 1]
    const eventChannel = current.getOpenerEventChannel()
    setValue(eventChannel)
    setSuccess('true')
  }, []) // eslint-disable-line
  return { eventChannel: value, success: success }
}

export default useEventChannel

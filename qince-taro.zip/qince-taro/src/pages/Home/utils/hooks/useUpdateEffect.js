import React from 'react'

// 自定义hook 初始化不调用
function useUpdateEffect(fn, inputs) {
  const didMountRef = React.useRef(false)
  React.useEffect(() => {
    if (didMountRef.current) fn()
    else didMountRef.current = true
  }, inputs) // eslint-disable-line
}

export default useUpdateEffect

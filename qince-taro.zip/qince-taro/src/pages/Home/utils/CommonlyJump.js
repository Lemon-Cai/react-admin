import jump from '@/utils/jump'
import Taro from '@tarojs/taro'

import { getParameter } from '@/utils'
import fetch from '@/utils/request'

const CommonlyJump = item => {
  if (item?.url) {
    if (item?.url.indexOf('webview:') === 0) {
      item.url = item?.url?.replace('webview:', '')
    }
    if (
      item.url.indexOf('.html') !== -1 ||
      item.url.indexOf('.action') !== -1 ||
      item.url.indexOf('.do') !== -1
    ) {
      let menuId = getParameter('menuId', item.url)
      if (menuId) {
        // this.$http.saveMenuLog({menuId: menuId})
        const params = { menuId }
        fetch({
          url: '/client/saveMenuLog.action',
          params,
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        })
      }
      jump({
        url: `${item.url}${(item.url.indexOf('?') !== -1 ? '&' : '?') + 't=' + +new Date()}`,
        title: item.name
      })
    } else {
      if (item.url.indexOf('schedule/attandence/index')) {
      }
      jump({
        url: item.url,
        title: item.name
      })
    }
  } else {
    _toView(item?.menuList || item?.children, item?.name)
  }
}

const _toView = (othersMenuList, name) => {
  Taro.navigateTo({
    url: '/pages/Home/Commonly/Others/index',
    success: function(res) {
      // 通过eventChannel向被打开页面传送数据
      res.eventChannel.emit('_props', {
        othersMenuList,
        title: name
      })
    },
    events: {
      // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
      // _props: function(data) {
      //   const { menuList: menus = [] } = data
      //   setUsualFeatures(pre => ({ ...pre, menuList: menus }))
      // }
    }
  })
}

export default CommonlyJump

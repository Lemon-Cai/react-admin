export default definePageConfig({
  navigationBarTitleText: '',
  disableScroll: true
})

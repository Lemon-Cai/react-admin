import { useState, useEffect, useRef } from 'react'
import { getCurrentPages, setNavigationBarTitle } from '@tarojs/taro'
import { View } from '@tarojs/components'
import { styled } from 'linaria/react'

import { Page, PageBody } from '@/components/Page'
import { Drag } from '@/components/Drag'

import fetch from '@/utils/request'

const DragStyled = styled(Drag)`
  height: auto;
`

const Title = styled(View)`
  padding: 12px;
  margin-bottom: -8px;
  font-size: 13px;
  /* color: ${props => (props.readOnly ? '' : '#ff9008')}; */
`

const Edit = () => {
  const sortedList = useRef(null)
  const typeRef = useRef(null)
  // 排序列
  const [sortColumns, setSortColumns] = useState([])

  const { eventChannel, success } = useEventChannel()

  // 持续监听页面重新消息
  useDidUpdateEffect(() => {
    eventChannel.on('_props', _props => {
      const { usedMenuList = [], title = '', typeParams = '' } = _props
      setNavigationBarTitle({ title: title })
      // 默认显示的排序列 /  不显示的不排序列
      setSortColumns(usedMenuList)
      typeRef.current = typeParams
    })
  }, [JSON.stringify(success)]) // eslint-disable-line

  const handleChange = list => {
    sortedList.current = list
    _request(list)
  }

  const handleClick = (key, index, obj) => {
    const sort = key === 'delete' ?
      sortColumns?.map((item => ({ ...item, showState: item.menuId === obj?.data?.menuId ? '0' : item.showState }))) :
      sortColumns?.map((item => ({ ...item, showState: item.menuId === obj?.data?.menuId ? '1' : item.showState })))
    setSortColumns(sort)
    _request(sort, eventChannel)
  }

  const _request = (sort) => {
    sortColumns.forEach((item => {
      if (!(sort.some(o => o?.menuId === item?.menuId))) {
        sort.push({ ...item, showState: '0' })
      }
    }))
    let url
    if (typeRef.current && typeRef.current.type === 'myUsedWork') {
      const params = {
        icardId: typeRef.current.id,
        hideList: [],
        showList: []
      }
      url = '/workbench/icard/menu/showchange.do'
      sort.forEach(item => {
        if (item.showState !== '1') {
          params['hideList'].push(item.menuId)
        } else {
          params['showList'].push(item.menuId)
        }
      })
      _fetchMenuChange(url, params, eventChannel, sort)
    } else {
      const params = {
        clientType: typeRef.current.id,
        showList: []
      }
      url = '/workbench/icard/showchange.do'
      sort.forEach(item => {
        if (item.showState === '1') {
          params['showList'].push(item.menuId)
        }
      })
      _fetchMenuChange(url, params, eventChannel, sort)
    }
  }

  return (
    <Page>
      <PageBody>
        <Content
          title="显示卡片"
          type="delete"
          draggable
          sortColumns={sortColumns?.filter(o => o?.showState === '1')}
          onChange={handleChange}
          onClick={handleClick}
        />
        <Content
          title="未显示卡片"
          type="add"
          sortColumns={sortColumns?.filter(o => o?.showState === '0')}
          onChange={handleChange}
          onClick={handleClick}
        />
      </PageBody>
    </Page>
  )
}

const Content = ({ title, type, draggable, sortColumns = [], onChange = () => { }, onClick = () => { } }) => {

  return (
    <>
      <Title>{title}</Title>
      <DragStyled
        type={type}
        draggable={draggable}
        data={sortColumns}
        itemHeight={64}
        onChange={onChange}
        onClick={onClick}
      />
    </>
  )
}

const _fetchMenuChange = (url, params, eventChannel, showList) => {
  eventChannel.emit('_props', { showList: showList })
  fetch({
    url: url,
    header: {
      'Content-Type': 'application/json;charset=utf-8',
      Accept: 'application/json, text/plain, */*'
    },
    params: params
  }).then(result => {
    if (result?.code === '1') {
      // 持续监听页面重新消息
    }
  })
}

const useEventChannel = () => {
  const [value, setValue] = useState('')
  const [success, setSuccess] = useState('')
  useEffect(() => {
    // 持续监听页面重新消息
    const pages = getCurrentPages()
    const current = pages[pages.length - 1]
    const eventChannel = current.getOpenerEventChannel()
    setValue(eventChannel)
    setSuccess('true')
  }, []) // eslint-disable-line
  return { eventChannel: value, success: success }
}

// 自定义hook 初始化不调用
function useDidUpdateEffect(fn, inputs) {
  const didMountRef = useRef(false)
  useEffect(() => {
    if (didMountRef.current) fn()
    else didMountRef.current = true
  }, inputs) // eslint-disable-line
}
export default Edit

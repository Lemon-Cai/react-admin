import Taro, { useDidShow, eventCenter, Events, getCurrentInstance } from '@tarojs/taro'
import { View } from '@tarojs/components'

import { useEffect } from 'react'
import { connect } from 'react-redux'
import { styled } from 'linaria/react'

import { Page } from '@/components/Page'
import { Space } from '@/components/Space'
import { Empty } from '@/components/Empty'

import * as actions from '@/store/Home'

import Diligent from './Diligent'
import Notice from './Notice'
import Commonly from './Commonly'
import Assistant from './Assistant'
import NoticePupop from './NoticePupop'

const Link = styled(View)`
  color: #0277fb;
  font-size: 12px;
  cursor: auto;
  text-align: center;
  margin: 16px 0;
`
const events = new Events()

const Home = props => {
  const {
    // 页面全量数据
    // homeData = [],
    userInfo,
    // 自定义工作台菜单
    usedMenuList = [],
    // 全部功能菜单
    allMenuList = [],
    // 全量数据
    dispatchHome,
    // 系统初始化
    dispatchFetchSystemInit,
    // dispatchChangeState
    dispatchChangeState
  } = props

  useEffect(() => {
    eventCenter.on(getCurrentInstance().router.onShow, () => {
      if (Taro.getStorageSync('qince-home') === 'true') {
        dispatchHome()
        Taro.setStorageSync('qince-home', 'false')
      }
    })
    return () => events.off()
  }, []) // eslint-disable-line

  useDidShow(() => {
    // 未查询用户信息
    if (!allMenuList?.length && !userInfo.userId) {
      Promise.all([dispatchHome(), dispatchFetchSystemInit()]).then(() => Taro.hideLoading())
    }
  })

  // const handleShowResetPassword = () => {
  //   if (userInfo?.IsSatisfy === '0' && !showModal.current) {
  //     showModal.current = true
  //     // 密码安全性低  跳转修改密码
  //     Taro.showModal({
  //       content: '管理员提高了登录密码安全强度，请立即修改登录密码。',
  //       confirmText: '修改密码',
  //       showCancel: false,
  //       success: () => {
  //         showModal.current = false
  //         setTimeout(() => {
  //           Taro.redirectTo({
  //             url: '/pages/Login/setPassword'
  //           })
  //         }, 100)
  //       }
  //     })
  //   }
  // }

  const handleToSetup = () => {
    Taro.navigateTo({
      url: '/pages/Home/Setting/index',
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('_props', {
          usedMenuList: usedMenuList,
          allMenuId: allMenuList.map(item => item.menuId),
          title: '自定义工作台',
          typeParams: {
            id: usedMenuList.find(o => o?.icardType)?.clientType
          }
        })
      },
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        _props: function(data) {
          const { showList } = data
          dispatchChangeState({ usedMenuList: showList })
        }
      }
    })
  }

  return usedMenuList?.length ? (
    <Page style={{ padding: '8px', overflow: 'auto' }}>
      <Space direction="vertical">
        {(usedMenuList || [])?.map((item, index) => {
          if (item.showState !== '1') return null
          return (
            <CustomWorkbenchMenu
              key={item?.menuId || index}
              item={item}
              _allMenuList={allMenuList}
            />
          )
        })}
      </Space>
      <Link onClick={handleToSetup}>自定义工作台</Link>
      <NoticePupop />
    </Page>
  ) : (
    <Space block direction="vertical">
      <Empty description={props?.message} />
    </Space>
  )
}

// 自定义工作台菜单
const CustomWorkbenchMenu = ({ item = {}, _allMenuList = [] }) => {
  const { icardType } = item
  let childrenNode = null
  switch (icardType) {
    case '-52':
      // 数据概览
      break
    case '-12':
      // 勤奋度
      childrenNode = <Diligent />
      break
    case '-42':
      // 通知公告
      childrenNode = <Notice bbsMessage={item} />
      break
    case '2':
      // 我的常用功能
      childrenNode = <Commonly usualFeatures={item} allMenuList={_allMenuList} />
      break
    case '1':
      // 工作助手
      childrenNode = <Assistant userWorkhelper={item} allMenuList={_allMenuList} />
      break
    default:
      break
  }
  return childrenNode
}

const mapStateToProps = state => ({
  ...state.Home
})

const mapDispatchToProps = {
  ...actions
}

export default connect(mapStateToProps, mapDispatchToProps)(Home)

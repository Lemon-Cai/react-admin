export default definePageConfig({
  navigationStyle: 'custom'
})

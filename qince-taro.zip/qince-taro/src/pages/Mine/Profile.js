import Taro from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { View, Text, Image } from '@tarojs/components'
import { styled } from 'linaria/react'

const StyledAvatar = styled(View)`
  width: 60px;
  height: 60px;
  overflow: hidden;
  border-radius: 100%;
  text-align: center;
  justify-content: center;
  background: #f6f6f6;
`

const Profile = (props) => {
  const { value } = props

  // 头像
  const [face, setFace] = useState('')

  // 姓
  const [surname, setSurname] = useState('')

  useEffect(() => {
    if (value) {
      const path = value.userFace || `${value?.imageRoot}/user/avatar/${value?.id}.jpg?x-oss-process=style/zk_face`
      try {
        Taro.getImageInfo({
          src: path,
          success: (res) => {
            if (res.width > 0) {
              setFace(path)
            }
          }
        })
      } catch(e) {
        console.log(e)
        setFace('https://image-test.waiqin365.com/imobii_portal/images/icon/default-face-small.png')
      }
      setSurname(value?.name.substring(0, 1))
    }
  }, [value])

  const handleToDetail = () => {
    Taro.navigateTo({
      url: '/app/Mine/UserInfo/index'
    })
  }

  return (
    <View>
      <View className="weui-media-box weui-media-box_appmsg" style={{ padding: '12px' }} onClick={handleToDetail}>
        <View className="weui-media-box__hd">
          <StyledAvatar>
            {face ? <Image className="weui-media-box__thumb" src={face} /> : surname}
          </StyledAvatar>
        </View>
        <View className="weui-media-box__bd">
          <Text className="weui-media-box__title" style={{fontWeight: 'bold', color: '#1A1C1F'}}>{value?.name || ''} {value?.isAdmin === 'true' && `(管理员)`} </Text>
          <View className="weui-media-box__desc" style={{color: '#77818C'}}>{value?.tenantName}{value?.dept_name ? ` ｜ ${value?.dept_name}` : ''}</View>
        </View>
        <View className="weui-media-box__ft" />
      </View>
    </View>
  )
}

export default Profile

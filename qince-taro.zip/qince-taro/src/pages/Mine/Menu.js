import Taro from '@tarojs/taro'
import { useState, useMemo, useEffect } from 'react'
import { View } from '@tarojs/components'
import { styled } from 'linaria/react'

import { Card, CardBody } from '@/components/Card'
import { Icons } from '@/components/Icons'
import { Cells, Cell, CellHeader, CellBody, CellFooter } from '@/components/Cell/index'

const StyledCard = styled(Card)`
  padding: 0;
  overflow: hidden;
  box-shadow: 0px 2px 16px -6px rgba(0, 0, 0, 0.08);
  .qince-card-body {
    padding: 0;
  }
  .weui-cells {
    margin: 0;
    &:before,
    &:after {
      display: none;
    }
  }
  & + .qince-card {
    margin-top: 12px;
  }
`

const Mine = ({ userInfo, dispatchAccountList, dispatchInitMine, dispatchInitHome }) => {
  const [isMiniProgram, setIsMiniProgram] = useState(true) // 默认为微信小程序
  const [accountList, setAccountList] = useState(true) // 默认为微信小程序

  const qywechatMenus = useMemo(() => {
    let baseMenu = [
      {
        name: '联系客服',
        iconType: 'mine-contact',
        path: 'tel:4001-025-365',
        openType: '3'
      },
      {
        name: '了解勤策',
        iconType: 'mine-know',
        path: '/mine/mineIframe',
        openType: '1',
        url: 'https://s.eqxiu.cn/s/s1bI1c0I'
      },
      {
        name: '成功案例',
        iconType: 'mine-manual',
        url:
          'https://mp.weixin.qq.com/mp/homepage?__biz=MjM5ODIyMDM2Mg==&hid=4&sn=595d9484e6efdb463a9349b064a27542',
        openType: '1'
      },
      {
        name: '扫码登录',
        iconType: 'scan',
        openType: '2'
      }
    ]
    if (userInfo?.is_admin === '1') {
      baseMenu.push({
        name: '报价方案',
        iconType: 'mine-price',
        url:
          'https://open.work.weixin.qq.com/wwopen/appStore/detail/price?appId=MTk3MDMyNDk3MTk5OTA3NF8zMzk0OF8x&notreplace=true#',
        openType: '1'
      })
    }
    return baseMenu
  }, [userInfo]) // eslint-disable-line

  useEffect(() => {
    Taro.getSystemInfoAsync({
      success: res => {
        if (res.environment) {
          // 判断为企微环境
          setIsMiniProgram(false)
        }
      }
    })
    if (userInfo) {
      getMoreAccountList()
    }
  }, [userInfo]) // eslint-disable-line

  // 检查是否有多账号
  const getMoreAccountList = () => {
    let params = {
      mobile: userInfo.mobile
    }
    dispatchAccountList(params).then(res => {
      if (res.code === '1') {
        setAccountList(res.data || [])
      }
    })
  }

  // 联系客服
  const handleContact = () => {
    Taro.makePhoneCall({
      phoneNumber: '025-68736873'
    })
  }

  const handleModifyPassword = () => {
    Taro.navigateTo({
      url: '/app/Mine/ModifyPassword/index'
    })
  }

  // 退出登录
  const handleLogout = () => {
    Taro.showModal({
      content: '确定退出登录？',
      success: async function(res) {
        if (res.confirm) {
          Taro.removeStorageSync('qince-token')
          await dispatchInitHome()
          await dispatchInitMine()
          Taro.redirectTo({
            url: '/pages/Login/index'
          })
        }
      }
    })
  }

  const handleLogoutAccount = () => {
    Taro.navigateTo({
      url: '/app/Mine/Logout/index'
    })
  }

  const handleChangeAccount = () => {
    Taro.navigateTo({
      url: '/app/Mine/ChangeAccount/index'
    })
  }

  const handleClickMenu = item => {
    if (item.openType === '1') {
      let path = item.url
      Taro.navigateTo({
        url: `/app/Webview/index?url=${encodeURIComponent(path)}&title=${encodeURIComponent(
          item.name
        )}`
      })
    } else if (item.openType === '2') {
      // 扫码
      handleScanLogin()
    } else if (item.openType === '3') {
      // 打电话
      Taro.makePhoneCall({
        phoneNumber: '025-68736873'
      })
    }
  }

  const handleScanLogin = () => {
    try {
      Taro.scanCode({
        onlyFromCamera: true,
        success: res => {
          console.log(res)
          if (res.errMsg === 'scanCode:ok') {
            // 跳转至扫码确认页面
            Taro.navigateTo({
              url: `/app/Mine/ScanLogin/index?result=${res.result}&rawData=${res.rawData}`
            })
          } else {
            Taro.showToast({
              mask: true,
              title: '扫码失败,请重试',
              icon: 'none'
            })
          }
        }
      })
    } catch (e) {
      Taro.showToast({
        mask: true,
        title: '扫码失败,请重试',
        icon: 'none'
      })
    }
  }

  return (
    <View style={{ padding: '12px' }}>
      {isMiniProgram ? (
        <StyledCard>
          <CardBody>
            <Cells>
              <Cell access style={{ padding: '12px 14px' }} onClick={handleModifyPassword}>
                <CellHeader>
                  <Icons style={{ marginRight: 10, fontSize: 20 }} color="#1890FF" value="forgot_password" />
                </CellHeader>
                <CellBody>修改密码</CellBody>
                <CellFooter />
              </Cell>
              <Cell access style={{ padding: '12px 14px' }} onClick={handleScanLogin}>
                <CellHeader>
                  <Icons style={{ marginRight: 10, fontSize: 20 }} color="#FA8C16" value="scan" />
                </CellHeader>
                <CellBody>扫码登录</CellBody>
                <CellFooter />
              </Cell>
              {accountList?.length > 0 && (
                <Cell access style={{ padding: '12px 14px' }} onClick={handleChangeAccount}>
                  <CellHeader>
                    <Icons style={{ marginRight: 10, fontSize: 20 }} color="#13C2C2" value="transfer" />
                  </CellHeader>
                  <CellBody>切换账号</CellBody>
                </Cell>
              )}
              <Cell access style={{ padding: '12px 14px' }} onClick={handleContact}>
                <CellHeader>
                  <Icons style={{ marginRight: 10, fontSize: 20 }} color="#13C2C2" value="tel" />
                </CellHeader>
                <CellBody>联系客服</CellBody>
                <CellFooter>025-68736873</CellFooter>
              </Cell>
              <Cell access style={{ padding: '12px 14px' }} onClick={handleLogoutAccount}>
                <CellHeader>
                  <Icons style={{ marginRight: 10, fontSize: 20 }} color="#F5222D" value="logout" />
                </CellHeader>
                <CellBody>注销帐号</CellBody>
                <CellFooter />
              </Cell>
            </Cells>
          </CardBody>
        </StyledCard>
      ) : (
        <StyledCard>
          <CardBody>
            <Cells>
              {qywechatMenus.map(item => (
                <Cell key={item.name} access onClick={() => handleClickMenu(item)}>
                  <CellHeader></CellHeader>
                  <CellBody>{item.name}</CellBody>
                  <CellFooter>{item.openType == '4' && '025-68736873'}</CellFooter>
                </Cell>
              ))}
            </Cells>
          </CardBody>
        </StyledCard>
      )}

      <View style={{marginTop: 42}}>
        <View onClick={handleLogout}>
          <CellBody style={{ textAlign: 'center' }}>退出登录</CellBody>
        </View>
      </View>
    </View>
  )
}

export default Mine

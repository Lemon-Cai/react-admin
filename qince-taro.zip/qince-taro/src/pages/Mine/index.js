import { useEffect, useState } from 'react'
import Taro from "@tarojs/taro"

import { connect } from 'react-redux'
import * as actions from '@/store/Mine'
import { dispatchInit } from '@/store/Home'

import { styled } from 'linaria/react'

import { Page } from '@/components/Page'

import Profile from './Profile'
import Menu from './Menu'

const StyledPage = styled(Page)`
  padding-top: 64px;
  background-image: url(https://res.waiqin365.com/d/miniprogram/images/mine/bg.jpg);
  background-repeat: no-repeat;
  background-size: cover;
`

const Mine = (props) => {
  const {
    // loading,
    userInfo,
    dispatchGetUserInfo,
    dispatchAccountList,
    dispatchInitMine,
    dispatchInitHome
  } = props

  const [statusHeight, setStatusHeight] = useState(0)
  const [menuButtonHeight, setMenuButtonHeight] = useState(0)

  useEffect(() => {
    dispatchGetUserInfo()
    _setTitleHeight()
  }, []) // eslint-disable-line

  const _setTitleHeight = () => {
    let _statusHeight = Taro?.getMenuButtonBoundingClientRect()?.top || 0
    let _menuButtonHeight = Taro?.getMenuButtonBoundingClientRect()?.height || 0
    setStatusHeight(_statusHeight)
    setMenuButtonHeight(_menuButtonHeight)
  }

  return (
    <StyledPage style={{paddingTop: statusHeight + menuButtonHeight + 20}}>
      <Profile value={userInfo}  />
      <Menu userInfo={userInfo} dispatchAccountList={dispatchAccountList} dispatchInitMine={dispatchInitMine} dispatchInitHome={dispatchInitHome} />
    </StyledPage>
  )
}

const mapStateToProps = state => ({
  ...state.Mine
})

const mapDispatchToProps = {
  ...actions,
  dispatchInitHome: dispatchInit
}

export default connect(mapStateToProps, mapDispatchToProps)(Mine)

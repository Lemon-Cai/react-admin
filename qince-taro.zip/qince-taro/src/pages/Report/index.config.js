export default definePageConfig({
  navigationStyle: 'custom',
  navigationBarTitleText: '报表'
})

export default definePageConfig({
  navigationBarTitleText: 'Drag',
  disableScroll: true
})

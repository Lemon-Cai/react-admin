import { useRef } from 'react'

import { Page, PageBody } from '@/components/Page'
import { Drag } from '@/components/Drag'
import { Cell, CellHeader, CellBody, CellFooter } from '@/components/Cell'
import { Icons } from '@/components/Icons'

const listData = [
  { key: '0', backgroundColor: 'red', fixed: false },
  { key: '1', backgroundColor: 'deeppink', fixed: false },
  { key: '2', backgroundColor: 'green', fixed: false },
  { key: '3', backgroundColor: 'orange', fixed: false },
  { key: '4', backgroundColor: 'purple', fixed: false },
  { key: '5', backgroundColor: 'lime', fixed: false },
  { key: '6', backgroundColor: 'blue', fixed: false },
  { key: '7', backgroundColor: 'violet', fixed: false },
  { key: '8', backgroundColor: 'cyan', fixed: false },
  { key: '9', backgroundColor: 'gold', fixed: false }
]

const Edit = () => {
  const sortedList = useRef(listData)

  const onChange = list => {
    // console.log('onChange', list)
    // state.listData = list // 直接赋值 会重新渲染
    console.log('list:', list)
    sortedList.current = list
  }

  const renderItem = (item) => {
    return (
      <Cell>
        <CellHeader></CellHeader>
        <CellBody>{item.key}</CellBody>
        <CellFooter>
        </CellFooter>
      </Cell>
    )
  }

  const renderDragItem = () => {
    return <Icons value="menu" />
  }

  return (
    <Page>
      <PageBody>
        <Drag
          listData={sortedList.current}
          itemHeight={64}
          onChange={onChange}
          renderItem={renderItem}
          style={{ height: '100%' }}
          renderDragItem={renderDragItem}
        />
      </PageBody>
    </Page>
  )
}

export default Edit

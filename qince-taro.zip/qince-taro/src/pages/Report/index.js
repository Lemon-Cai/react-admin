import Taro, { useDidShow } from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { WebView } from '@tarojs/components'

// 报表
const Report = () => {
  const [url, setUrl] = useState('')
  const [token, setToken] = useState(() => {
    return Taro.getStorageSync('qince-token')
  })

  useDidShow(() => {
    let pages = Taro.getCurrentPages()
    if (pages.length > 0) {
      let currPage = pages[pages.length - 1]
      if (currPage?.data?.message?.action === 'reload') {
        const host = Taro.getStorageSync('appsvrUrl')
        const _token = Taro.getStorageSync('qince-token')
        setToken(_token)
        setUrl(`${host}/wework/#/report?from=miniprogram&token=${_token}&type=${currPage?.data?.message?.data}&timestamp=${new Date().getTime()}`)
      }
    }
    if (Taro.getStorageSync('qince-token') !== token) {
      const _token = Taro.getStorageSync('qince-token')
      const host = Taro.getStorageSync('appsvrUrl')
      setToken(_token)
      setUrl(`${host}/wework/#/report?from=miniprogram&token=${_token}&timestamp=${new Date().getTime()}`)
    }
  })

  // 初始化
  useEffect(() => {
    const host = Taro.getStorageSync('appsvrUrl')
    if (token) {
      console.log(token, 'token')
      setUrl(`${host}/wework/#/report?from=miniprogram&token=${token}&timestamp=${new Date().getTime()}`) // eslint-disable-line
    }
  }, []) // eslint-disable-line

  return <WebView src={url} />
}

export default Report

const definePageConfig = ({
  backgroundTextStyle: 'light',
  navigationBarBackgroundColor: '#f7f7f7',
  navigationBarTitleText: '人员选择',
  navigationBarTextStyle: 'black'
})

export default definePageConfig
import Taro, { useDidShow, useLoad } from '@tarojs/taro'
import { useState, useEffect } from 'react'

import { View, Input, Text, Image, ScrollView } from '@tarojs/components'

import { Page, PageHeader, PageBody, PageFooter } from '@/components/Page'

import { Tabs } from '@/components/Tabs'

import fetch from '@/utils/request'

import DeptTree from './DeptTree'
import EmployeeList from './EmployeeList'

import './index.less'

const TabList = [
  {
    title: '按人员',
    key: '1'
  },
  {
    title: '按部门',
    key: '2'
  }
]
let options = {}
let empQueryParams = {}
let deptQueryParams = {}
let beforeConfirm = null

export default () => {
  const [multiple, setMultiple] = useState(true)
  const [tabIndex, setTabIndex] = useState(0)

  const [empParams, setEmpParams] = useState({
    page: 1,
    rows: 20,
    keyword: ''
  })

  const [list, setList] = useState([]) // 人员列表数据
  const [listTotal, setListTotal] = useState(0)

  const [deptTree, setDeptTree] = useState([]) // 部门数据

  const [selected, setSelected] = useState([]) // 选中的展示区数据

  useEffect(() => {
    if (tabIndex === 1 && !deptTree.length) {
      _initDeptData()
    }
  }, [tabIndex]) // eslint-disable-line

  useLoad(op => {
    options = op
    setTimeout(() => {
      getEmployeeList()
    }, 0)
  })

  useDidShow(() => {
    const pageData = Taro.getCurrentInstance()
    const event = pageData?.page?.getOpenerEventChannel()
    event.on('empDatas', datas => {
      setSelected(datas.value || [])
      empQueryParams = datas?.empQueryParams || {}
      deptQueryParams = datas?.deptQueryParams || {}
      setMultiple(typeof datas?.multiple === 'boolean' ? datas?.multiple : true)
      datas?.beforeConfirm && (beforeConfirm = datas?.beforeConfirm)
    })
  })

  const handleSubmit = singleData => {
    let pages = Taro.getCurrentPages()

    let prePage = pages?.[pages.length - 2] || ''

    if (prePage) {
      prePage.setData({
        empSelected: singleData ? singleData : selected
      })
    }
    Taro.navigateBack({
      delta: 1
    })
  }

  const handleClickTab = index => {
    setTabIndex(index)
  }

  const getEmployeeList = (isNext = false) => {
    // /combo/v1/getComboGrid.do?comboCode=employee
    // menuId   isControl page rows
    let currentPage = empParams.page
    if (isNext) {
      currentPage += 1
      setEmpParams({
        ...empParams,
        page: currentPage
      })
    } else {
      currentPage = 1
      setEmpParams({
        ...empParams,
        page: currentPage
      })
    }
    Taro.showLoading()
    fetch({
      url: '/combo/v1/getComboGrid.do?comboCode=employee',
      params: {
        keyword: empParams.keyword || '',
        menuId: options?.menuId || '6778072811795709662',
        page: currentPage,
        rows: empParams.rows,
        isControl: options?.isControl || '0',
        ...empQueryParams
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }
    }).then(res => {
      Taro.hideLoading()
      if (res.rows.length > 0) {
        if (isNext) {
          setList(list.concat(res.rows || []))
        } else {
          setList(res.rows || [])
          setListTotal(res.total || 0)
        }
      } else {
        setList([])
        setListTotal(0)
      }
    })
  }

  const _initDeptData = () => {
    Taro.showLoading()
    fetch({
      url: '/platform/combo/v1/getComboTree.do?comboCode=depart_employee_tree',
      method: 'POST',
      params: {
        menuId: options?.menuId || '6778072811795709662',
        hasEmp: '1',
        isControl: options?.isControl || '1',
        ...deptQueryParams
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }
    }).then(res => {
      Taro.hideLoading()
      if (res.length > 0) {
        setDeptTree(res)
      }
    })
  }

  const handleBottomReload = () => {
    console.log('底部刷新')
    if (listTotal > list.length) {
      getEmployeeList(true)
    }
  }

  const handleChangeEmployees = emps => {
    setSelected(
      emps.map(item => ({
        ...item,
        name: item.name || item.text
      }))
    )
  }

  const handleChangeChecked = values => {
    values = values.map(item => ({
      ...item,
      name: item.name || item.text
    }))

    setSelected(values)
    if (!multiple) {
      handleSubmit(values)
    }
  }

  const handleSearch = () => {
    getEmployeeList()
  }

  return (
    <Page className="employee-component">
      <PageHeader style={{ width: '100%', height: 'auto' }}>
        {multiple && (
          <View className="switch-area">
            <Tabs current={tabIndex} onClick={handleClickTab} tabList={TabList} />
          </View>
        )}

        {tabIndex === 0 && (
          <View className="search-box">
            <Input
              value={empParams.keyword}
              onInput={e => setEmpParams({ ...empParams, keyword: e.detail.value })}
              className="search-input"
              placeholder="请输入查询名称"
              style={{ background: '#fff', height: 32, borderRadius: 4, padding: '0 10px' }}
              type="text"
              onConfirm={handleSearch}
            />
            <Text className="search-btn" onClick={handleSearch}>
              搜索
            </Text>
          </View>
        )}
      </PageHeader>

      <PageBody>
        <View className="list-wrap" style={{ height: '100%' }}>
          {tabIndex === 0 && (
            <EmployeeList
              list={list}
              multiple={multiple}
              value={selected}
              beforeConfirm={beforeConfirm}
              onChange={handleChangeChecked}
              onBottomReload={handleBottomReload}
            />
          )}
          {tabIndex === 1 && deptTree.length > 0 && multiple && (
            <DeptTree treeData={deptTree} value={selected} onChange={handleChangeEmployees} />
          )}
        </View>
      </PageBody>
      {multiple && (
        <PageFooter>
          <View className="footer-wrap">
            <ScrollView className="scroll-emps" scrollX>
              <View className="employees-area">
                {selected.map(item => {
                  return (
                    <View key={item} className="emp-item">
                      <Image
                        className="emp-avatar"
                        src={
                          item?.props?.avatar ||
                          item?.face_pic ||
                          'https://image-test.waiqin365.com/imobii_portal/images/icon/default-face.png'
                        }
                      ></Image>
                      <View className="emp-name">{item.name || item.text || ''}</View>
                    </View>
                  )
                })}
              </View>
            </ScrollView>
            <View className="confirm-btn" onClick={() => handleSubmit()}>
              确定{selected.length > 0 && `(${selected.length})`}
            </View>
          </View>
        </PageFooter>
      )}
    </Page>
  )
}

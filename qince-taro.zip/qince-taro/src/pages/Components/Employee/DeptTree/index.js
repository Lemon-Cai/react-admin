import { useState, useEffect } from 'react'
import { View, Text, Image } from '@tarojs/components'
import Checkbox from '@/components/CompCheckbox'
import { Icons } from '@/components/Icons'

import _unionBy from 'lodash/unionBy'
import _differenceBy from 'lodash/differenceBy'

import utils from './utils'
import './index.less'

export default ({
  treeData, // 列表数据
  // multiple, // 是否多选
  value, // {[keyField]: '', [labelField]: ''}
  onChange,
  formatTreeData, // 转化  function（） => return []
  keyField = 'id', // key
  labelField = 'text' // label
}) => {
  const [listData, setListData] = useState([]) // 树数据
  const [expendKeys, setExpendKeys] = useState([]) // 展开节点
  const [selectedNode, setSelectedNode] = useState([]) // 选中节点

  useEffect(() => {
    if (formatTreeData) {
      setListData(formatTreeData(treeData))
    } else {
      setListData(treeData)
    }
  }, [treeData]) // eslint-disable-line

  useEffect(() => {
    let allNodes = [] // 数据传入后 去重后需要关联的上级节点
    if (value.length) {
      const treeDatas = formatTreeData ? formatTreeData(treeData) : treeData
      value.forEach(item => {
        const relationParentNodes = utils.getRelationParentsNode(item, value, treeDatas)
        allNodes = _unionBy(relationParentNodes, allNodes, keyField)
      })
    }
    setSelectedNode( _unionBy(selectedNode, [...allNodes, ...(value || [])], keyField))
  }, [value]) // eslint-disable-line

  const handleOpenTree = item => {
    if (!item?.children?.length) return
    if (expendKeys.includes(item[keyField])) {
      let newList = expendKeys.filter(key => key !== item[keyField])
      setExpendKeys(newList)
    } else {
      setExpendKeys(expendKeys.concat([item[keyField]]))
    }
  }

  const handleChangeChecked = (val, node) => {
    // 获取当前节点及所有子节点
    const nodeList = utils.getTileNode(node)

    if (val) {
      // 确定时  兄弟节点都选中时候  选中父级节点
      let relationParentNodes = utils.getRelationParentsNode(node, selectedNode, listData)
      let changedList = _unionBy(selectedNode, [...relationParentNodes, ...nodeList], keyField)

      // console.log(selectedNode, relationParentNodes, nodeList, changedList)

      setSelectedNode(changedList)

      onChange && onChange(filterEmpList(changedList))
    } else {
      //  取消时  向上查找父级节点并取消
      let topsList = utils.getParentsNode(node, listData)
      let changedList = _differenceBy(selectedNode, [...topsList, ...nodeList], keyField)
      setSelectedNode(changedList)
      onChange && onChange(filterEmpList(changedList))
    }
  }

  // 过滤人员数据
  const filterEmpList = (list) => {
    return list.filter(item => item?.props?.type === 'emp' || item.face_pic)
  }

  // 检查子集有没有选中项目
  const checkChildrenSelected = (item) => {
    let flag = false

    const eachChildren = (node) => {
      if (!node) return
      if (node?.children?.length) {
        node.children.forEach(childrenNode => {
          selectedNode.find(i => i[keyField] === childrenNode[keyField]) && (flag = true)
          childrenNode?.children?.length && eachChildren(childrenNode)
        })
      }
    }
    eachChildren(item)

    return flag
  }

  const handleRenderTree = list => {
    return list.map(item => (
      <View key={item[keyField]} className="tree-node-box">
        <View className="tree-node">
          <View className="tree-content" onClick={() => handleOpenTree(item)}>
            {item?.children?.length > 0 && (
              <Icons value={expendKeys.includes(item[keyField]) ? 'open' : 'retract'}></Icons>
            )}
            {
              item?.props?.type === 'emp' && (
                <Image className="emp-avatar" src={item?.props?.avatar || 'https://image-test.waiqin365.com/imobii_portal/images/icon/default-face.png'}></Image>
              )
            }
            <Text className="node-text">{item[labelField]}</Text>
          </View>
          <Checkbox
            className="check-icon"
            halfChecked={checkChildrenSelected(item)}
            checked={!!selectedNode.find(i => i[keyField] === item[keyField])}
            onChange={val => handleChangeChecked(val, item)}
          ></Checkbox>
        </View>
        <View className="line wq-border-b"></View>
        {item?.children?.length > 0 && expendKeys.includes(item[keyField]) && (
          <View className="tree-children">{handleRenderTree(item.children || [])}</View>
        )}
      </View>
    ))
  }

  return <View className="tree-area">{handleRenderTree(listData)}</View>
}

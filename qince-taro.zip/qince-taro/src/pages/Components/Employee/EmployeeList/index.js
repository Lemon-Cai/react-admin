import { View, Image } from '@tarojs/components'

import ScrollList from '@/components/ScrollList'
import Checkbox from '@/components/CompCheckbox'

import _unionBy from 'lodash/unionBy'
import _differenceBy from 'lodash/differenceBy'

export default ({ list, value, multiple, beforeConfirm, onChange, onBottomReload }) => {

  const handleChangeChecked = async (val, item) => {
    if (val) {

      if (beforeConfirm) {
        let result = await beforeConfirm(item)
        if (!result) return
      }

      if (!multiple) {
        onChange && onChange([item])
      } else {
        onChange && onChange(_unionBy(value, [item], 'id'))
      }
    } else {
      onChange && onChange(_differenceBy(value, [item], 'id'))
    }
  }

  const handleBottomReload = () => {
    onBottomReload && onBottomReload()
  }

  const _renderItem = item => {
    return (
      <View className="emp-item wq-border-b">
        <Checkbox
          isControl
          className="emp-checkbox"
          checked={!!value.find(i => i.id === item.id)}
          onChange={val => handleChangeChecked(val, item)}
        >
          <View className="emp-content">
            <Image
              className="avatar-icon"
              src={
                item.face_pic
                  ? item.face_pic
                  : 'https://image-test.waiqin365.com/imobii_portal/images/icon/default-face-small.png'
              }
              mode="scaleToFill"
            />
            <View className="content-info">
              <View className="emp-name">{item.name}</View>
              <View className="emp-dept">{item.dept_name}</View>
            </View>
          </View>
        </Checkbox>
      </View>
    )
  }

  return (
    <ScrollList
      style={{ height: '100%' }}
      list={list}
      alphabetBar
      // value={selected}
      // onChange={handleChangeEmployees}
      renderItem={_renderItem}
      onScrollToLower={handleBottomReload}
    />
  )
}

import _cloneDeep from 'lodash/cloneDeep'
import _differenceBy from 'lodash/differenceBy'

export default {
  // 平铺数据 转化树结构
  formatTreeNode: dataList => {
    const cloneDatas = _cloneDeep(dataList)

    let treeDatas = cloneDatas.filter(i => i.pId === '-1')

    const setChildrens = datas => {
      datas.forEach(item => {
        const childrenData = cloneDatas.filter(i => i.pId === item.id)
        item.children = childrenData
        if (childrenData?.length) {
          setChildrens(childrenData)
        }
      })
    }
    setChildrens(treeDatas)

    return treeDatas
  },
  // 树节点 结构平铺
  getTileNode: treeNode => {
    const cloneData = _cloneDeep(treeNode)
    const nodeList = []

    const pushData = data => {
      const childrenData = data?.children || null
      delete data.children
      nodeList.push(data)
      if (childrenData?.length) {
        childrenData.forEach(node => {
          pushData(node)
        })
      }
    }
    pushData(cloneData)
    return nodeList
  },
  // 获取父级列表
  getParentsNode(node, list) {
    // 获取层级比当前节点高的列表数据

    const topList = []
    const getParentItem = treeNode => {
      const parentId = list.find(i => i.id === treeNode.id)?.pId
      const parentNode = list.find(i => i.id === parentId)

      parentNode && topList.push(parentNode)

      if (parentId && parentId !== '-1') {
        getParentItem(parentNode)
      }
    }
    getParentItem(node)

    return topList
  },
  // 获取关联后的父级列表
  getRelationParentsNode(node, selectedNode, list) {
    // 关联选中的父级节点
    let checkedList = []

    const getParentsChecked = _node => {
      if (!_node) return
      // 找到当前节点的pId  筛选出相同的pId兄弟节点
      const currentPid = list.find(i => i.id === _node.id)?.pId
      let siblingNodes = _cloneDeep(list.filter(i => i.pId === currentPid))
      let newSelectedNode = [...selectedNode, _node]

      let filtereds = _differenceBy(siblingNodes, newSelectedNode, 'id')
      if (filtereds.length === 0) {
        let targetItem = list.find(i => i.id === currentPid)
        if (targetItem) {
          // 父级选中
          checkedList.push(targetItem)
          getParentsChecked(targetItem)
        }
      }
    }
    getParentsChecked(node)

    return checkedList
  }
}

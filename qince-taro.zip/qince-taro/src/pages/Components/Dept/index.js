import { useState } from 'react'
import Taro, { useDidShow, useLoad } from '@tarojs/taro'

import { View } from '@tarojs/components'
import { Page, PageBody, PageFooter } from '@/components/Page'

import fetch from '@/utils/request'
import DeptTree from './DeptTree'
import utils from './utils'

import './index.less'


let options = {}
let queryParams = {}

export default () => {

  const [listData, setListData] = useState([]) // 树数据
  const [selected, setSelected] = useState([]) // 选中节点

  useLoad(op => {
    options = (op || {})
    setTimeout(() => {
      _initDeptData()
    }, 0)
  })

  useDidShow(() => {
    const pageData = Taro.getCurrentInstance()
    const event = pageData?.page?.getOpenerEventChannel()
    event.on('deptDatas', datas => {
      setSelected(datas.value || [])
      queryParams = datas?.params || {}
    })
  })


  const _initDeptData = () => {
    let url = '/platform/combo/v1/getComboZTree.do'
    let params = {
      hasEmp: '0',
      isControl: '1',
      menuId: options?.menuId || '6778072811795709662',
      opCodes: 'VIEW',
      comboCode: 'depart_tree',
      ...queryParams.current
    }
    fetch({
      url,
      params,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }
    }).then(res => {
      if (res.length) {
        setListData(res)
      }
    })
  }

  const handleChangeChecked = (list) => {
    setSelected(list)
  }

  const handleSubmit = () => {
    let pages = Taro.getCurrentPages()

    let prePage = pages?.[pages.length - 2] || ''

    if (prePage) {
      prePage.setData({
        deptSelected: selected
      })
    }
    Taro.navigateBack({
      delta: 1
    })
  }

  return (
    <Page>
      <PageBody>
        {listData.length > 0 && (
          <DeptTree treeData={listData} formatTreeData={utils.formatTreeNode} value={selected} onChange={handleChangeChecked} />
        )}
      </PageBody>
      <PageFooter>
        <View className="confirm-btn wq-border-t" onClick={handleSubmit}>
          确定{selected?.length > 0 && `(${selected.length})`}
        </View> 
      </PageFooter>
    </Page>
  )
}

import { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import Taro, { getCurrentInstance, useLoad } from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import { styled } from 'linaria/react'

import * as actions from '@/store/Login'

import { Button } from '@/components/Button'
import { Page } from '@/components/Page'

const StyledPage = styled(Page)`
  display: flex;
  flex-direction: column;
  background-image: url('//res.waiqin365.com/d/qince-h5/platform/login/background.png');
  .header {
    position: absolute;
    width: 100%;
    display: flex;
    align-items: center;
    padding-left: 22px;
    box-sizing: border-box;
    .back-icon {
      height: 16px;
      width: 16px;
    }
  }
  .flex {
    display: flex;
    align-items: center;
    .forget {
      font-size: 14px;
      color: #ff9008;
      margin-left: 8px;
      white-space: nowrap;
    }
  }
  .weui-cells {
    background: none;
    padding: 0 22px;
    &::before,
    &::after {
      display: none;
    }
    .weui-cell {
      padding: 12px 0;
      font-size: 15px;
      &::before {
        display: none;
      }
    }
  }
  .qince-select-body {
    .wq-page-hd {
      padding-left: 22px;
      font-size: 22px;
      color: #191c1f;
      margin-bottom: 14px;
    }
    .select-list {
      padding: 0 22px;
      box-sizing: border-box;
      max-height: 65vh;
      overflow: auto;
      .select-item + .select-item {
        margin-top: 8px;
      }
      .select-item {
        padding: 12px 20px;
        box-sizing: border-box;
        border: 1px solid #dde2e8;
        box-shadow: inset 0px -0.5px 0px 0px rgba(230, 232, 235, 1);
        border-radius: 8px;
        position: relative;
        .code-value {
          font-size: 16px;
          color: #1a1c1f;
          line-height: 20px;
        }
        .dept-value {
          font-size: 14px;
          color: #42474d;
          line-height: 18px;
          margin-top: 4px;
        }
        &.selected {
          &::before {
            content: '';
            display: inline-block;
            position: absolute;
            left: -1px;
            top: -1px;
            width: 33px;
            height: 33px;
            background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGMAAABjCAYAAACPO76VAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAY6ADAAQAAAABAAAAYwAAAAC9CX4aAAAHQklEQVR4Ae2cSYwVVRSG/9cNNM0gNKhIwCGKDE5E0IiKIEZMXBjdmOCwUFwY48JoosYhpiUqxoWJiRqHaGJ0ZWJ0oQajJMYhgtgEUHBgbIjQzYwgNvRQnr+Kovq9rlfvVtWt6b17k86rO55zz1fnjgUlaAiWtasV3fsWo8laBKs0U5qcBstqA0pjAWuEBhH130QJz5ei9tI6vKENJ/tvhzUgf7hF2hkVta2Gr0cQk+a2h4ZhWbtHobvrMZSsJwSCvPkmxLLAKRBsQxmGZVnN2Lv2AanTLhAmx1LAVHYsMAgEE5RgWPvXTUHfwGcy/l9l7KjJAhUg2GpTraat/euvQX//GgOilqVC5PuAYO1AGFZ3x73o6/vWDEshDF2raBUQrFZ1mLJBWPiwVtsmP4QFAkCwFV8Y9tBEjwBGspAJGixQAwQlDIFhT9acI8yKSQOBU00ogGDJsjnDXr5y1WRApA6CAoeVSXX2EWb5WmaUGBFFj3AlnB6m7J313j1bjFe4pon5GxIEpXmewSMOmJ11TARO9QggWNH2DPvQ70Rvp3iFOWuKSyMiCIp1JnD79NWAiMtBXm379DVqOw4MHoObEM8CMUFQeJN9MeTcR8RTppFrawBhw7Bv6OrpYujEEeDY3+m9GppAODB4VVoXwQI2fwJ8sURg7E6nRxpBUOFhzp21dKTIoWc/8NMyoLvD6UXrhOR7oxkEFeY+Y1rymicoYd864MdngJ7DnpCWid5zEk8JgKCa4hn8iqOgYc8q4Iengf4TXgdKskAcOc6L635KCATVFM+wP6fRrXLy7e1cCaySoWmgr1xWC0GcPuUpz4sbSxAEVRMYBfyuaevnwJqXRX2fua5lfFyT+9dPGASFcs4oVtixQkAsr65zUwLfzKUAgh1yduDVu5avnAO/nfKIALV6jwVkRshKCQQ1Kw6M493A90/JZN0bbNG+48H5YXJTBEG1igGjrwf47klZvh6sbcqTR4dO6rVrDS2RMggqUAwYP78EHN481GB+KVxdHVIs61efaRmAoNj8w+j8CuAyNkzokv1H1JARCKqbbxj/7QN+eTW8WTu/Dl+HNTIEQfH5XtqufhEIszoaPhqYdTdw4R3sW7iQMQgqm18YWz4FuuQTX9Vw1mxg3nPA6HNUa3jlcgCCyqQLo+eADIyyKRtR46q95xCw/i3PWIFPcvRx2VLg0vtkmIkw6uYEBLsYQftAy/hnWv3AXx/LXcNdwO8Kn+9ueFNteGqSd+m6ZQ6MgoOg4ZL3DB5xcxI+stUBxQugGUvkZLXKncOBjcC2L/2hDk4dJv9q7QY5n5o0d3Cq+nOOPMJVOjkYHJLWvQHskKXp4MAN3CbxjjmPDE71njsUVk8c5m58DZgww6sX5imHIKi+/mFq8JBUCcI12FaZnI/vdWPe705Zkh78w4v7PdEjFgqwOgPBruqFwSFpxf3AWnlre//1M6WTxvOlTR+U5xPihnfL0ypjzS3AgleAiZdU5qjFc+oRrvL6YPz6HrDyYW9ucCVU+90mdxLH9ni522WeCPqqo9QMzJdjkbOv9OqEeco5CHZFH4zLlzrGOuN8NRPxDGnj+05ZekWlp1S2cvXj8iXwvMpUtXgBQLAj+mDwqnPqQuBWTs6PyjqttbaheFF0dBfQ+U25l1TWnHWP7Kpvq0xVixcEBDtTsro6fO4u1foZWIpD0OoXAM4jQeG8xcA/2+VUdot/KQLm8BQlFAgEu5ccDLZuDcik/LZs9D5iLHwYdxGw+B3xspHh6xYMBDuocZjysRd3xbMfAq4XD2ke7lMgIImHfvSIBgFBSyQLw7X1uYtkSSp7AxpYNcx7Fhg7VbW0V66AHuEqnw4MSps0B7jpdTkGaXNlV/+dKcfgUxZUz6+WU2AQ7FJ6MCitbTpws8whYyYz5h/GXwxc8aB/XlBqwUGwa+nCoMQxU4BF4iGtZzJWHppHANe2i1Yhj8zqAAQNkT4MSuUFEM+Xho9hzAuc7Mdd4MVVnuoEBLuaDQxKHi/L1vnLPS+YOAuYfidz1EMdgWCns4NB6ZzUeVXKc6e5ctwR5oPlOgNBcyS76aMElXDoT5ncZ6iUdMrUIQh2LFvPcM1vQNiWyAcMF0qt3zr1CLfbxYFR5yAIpBgwGgBEMWA0CIj8w2ggEPmG0WAg8gujAUHkE0aDgsgfjAYGkS8YDQ4iPzAMCLLIwabPgLBBZA/DgDgNIlsYBkQZiOxgGBBDQGQDw4DwBZE+DAOiKoh0YRgQgSDSg2FA1ASRDgwDQglE8jAMCGUQycIwIEKBSA6GAREaRDIwDIhIIPTDMCAig9ALw4CIBUIfDAMiNgg9MAwILSDiwzAgtIGIB8OA0AoiOgwDQjuIaDAMiERAhIdhQCQGIhwMAyJREOowDIjEQajBMCBSAVEbhgGRGohgGAZEqiCqwzAgUgfhD8OAyATEUBgGRGYgymEYEJmCsIXzf++0ujvas9fEaAADIj8vwf/hxd7SpXCC4gAAAABJRU5ErkJggg==');
            background-size: 100% 100%;
            background-repeat: no-repeat;
          }
        }
        .selected-text {
          position: absolute;
          right: 12px;
          top: 12px;
          color: #ff9008;
          font-size: 14px;
        }
      }
    }
  }
  .submit-box {
    padding: 20px;
  }
  .submit-btn {
    border-radius: 4px;
    height: 40px;
    line-height: 40px;
    padding: 0;
    font-size: 16px;
    font-weight: 400;
    border: none;
    outline: none;
  }
`

const Select = ({
  dispatchSubmitMoreAccount
}) => {

  const { page } = getCurrentInstance()

  const [codeList, setCodeList] = useState([])
  const [selected, setSelected] = useState({})

  const [statusHeight, setStatusHeight] = useState(0)
  const [menuButtonHeight, setMenuButtonHeight] = useState(0)

  useEffect(() => {
    _setTitleHeight()
  }, [])

  useLoad(() => {
    const eventChannel = page.getOpenerEventChannel()
    eventChannel.on('accountList', data => {
      setCodeList(data?.codeList || [])
      setSelected(data?.codeList?.[0])
    })
  })

  const _setTitleHeight = () => {
    let _statusHeight = Taro?.getMenuButtonBoundingClientRect()?.top || 0
    let _menuButtonHeight = Taro?.getMenuButtonBoundingClientRect()?.height || 0
    setStatusHeight(_statusHeight)
    setMenuButtonHeight(_menuButtonHeight)
  }

  const handleBack = () => {
    Taro.navigateBack()
  }

  const handleSubmit = () => {
    let params = {
      code: selected.wxCode,
      tenantCode: selected.tenantCode,
      userCode: selected.code,
      tenantId: selected.tenantId,
      openId: selected.openId,
    }
    dispatchSubmitMoreAccount(params)
  }

  const handleChangeChecked = item => {
    setSelected(item)
  }

  return (
    <StyledPage>
      <View
        className="header"
        style={{ height: `${menuButtonHeight + statusHeight}px`, paddingTop: `${statusHeight}px` }}
      >
        <Image
          onClick={handleBack}
          className="back-icon"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAtCAYAAADoSujCAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMKADAAQAAAABAAAALQAAAABDRz8/AAACe0lEQVRoBe2Z207CQBCGd6s8BzwKb6JeIScTxUTQiBFN4AZNBMHDjTE+CA/gpddG40tolK4zTQY5tDClu1ua2Julze72++efabuLFJqPo/Nueuh+PojU2lartvumefqZ6ZyZKxEuePDDr4FSIiu+h4Nq8zITYTrWUMnqxeg0ghcqQ92lFO/gRNakE1oE+MHbEhE5hebBowhIp7T4cTdIkO42kgOL4BEW0qjXqu8XdYPTfEsLWAV4FLFUCnHgIfb95nGlRJEy1YZ2gAvfqu8VpZTKFDjNG0oABx5y/gYiX7ABjyLYAlYRni2AAw+xuIW0yduKPDuFVhl+oQMceMj5O8j5bduRX+hAEuADHeDAQ87fQ87n4op8oANJgp9xgAMPz90XJZxDcMClKMTZjt4DHPg4QYPu7QlIKjyKkkmGRwHruACHL64MniTxcHD3wFu7JpEemL0a8HYPYBfBW/4FCYFPYynUs1LmP5GDEPyuj55CLBExfbD5gdO1kQC8kEQRE0tKb/8G9nHm14TK1c7aPQW5RFGIs/WF4Dhhe+UVFCRfAdiZIwKeAX1ba9/QApIiYqIGplUyayIPNdGdHmvrPDCFxgE46QQ1YXQHbpxn/PdcB6gjxwl4CRZqp/adYDlAQjhOOEJeN0/M78gRE8sB6sxxwhWqWG20OzTGdBvKAYLhOAFr5W6rXinTGFNtKAcIguMEvKlLUBNXNMZUu5QDBMNxAmqiAzWxQ2N0t0s5QBAcJ6AmygeNizqN0d1GEoAwi0RALXzIlHzSDU7zRUohmgRbv3RCeJFy8F/K1/G+On9rEzAtwgY83lOrgD8R7iNEftNk5PFe/8cqROAXle6S6vyfgHYAAAAASUVORK5CYII="
        ></Image>
      </View>
      <View className="qince-select-body">
        <View
          className="wq-page-hd"
          style={{ paddingTop: `${menuButtonHeight + statusHeight + 36}px` }}
        >
          选择账号
        </View>
        <View className="select-list">
          {codeList?.map(item => (
            <View
              key={item.id}
              className={`select-item ${selected.code === item.code ? 'selected':''}`}
              onClick={() => handleChangeChecked(item)}
            >
              <View className="code-value">{item.code}</View>
              <View className="dept-value">{item.dept}</View>
              {selected.code === item.code && <View className="selected-text">当前选择</View>}
            </View>
          ))}
        </View>

        <View className="submit-box">
          <Button gradients={['#FF5E3A', '#FF9500']} onClick={handleSubmit}>
            提交
          </Button>
        </View>
      </View>
    </StyledPage>
  )
}
const mapStateToProps = state => ({
  ...state.Login
})

const mapDispatchToProps = {
  ...actions
}
export default connect(mapStateToProps, mapDispatchToProps)(Select)

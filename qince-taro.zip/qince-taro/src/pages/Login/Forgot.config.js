export default definePageConfig({
  // backgroundTextStyle: 'light',
  navigationBarBackgroundColor: '#f7f7f7',
  // navigationBarTitleText: '找回密码',
  navigationBarTextStyle: 'black',
  navigationStyle: 'custom',
  usingComponents: {
    't-captcha': 'plugin://captcha/t-captcha'
  }
})

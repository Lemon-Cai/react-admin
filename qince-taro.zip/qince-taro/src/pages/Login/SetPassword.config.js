export default definePageConfig({
  // backgroundTextStyle: 'light',
  navigationBarBackgroundColor: '#f7f7f7',
  navigationBarTitleText: '修改密码',
  navigationBarTextStyle: 'black',
  // navigationStyle: 'custom'
})

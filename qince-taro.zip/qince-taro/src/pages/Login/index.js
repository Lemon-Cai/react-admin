import Taro, { getCurrentInstance } from '@tarojs/taro'
import { useEffect, useState } from 'react'
import { connect } from 'react-redux'
import * as actions from '@/store/Login'
import { dispatchInit } from '@/store/Home'

import { View, Label, CheckboxGroup, Checkbox, Image } from '@tarojs/components'
import { styled } from 'linaria/react'

import Logo from '@/assets/images/icon/icon-wechat.png'
import { Page } from '@/components/Page'
import { Cells, Cell, CellBody } from '@/components/Cell'
import { Input } from '@/components/Input'
import { Icons } from '@/components/Icons'

import { Button } from '@/components/Button'
import { Divider } from '@/components/Divider'

const StyledPage = styled(Page)`
  display: flex;
  flex-direction: column;
  background-image: url('//res.waiqin365.com/d/qince-h5/platform/login/background.png');
  .weui-cells {
    background: none;
    padding: 0 22px;
    &::before,
    &::after {
      display: none;
    }
    .weui-cell {
      padding: 12px 0;
      &::before {
        display: none;
      }
    }
  }
  .qince-login-body {
    flex: 1;
    .login-title {
      padding-left: 22px;
      font-size: 22px;
      color: #191c1f;
      margin-bottom: 14px;
    }
    .weui-cells {
      margin-top: 0;
    }
    .qince-icon {
      margin-right: 8px;
    }
    .qince-login-btn-area {
      margin: 0 16px;
    }
    .qince-agree {
      display: block;
      padding: 24px 0 16px 0;
      font-size: 12px;
      .qince-agree-text {
        color: #acb3b2;
      }
      .qince-agree-label {
        display: inline-block;
      }
      .qince-agree-link {
        display: inline;
        color: #ff9008;
      }
      .qince-agree-checkbox {
        position: absolute;
        left: -9999px;
      }
      .qince-agree-checkbox-icon {
        position: relative;
        top: 2px;
        display: inline-block;
        border: 1px solid #d1d1d1;
        background-color: #fff;
        border-radius: 3px;
        width: 14px;
        height: 14px;
        margin-right: 4px;
      }
      .qince-agree-checkbox-icon-check {
        position: absolute;
        width: 12px;
        height: 12px;
        line-height: 12px;
        color: #ff9008;
        top: 1px;
        left: 0;
      }
    }
    .flex {
      display: flex;
      align-items: center;
      .forget {
        font-size: 14px;
        color: #888;
        margin-left: 8px;
        white-space: nowrap;
      }
    }
  }
  .qince-login-footer {
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
    .qince-divider {
      width: 60%;
      margin: 0 auto;
      font-size: 12px;
    }
  }
  .qince-login-wechat {
    width: 48px;
    height: 48px;
    background: transparent;
    border-radius: 100%;
    padding: 0;
    margin: 10px auto 15px;
    &:after {
      display: none;
    }
    .qince-icon {
      width: 48px;
      height: 48px;
      line-height: 48px;
      font-size: 48px;
      color: #07c160;
    }
  }
  .qince-login-button {
    background: linear-gradient(90deg, #ff5e3a, #ff9500);
    color: #fff;
    &:after {
      display: none;
    }
    &.weui-btn_disabled {
      opacity: 0.6;
    }
  }
  .qince-login-forgot {
    display: inline-block;
    margin: 16px 0 0 16px;
    font-size: 12px;
    color: #ff9008;
  }
`

const Login = props => {
  const {
    // loading,
    tenantCode,
    userName,
    password,
    isAgree,
    loginTimes,
    dispatchChangeState,
    dispatchLogin,
    dispatchCheckLogin,
    dispatchPhoneLogin,
    dispatchInitHome
  } = props

  const { page } = getCurrentInstance()

  const [showPage, setShowPage] = useState(true)

  const [statusHeight, setStatusHeight] = useState(0)
  const [menuButtonHeight, setMenuButtonHeight] = useState(0)

  useEffect(() => {
    _setTitleHeight()

    Taro.login().then(res => {
      const code = res.code
      Taro.setStorageSync('sessionKey', code)
    })
    // 本地有token  校验token过期
    const _checkToken = async token => {
      let params = {
        token,
        userId: Taro.getStorageSync('userId') || ''
      }
      const result = await dispatchCheckLogin(params)
      return result
    }

    let token = Taro.getStorageSync('qince-token')

    if (token) {
      setShowPage(false)
      Taro.showLoading({
        title: '加载中...'
      })
      _checkToken(token).then(res => {
        // 登录过期 清除首页信息
        if (res.code !== '1') {
          dispatchInitHome()
        }
        Taro.hideLoading()
        setShowPage(true)
      })
    }
  }, []) // eslint-disable-line

  const _setTitleHeight = () => {
    let _statusHeight = Taro?.getMenuButtonBoundingClientRect()?.top || 0
    let _menuButtonHeight = Taro?.getMenuButtonBoundingClientRect()?.height || 0
    setStatusHeight(_statusHeight)
    setMenuButtonHeight(_menuButtonHeight)
  }

  // 修改表单数据
  const handleChange = (val, e) => {
    dispatchChangeState({ [e.target.id]: val })
  }

  // 点击忘记密码
  const handleForgot = () => {
    // eslint-disable-line
    Taro.navigateTo({
      url: '/pages/Login/forgot'
    })
  }

  // 点击微信登录
  const handleClickWeChat = () => {
    Taro.showToast({
      title: '请先阅读并勾选上方协议',
      icon: 'none'
    })
  } // eslint-disable-line

  // 获取手机号码
  const handleGetPhoneNumber = e => {
    // console.log(e, 'eee')
    if (e.detail.iv) {
      Taro.login().then(res => {
        const code = res.code
        const accountInfo = Taro.getAccountInfoSync()
        const params = {
          appId: accountInfo?.miniProgram?.appId || '',
          code,
          data: e.detail.encryptedData || '',
          ivs: e.detail.iv || '',
          isAutoLogin: '0'
        }
        dispatchPhoneLogin(params)
      })
    } else {
      Taro.showToast({
        title: '需要获取您的的手机号码才能使用小程序',
        icon: 'none'
      })
    }
  } // eslint-disable-line

  // 点击阅读并同意
  const handleChangeAgree = e => {
    dispatchChangeState({ isAgree: !!e.detail.value.length })
  }

  // 打开用户使用协议
  const handleProxy = () => {
    Taro.navigateTo({
      url: `/app/Webview/index?url=https%3A%2F%2Fmobile.qince.com%2Fp-faq-1743.html?title=用户使用协议&r=${new Date().getTime()}`
    })
  }

  // 隐私政策
  const handlePrivacy = () => {
    Taro.navigateTo({
      url: `/app/Webview/index?url=https%3A%2F%2Fmobile.qince.com%2Fp-faq-1744.html?title=隐私政策&r=${new Date().getTime()}`
    })
  }

  // 验证码准备就绪
  const handleReady = () => {
    console.log('验证码准备就绪………')
  }

  // 验证码弹框准备关闭
  const handleClose = () => {
    console.log('验证码弹框准备关闭')
  }

  // 验证码出错
  const handleError = () => {
    console.log('验证码出错')
  }

  // 验证码验证结果回调
  const handleVerify = e => {
    if (e.detail.ret === 0) {
      dispatchLogin({ ticket: e.detail.ticket })
    }
  }

  // 点击登录按钮
  const handleClick = () => {
    if (!tenantCode) {
      Taro.showToast({
        title: '请输入企业账号',
        icon: 'none'
      })
      return false
    }
    if (!userName) {
      Taro.showToast({
        title: '请输入个人账号',
        icon: 'none'
      })
      return false
    }
    if (!password) {
      Taro.showToast({
        title: '请输入密码',
        icon: 'none'
      })
      return false
    }
    if (loginTimes >= 3) {
      page.selectComponent('#captcha').show()
    } else {
      Taro.showLoading()
      dispatchLogin()
    }
  }

  return (
    <>
      {showPage && (
        <StyledPage style={{ paddingTop: menuButtonHeight + statusHeight + 36 }}>
          <View className="qince-login-body">
            <View className="login-title">欢迎登录！</View>
            <Cells>
              <Cell>
                <CellBody className="border-b">
                  <Input
                    clear
                    id="tenantCode"
                    name="tenantCode"
                    value={tenantCode}
                    placeholder="请输入企业账号"
                    onChange={handleChange}
                  />
                </CellBody>
              </Cell>
              <Cell>
                <CellBody className="border-b">
                  <Input
                    clear
                    id="userName"
                    name="userName"
                    value={userName}
                    placeholder="请输入个人账号"
                    onChange={handleChange}
                  />
                </CellBody>
              </Cell>
              <Cell>
                <CellBody className="border-b">
                  <View className="flex">
                    <Input
                      showEye
                      clear={false}
                      password
                      name="password"
                      id="password"
                      value={password}
                      placeholder="请输入密码"
                      onChange={handleChange}
                    />
                  </View>
                </CellBody>
              </Cell>
            </Cells>

            <View className="qince-login-btn-area">
              <View className="qince-agree">
                <View className="qince-agree-text">
                  <Label className="qince-agree-label" for="agree">
                    <CheckboxGroup onChange={handleChangeAgree}>
                      <Checkbox
                        className="qince-agree-checkbox"
                        id="agree"
                        value="agree"
                        checked={isAgree}
                      />
                      <View className="qince-agree-checkbox-icon">
                        {isAgree && (
                          <Icons
                            className="qince-agree-checkbox-icon-check"
                            value="right"
                            size={12}
                          />
                        )}
                      </View>
                      我已阅读并同意
                    </CheckboxGroup>
                  </Label>
                  <View onClick={handleProxy} className="qince-agree-link">
                    《用户使用协议》
                  </View>
                  和
                  <View onClick={handlePrivacy} className="qince-agree-link">
                    《隐私政策》
                  </View>
                </View>
              </View>
              <Button
                disabled={!isAgree || !password || !userName || !tenantCode}
                className="qince-login-button"
                onClick={handleClick}
                type="primary"
              >
                登录
              </Button>
            </View>
            <View className="qince-login-forgot" onClick={handleForgot}>
              忘记密码
            </View>
          </View>
          <View className="qince-login-footer">
            <Divider>微信账号登录</Divider>
            {isAgree ? (
              <Button
                openType="getPhoneNumber"
                onGetPhoneNumber={handleGetPhoneNumber}
                className="qince-login-wechat"
              >
                <Image src={Logo}></Image>
              </Button>
            ) : (
              <Button className="qince-login-wechat" onClick={handleClickWeChat}>
                <Image src={Logo}></Image>
              </Button>
            )}
          </View>

          <t-captcha
            id="captcha"
            appId="2021318781"
            onVerify={handleVerify}
            onReady={handleReady}
            onClose={handleClose}
            onError={handleError}
          />
        </StyledPage>
      )}
    </>
  )
}

const mapStateToProps = state => ({
  ...state.Login
})

const mapDispatchToProps = {
  ...actions,
  dispatchInitHome: dispatchInit
}

export default connect(mapStateToProps, mapDispatchToProps)(Login)

import { useState } from 'react'
import { connect } from 'react-redux'
import Taro from '@tarojs/taro'
import { View } from '@tarojs/components'
import { styled } from 'linaria/react'

import * as actions from '@/store/Login'
import { dispatchInit } from '@/store/Home'
import passwordUtils from '@/utils/password'

import { Cells, Cell, CellBody } from '@/components/Cell'
import { Button } from '@/components/Button'
import { Page } from '@/components/Page'
import { Input } from '@/components/Input'

const StyledPage = styled(Page)`
  display: flex;
  flex-direction: column;
  .flex {
    display: flex;
    align-items: center;
    .forget {
      font-size: 14px;
      color: #ff9008;
      margin-left: 8px;
      white-space: nowrap;
    }
  }
  .weui-cells {
    background: none;
    padding: 0 22px;
    &::before,
    &::after {
      display: none;
    }
    .weui-cell {
      padding: 12px 0;
      font-size: 15px;
      &::before {
        display: none;
      }
    }
  }
  .qince-forgot-body {
    .wq-page-hd {
      padding-left: 22px;
      font-size: 22px;
      color: #191c1f;
      margin-bottom: 14px;
    }
  }
  .submit-box {
    padding: 20px;
  }
  .submit-btn {
    border-radius: 4px;
    height: 40px;
    line-height: 40px;
    padding: 0;
    font-size: 16px;
    font-weight: 400;
    border: none;
    outline: none;
  }
`

const SetPassword = ({ dispatchSetPassword, dispatchInitHome }) => {
  const [formData, setFormData] = useState({})

  const handleChange = (val, e) => {
    setFormData({ ...formData, [e.target.id]: val })
  }

  const _validate = params => {
    if (!params.oldPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入新密码！',
        icon: 'none'
      })
      return
    }
    if (!params.newPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入新密码！',
        icon: 'none'
      })
      return
    }
    if (!params.confirmPassword) {
      Taro.showToast({
        mask: true,
        title: '请输入确认新密码！',
        icon: 'none'
      })
      return
    }
    let result = passwordUtils.checkPassword(params.newPassword)
    if (!result.success && formData.strength !== '1') {
      // 低强度走之前校验
      Taro.showToast({
        mask: true,
        title: result.msg,
        icon: 'none'
      })
      return
    }
    if (params.newPassword !== params.confirmPassword) {
      Taro.showToast({
        mask: true,
        title: '新密码和确认新密码不一致！',
        icon: 'none'
      })
      return
    }
    return true
  }

  const handleSubmit = () => {
    // 校验输入内容
    if (!_validate(formData)) {
      return
    }
    dispatchInitHome()
    let params = {
      oldPassword: `${formData.oldPassword}`.trim(),
      password: `${formData.newPassword}`.trim(),
      confpwd: `${formData.confirmPassword}`.trim()
    }
    dispatchSetPassword(params).then(async result => {
      if (result.code === '1') {
        Taro.showModal({
          content: '新密码设置成功，您需要重新登录',
          showCancel: false,
          confirmText: '确定',
          success: () => {
            const user = Taro.getStorageSync('qince-loginInfo')?.userInfo
            Taro.setStorageSync(`${user.userId}-changedPassword`, '1')
            Taro.removeStorageSync('qince-token')
            Taro.redirectTo({
              url: '/pages/Login/index'
            })
          }
        })
      } else {
        Taro.showModal({
          content: result?.error || '设置密码失败，请稍后重试！',
          showCancel: false,
          confirmText: '确定'
        })
      }
    })
  }

  return (
    <StyledPage>
      <View className="qince-forgot-body">
        <Cells>
          <Cell>
            <CellBody className="border-b">
              <Input
                clear
                password
                name="oldPassword"
                id="oldPassword"
                maxLength={20}
                value={formData.oldPassword}
                placeholder="请输入原密码"
                onChange={handleChange}
              />
            </CellBody>
          </Cell>
          <Cell>
            <CellBody className="border-b">
              <Input
                clear
                password
                name="newPassword"
                id="newPassword"
                maxLength={20}
                value={formData.newPassword}
                placeholder="请输入新密码（6-20位）"
                onChange={handleChange}
              />
            </CellBody>
          </Cell>
          <Cell>
            <CellBody className="border-b">
              <Input
                clear
                password
                maxLength={20}
                name="confirmPassword"
                id="confirmPassword"
                value={formData.confirmPassword}
                placeholder="请再次确认新密码（6-20位）"
                onChange={handleChange}
              />
            </CellBody>
          </Cell>
        </Cells>
        <View className="submit-box">
          <Button gradients={['#FF5E3A', '#FF9500']} onClick={handleSubmit}>
            提交
          </Button>
        </View>
      </View>
    </StyledPage>
  )
}
const mapStateToProps = state => ({
  ...state.Login
})

const mapDispatchToProps = {
  ...actions,
  dispatchInitHome: dispatchInit
}
export default connect(mapStateToProps, mapDispatchToProps)(SetPassword)

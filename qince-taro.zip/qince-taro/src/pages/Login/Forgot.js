import { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import Taro, { getCurrentInstance } from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import { styled } from 'linaria/react'

import * as actions from '@/store/Login'
import passwordUtils from '@/utils/password'

import { Cells, Cell, CellBody } from '@/components/Cell'
import { Button } from '@/components/Button'
import { Page } from '@/components/Page'
import { Input } from '@/components/Input'

const StyledPage = styled(Page)`
  display: flex;
  flex-direction: column;
  background-image: url('//res.waiqin365.com/d/qince-h5/platform/login/background.png');
  .header {
    position: absolute;
    width: 100%;
    display: flex;
    align-items: center;
    padding-left: 22px;
    box-sizing: border-box;
    .back-icon {
      height: 16px;
      width: 16px;
    }
  }
  .flex {
    display: flex;
    align-items: center;
    .forget {
      font-size: 14px;
      color: #ff9008;
      margin-left: 8px;
      white-space: nowrap;
    }
  }
  .weui-cells {
    background: none;
    padding: 0 22px;
    &::before,
    &::after {
      display: none;
    }
    .weui-cell {
      padding: 12px 0;
      font-size: 15px;
      &::before {
        display: none;
      }
    }
  }
  .qince-forgot-body {
    .wq-page-hd {
      padding-left: 22px;
      font-size: 22px;
      color: #191c1f;
      margin-bottom: 14px;
    }
  }
  .submit-box {
    padding: 20px;
  }
  .submit-btn {
    border-radius: 4px;
    height: 40px;
    line-height: 40px;
    padding: 0;
    font-size: 16px;
    font-weight: 400;
    border: none;
    outline: none;
  }
`

const Forgot = props => {
  const { dispatchSendVerify, dispatchSubmitChangePassword } = props
  const { page } = getCurrentInstance()

  const [formData, setFormData] = useState({})
  const [countdown, setCountdown] = useState(60)
  const [countBegin, setCountBegin] = useState(false)

  const [statusHeight, setStatusHeight] = useState(0)
  const [menuButtonHeight, setMenuButtonHeight] = useState(0)

  useEffect(() => {
    _setTitleHeight()
  }, [])

  useEffect(() => {
    if (countBegin) {
      handleBeginCountDown()
    }
  }, [countdown, countBegin]) // eslint-disable-line

  const _setTitleHeight = () => {
    let _statusHeight = Taro?.getMenuButtonBoundingClientRect()?.top || 0
    let _menuButtonHeight = Taro?.getMenuButtonBoundingClientRect()?.height || 0
    setStatusHeight(_statusHeight)
    setMenuButtonHeight(_menuButtonHeight)
  }

  const handleChange = (val, e) => {
    setFormData({ ...formData, [e.target.id]: val })
  }

  const _validate = params => {
    if (!params.phone) {
      Taro.showToast({
        title: '请输入手机号码！',
        icon: 'none'
      })
      return false
    }
    if (!/^1\d{10}$/.test(params.phone)) {
      Taro.showToast({
        title: '手机号码格式不合法！',
        icon: 'none'
      })
      return false
    }
    if (!params.verify) {
      Taro.showToast({
        title: '请输入验证码！',
        icon: 'none'
      })
      return false
    }
    if (!params.newPassword) {
      Taro.showToast({
        title: '请输入新密码！',
        icon: 'none'
      })
      return false
    }
    if (!params.confirmPassword) {
      Taro.showToast({
        title: '请输入确认新密码！',
        icon: 'none'
      })
      return false
    }
    let result = passwordUtils.checkPassword(params.newPassword)
    if (!result.success && formData.strength !== '1') {
      // 低强度走之前校验
      Taro.showToast({
        title: result.msg,
        icon: 'none'
      })
      return false
    }
    if (params.newPassword !== params.confirmPassword) {
      Taro.showToast({
        title: '新密码和确认新密码不一致！',
        icon: 'none'
      })
      return false
    }
    return true
  }

  const handleSubmit = () => {
    // 校验输入内容
    if (!_validate(formData)) {
      return
    }

    let params = {
      newpwd: `${formData.newPassword}`.trim(),
      tenantId: `${formData.tenantId}`.trim(),
      userCode: `${formData.userCode}`.trim(),
      validateCode: `${formData.verify}`.trim(),
      keyid: `${formData.keyid}`.trim()
    }
    dispatchSubmitChangePassword(params).then(result => {
      if (result.code === '1') {
        Taro.showModal({
          content: result.message || '新密码设置成功',
          showCancel: false,
          confirmText: '确定',
          success: () => {
            Taro.removeStorageSync('qince-token')
            Taro.navigateBack({
              delta: 1
            })
          }
        })
      } else {
        Taro.showToast({
          title: result.message || '设置密码失败，请稍后重试！',
          icon: 'none'
        })
      }
    })
  }

  const handleSendVerify = () => {
    if (!/^1\d{10}$/.test(formData.phone)) {
      Taro.showToast({
        mask: true,
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return
    }
    page.selectComponent('#captcha').show()
  }

  const handleVerify = e => {
    if (e.detail.ret === 0) {
      try {
        let params = {
          countryCode: '86',
          mobile: formData.phone,
          ticket: e.detail.ticket
        }
        dispatchSendVerify(params).then(res => {
          if (res.code === '1') {
            setFormData({
              ...formData,
              tenantId: res.tenantId,
              userCode: res.userCode,
              keyid: res.keyid,
              strength: res.pwStrength
            })
            setCountdown(60)
            setCountBegin(true)
            Taro.showToast({
              title: '验证码已发送'
            })
          } else {
            Taro.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      } catch (err) {
        Taro.showToast({
          title: '验证码发送失败，请稍后重试',
          icon: 'none'
        })
        console.log(err)
      }
      // dispatchLogin({ ticket: e.detail.ticket })
    }
  }

  const handleBeginCountDown = () => {
    const countdownFn = () => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve(true)
        }, 1000)
      })
    }
    countdownFn().then(() => {
      if (countBegin && countdown <= 1) {
        setCountBegin(false)
        return
      }
      setCountdown(countdown - 1)
    })
  }

  const handleError = err => {
    Taro.showToast({
      title: err,
      icon: 'none'
    })
  }

  const handleBack = () => {
    Taro.navigateBack()
  }

  return (
    <StyledPage>
      <View
        className="header"
        style={{ height: `${menuButtonHeight + statusHeight}px`, paddingTop: `${statusHeight}px` }}
      >
        <Image
          onClick={handleBack}
          className="back-icon"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAtCAYAAADoSujCAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMKADAAQAAAABAAAALQAAAABDRz8/AAACe0lEQVRoBe2Z207CQBCGd6s8BzwKb6JeIScTxUTQiBFN4AZNBMHDjTE+CA/gpddG40tolK4zTQY5tDClu1ua2Julze72++efabuLFJqPo/Nueuh+PojU2lartvumefqZ6ZyZKxEuePDDr4FSIiu+h4Nq8zITYTrWUMnqxeg0ghcqQ92lFO/gRNakE1oE+MHbEhE5hebBowhIp7T4cTdIkO42kgOL4BEW0qjXqu8XdYPTfEsLWAV4FLFUCnHgIfb95nGlRJEy1YZ2gAvfqu8VpZTKFDjNG0oABx5y/gYiX7ABjyLYAlYRni2AAw+xuIW0yduKPDuFVhl+oQMceMj5O8j5bduRX+hAEuADHeDAQ87fQ87n4op8oANJgp9xgAMPz90XJZxDcMClKMTZjt4DHPg4QYPu7QlIKjyKkkmGRwHruACHL64MniTxcHD3wFu7JpEemL0a8HYPYBfBW/4FCYFPYynUs1LmP5GDEPyuj55CLBExfbD5gdO1kQC8kEQRE0tKb/8G9nHm14TK1c7aPQW5RFGIs/WF4Dhhe+UVFCRfAdiZIwKeAX1ba9/QApIiYqIGplUyayIPNdGdHmvrPDCFxgE46QQ1YXQHbpxn/PdcB6gjxwl4CRZqp/adYDlAQjhOOEJeN0/M78gRE8sB6sxxwhWqWG20OzTGdBvKAYLhOAFr5W6rXinTGFNtKAcIguMEvKlLUBNXNMZUu5QDBMNxAmqiAzWxQ2N0t0s5QBAcJ6AmygeNizqN0d1GEoAwi0RALXzIlHzSDU7zRUohmgRbv3RCeJFy8F/K1/G+On9rEzAtwgY83lOrgD8R7iNEftNk5PFe/8cqROAXle6S6vyfgHYAAAAASUVORK5CYII="
        ></Image>
      </View>
      <View className="qince-forgot-body">
        <View
          className="wq-page-hd"
          style={{ paddingTop: `${menuButtonHeight + statusHeight + 36}px` }}
        >
          找回密码
        </View>
        <Cells>
          <Cell>
            <CellBody className="border-b">
              <Input
                clear
                name="phone"
                id="phone"
                maxLength={11}
                value={formData.phone}
                placeholder="请输入您的手机号码"
                onChange={handleChange}
              />
            </CellBody>
          </Cell>
          <Cell>
            <CellBody className="border-b">
              <View className="flex">
                <Input
                  clear={false}
                  name="verify"
                  id="verify"
                  maxLength={6}
                  value={formData.verify}
                  placeholder="请输入验证码"
                  onChange={handleChange}
                />
                {countBegin ? (
                  <View className="forget">{countdown}</View>
                ) : (
                  <View className="forget" onClick={handleSendVerify}>
                    获取验证码
                  </View>
                )}
              </View>
            </CellBody>
          </Cell>
          <Cell>
            <CellBody className="border-b">
              <Input
                clear
                password
                name="newPassword"
                id="newPassword"
                maxLength={20}
                value={formData.newPassword}
                placeholder="请输入新密码（6-20位）"
                onChange={handleChange}
              />
            </CellBody>
          </Cell>
          <Cell>
            <CellBody className="border-b">
              <Input
                clear
                password
                maxLength={20}
                name="confirmPassword"
                id="confirmPassword"
                value={formData.confirmPassword}
                placeholder="请再次确认新密码（6-20位）"
                onChange={handleChange}
              />
            </CellBody>
          </Cell>
        </Cells>
        <View className="submit-box">
          <Button gradients={['#FF5E3A', '#FF9500']} onClick={handleSubmit}>
            提交
          </Button>
        </View>
      </View>
      <t-captcha
        id="captcha"
        appId="2021318781"
        onVerify={handleVerify}
        // onReady={handleReady}
        // onClose={handleClose}
        onError={handleError}
      />
    </StyledPage>
  )
}
const mapStateToProps = state => ({
  ...state.Login
})

const mapDispatchToProps = {
  ...actions
}
export default connect(mapStateToProps, mapDispatchToProps)(Forgot)

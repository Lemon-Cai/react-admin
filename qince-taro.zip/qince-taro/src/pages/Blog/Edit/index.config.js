export default definePageConfig({
  navigationBarTitleText: '新增日报',
})

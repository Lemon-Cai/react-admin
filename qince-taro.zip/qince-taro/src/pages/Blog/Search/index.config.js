/*
 * @Author: CaiPeng
 * @Date: 2023-02-27 15:55:31
 * @LastEditors: caipeng
 * @LastEditTime: 2023-02-27 16:03:42
 * @FilePath: \qince-taro\src\pages\Blog\Search\index.config.js
 * @Description: 
 */
export default definePageConfig({
  navigationBarTitleText: '搜索',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})

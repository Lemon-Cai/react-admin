/*
 * @Author: CaiPeng
 * @Date: 2022-10-26 20:09:00
 * @LastEditors: caipeng
 * @LastEditTime: 2023-04-27 09:34:34
 * @FilePath: \qince-taro\src\pages\Blog\AttentionList\index.js
 * @Description:
 */
import Taro, { useReachBottom } from '@tarojs/taro'
import { useEffect, useState, useRef } from 'react'
import { View, ScrollView, Image, Text } from '@tarojs/components'
import _throttle from 'lodash/throttle'

import { LoadMore } from '@/components/LoadMore'
import { Page, PageBody, PageFooter } from '@/components/Page'
import Employee from '@/components/Employee'
import fetch from '@/utils/request'
// import usePermissions from '@/utils/usePermissions'

import './index.less'

// 数据请求状态
let loading = false

const AttentionList = function() {
  // const { windowHeight } = Taro.getSystemInfoSync()

  const { current: pagination } = useRef({
    page: 1,
    rows: 20
  })
  const [state, setState] = useState({
    hasMore: true,
    loading: true,
    refreshing: false, // 是否处于刷新状态
    list: []
  })

  // const permissions = usePermissions({ menuId: '6778072811795709662' })

  useEffect(() => {
    _initData()
  }, []) // eslint-disable-line

  const _updateState = (val = {}) => {
    setState(prev => ({
      ...prev,
      ...val
    }))
  }

  const _initData = (flag, cb) => {
    // 分页
    if (flag) {
      pagination.page++
    } else {
      pagination.page = 1
    }
    if (!flag) {
      // flag： true：上拉加载， false： 下拉刷新
      _updateState({ refreshing: true })
    }
    fetch({
      url: `/app/blog/v8/getMyBlogAttention.action`,
      method: 'POST',
      params: {
        'params.attention_type': '1',
        'params.rows': pagination.rows,
        'params.page': pagination.page
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }).then(response => {
      let { total, code, data } = response
      let hasMore = true
      let newList = []
      if (code === '1') {
        let arr = (data?.attention || []).map(v => ({
          ...v,
          isFollowed: true,
          dept_name: v.depart_name,
          face_pic: v.small_face
        }))
        newList = pagination.page === 1 ? arr : [...state.list, ...arr]
        // 判断是否无更多数据
        if (newList.length >= total) {
          hasMore = false
        }
        // 判断是否暂无数据
        if ((data?.attention || []).length === 0 && newList.length === 0) {
          hasMore = false
        }
      } else {
        hasMore = false
      }
      cb?.(newList)
      setState({
        ...state,
        list: newList,
        refreshing: false,
        hasMore
      })
    })
  }

  // 滑动加载
  useReachBottom(async () => {
    if (state.hasMore) {
      _initData(true)
    }
  })

  // 下拉刷新
  const handleRefresh = e => {
    console.log('first: 刷新', e)
    _initData()
  }

  const handlePageScroll = _throttle(function() {
    // currentPage.scrollTop = e.detail.scrollTop
    // _updateRedux()
  }, 500)
  // 触底下拉加载
  const handleScrollBottom = e => {
    console.log('first: 触底', e)
    if (state.hasMore) {
      // 修改加载状态
      _initData(true)
    }
  }
  const handleLinkToUserDetail = id => {
    const user = Taro.getStorageSync('qince-loginInfo')?.userInfo
    Taro.navigateTo({
      title: '个人动态',
      url: `/pages/Blog/Person/index?id=${id}&userId=${user?.id}&tempUserCode=${id}`
    })
  }

  const handleToggleAttention = (isFollowed, id) => {
    if (isFollowed) {
      Taro.showModal({
        title: '',
        content: '确定要取消关注吗？',
        success: function(res) {
          if (res.confirm) {
            const params = {
              'params.user_id': id,
              'params.is_attention': '0'
            }
            dispatchUpdateUserAttention(params)
          }
        }
      })
    } else {
      const params = {
        'params.user_id': id,
        'params.is_attention': '1'
      }
      dispatchUpdateUserAttention(params)
    }
  }
  const dispatchUpdateUserAttention = params => {
    if (loading) {
      return
    }
    loading = true
    fetch({
      url: '/app/blog/v8/updateBlogAttentionForEmployee.action',
      params: params,
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
      .then(response => {
        if (response.code === '1') {
          let newList = state.list.map(item => {
            return {
              ...item,
              isFollowed: item.id === params['params.user_id'] ? !item.isFollowed : item.isFollowed
            }
          })
          let pages = Taro.getCurrentPages()
          let currentPage = pages[pages.length - 1]
          const eventChannel = currentPage.getOpenerEventChannel()
          // 通知列表页面刷新数据
          let attendList = newList.filter(v => v.isFollowed) // 现在关注的列表
          eventChannel.emit('reloadData', attendList.length !== 0, newList)
          _updateState({
            list: newList
          })
        }
        loading = false
      })
      .catch(() => {
        loading = false
      })
  }

  const handleEmpSubmit = val => {
    console.log('val', val)
    fetch({
      url: '/app/blog/v8/batchSaveBlogAttention.do',
      params: {
        empIds: val.map(v => v.id).join(',')
      }
    }).then(res => {
      if (res.code === '1') {
        Taro.showToast({
          icon: 'none',
          title: '添加成功',
          success() {
            _initData(false, list => {
              let pages = Taro.getCurrentPages()
              let currentPage = pages[pages.length - 1]
              const eventChannel = currentPage.getOpenerEventChannel()
              // 通知列表页面刷新数据
              let attendList = list.filter(v => v.isFollowed) // 现在关注的列表
              eventChannel.emit('reloadData', attendList.length !== 0, list)
            })
          }
        })
      } else {
        Taro.showToast({
          icon: 'none',
          title: res?.message || '请求异常'
        })
      }
    })
  }

  return (
    <Page>
      <PageBody className="scroll-container">
        <ScrollView
          className="scrollView"
          scrollY
          enablePassive // 该参数必传，不然flex布局有问题
          enableBackToTop
          scrollWithAnimation
          refresherEnabled
          // pagingEnabled
          onScroll={handlePageScroll}
          refresherTriggered={state.refreshing}
          onScrollToLower={handleScrollBottom}
          onRefresherRefresh={handleRefresh}
        >
          {state.list?.length > 0 &&
            state.list.map(item => (
              <View class="attention-list-item" key={item.id}>
                <View class="att-left-info">
                  <View class="base-info">
                    <View class="info-avatar" onClick={() => handleLinkToUserDetail(item.id)}>
                      <Image src={item.small_face} alt />
                    </View>
                    <View class="info-main">
                      <View class="info-name">{item.name}</View>
                      <View class="info-position">{item.depart_name}</View>
                    </View>
                  </View>
                </View>
                <View
                  class="att-right-btn"
                  onClick={() => handleToggleAttention(item.isFollowed, item.id)}
                >
                  {!item.isFollowed ? (
                    <View class="btn-not">关注</View>
                  ) : (
                    <View class="btn-followed">已关注</View>
                  )}
                </View>
              </View>
            ))}
          {state.hasMore ? (
            <LoadMore status={1} />
          ) : (
            <View className="end-message">
              <View>没有更多数据了</View>
            </View>
          )}
        </ScrollView>
      </PageBody>
      {/* {permissions.includes('ADD_ATTENTION') && ( */}
        <PageFooter>
          <Employee value={state.list} onChange={handleEmpSubmit}>
            <View className="btn-add">
              <View className="wq-icon-add"></View>
              <Text>添加关注</Text>
            </View>
          </Employee>
        </PageFooter>
      {/* // )} */}
    </Page>
  )
}

export default AttentionList

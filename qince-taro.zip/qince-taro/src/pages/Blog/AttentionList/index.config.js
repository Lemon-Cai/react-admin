/*
 * @Author: CaiPeng
 * @Date: 2023-02-08 20:29:06
 * @LastEditors: caipeng
 * @LastEditTime: 2023-02-09 13:31:01
 * @FilePath: \qince-taro\src\pages\Blog\BlogTypes\index.config.js
 * @Description: 
 */
export default definePageConfig({
  navigationBarTitleText: '我的关注',
  enablePullDownRefresh: false,
})

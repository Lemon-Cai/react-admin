/*
 * @Author: CaiPeng
 * @Date: 2023-02-20 14:06:44
 * @LastEditors: caipeng
 * @LastEditTime: 2023-02-20 15:34:11
 * @FilePath: \qince-taro\src\pages\Blog\Detail\index.config.js
 * @Description: 
 */
export default definePageConfig({
  navigationBarTitleText: ''
})

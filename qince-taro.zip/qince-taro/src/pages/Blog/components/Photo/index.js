import { forwardRef, useMemo, useState, useEffect, useImperativeHandle } from 'react'
import Taro from '@tarojs/taro'
import { View, Image } from '@tarojs/components'

import { Icons } from '@/components/Icons'

import './index.less'

// 缩略图后缀
const SMALL_SUFFIX = '?x-oss-process=style/zk320'

const Photo = (props, ref) => {
  // 获取屏幕宽高度
  const width = useMemo(() => {
    const { windowWidth } = Taro.getSystemInfoSync()
    return (windowWidth - 54) / 4
  }, [])

  const {
    hidden, // 是否隐藏渲染内容，但可以通过ref获取组件示例
    uploadDir, // 上传路径
    immediate, // 立即上传
    mode = 'aspectFill',
    value = [], // 照片数据
    max = 0,
    sourceType,
    readonly = false,
    disable = false,
    onChooseImageBefore,
    onChange
  } = props

  const [currentValue, setCurrentValue] = useState([])

  const count = useMemo(() => max - value.length, [max, value])

  useImperativeHandle(ref, () => ({
    clickUpload: handleClickUpload
  }))

  useEffect(() => {
    if (Array.isArray(value)) {
      setCurrentValue([
        ...value.map(photo => {
          if (typeof photo === 'string') {
            return photo.indexOf(SMALL_SUFFIX) !== -1
              ? { pic: photo }
              : { pic: `${photo}${SMALL_SUFFIX}` }
          }
          let url = photo.pic
          return url.indexOf(SMALL_SUFFIX) !== -1
            ? { ...photo }
            : { ...photo, pic: `${url}${SMALL_SUFFIX}` }
        })
      ])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(value)])

  // 点击照片查看大图
  const handleClick = index => {
    Taro.previewImage({
      current: currentValue[index].pic,
      urls: currentValue.map(item => item.pic)
    })
  }

  const handleClickUpload = () => {
    if (typeof onChooseImageBefore === 'function') {
      onChooseImageBefore()
    }
    if (count > 0) {
      Taro.chooseImage({
        count: count,
        sourceType: sourceType || ['album', 'camera'],
        success: async function(res) {
          let files = res.tempFiles || []
          let chooseImgs = files.map(o => ({ pic: o.path }))

          if (immediate) {
            const response = await _uploadImage(chooseImgs, uploadDir)
            if (response.code === '1') {
              let data = [
                ...currentValue,
                ...(response.data || []).map(v => ({
                  ...v,
                  pic: `${v.url}${SMALL_SUFFIX}`
                }))
              ]
              setCurrentValue(data)
              onChange?.(data)
            }
          } else {
            let pic = [...currentValue, ...chooseImgs]
            setCurrentValue(pic)
            onChange?.(pic)
          }
        },
        fail: function(e) {
          console.log('chooseImage fail', e)
        }
      })
    }
  }

  const handleDelete = (e, index) => {
    e.stopPropagation()
    let newVal = [...currentValue]
    newVal.splice(index, 1)
    setCurrentValue(newVal)
    onChange?.(newVal)
  }

  if (readonly) {
    return (
      <View className="wq-blog-photos">
        {(currentValue || []).map((photo, index) => {
          return index < 3 ? (
            <View
              key={`wq-blog-photo-${index}`}
              className="wq-blog-photo"
              style={{
                width: width,
                height: width
              }}
              onClick={() => handleClick(index)}
            >
              {value.length > 3 && index === 2 && (
                <View>
                  <View className="wq-blog-photo-mask"></View>
                  <View className="wq-blog-photo-length">+{value.length - 3}</View>
                </View>
              )}
              <Image
                className="wq-blog-photo-image"
                mode={mode}
                src={photo.pic}
              />
            </View>
          ) : (
            ''
          )
        })}
      </View>
    )
  }

  return (
    !hidden && (
      <View className="wq-blog-photos">
        {(currentValue || []).map((photo, index) => {
          return (
            <View
              key={`wq-blog-photo-${index}`}
              className="wq-blog-photo"
              style={{
                width: width,
                height: width
              }}
              onClick={() => handleClick(index)}
            >
              <Image
                className="wq-blog-photo-image"
                mode={mode}
                src={photo.pic}
              />
              {!disable && <Icons value="clear" onClick={e => handleDelete(e, index)} />}
            </View>
          )
        })}
        {count > 0 && !disable && (
          <View className="wq-uploader-btn-wrap">
            <View className="wq-uploader-btn" onClick={handleClickUpload}></View>
          </View>
        )}
      </View>
    )
  )
}

export const _uploadImage = async (list = [], uploadDir) => {
  let promiseArr = list.map(item => {
    return new Promise(resolve => {
      Taro.uploadFile({
        url: `${Taro.getStorageSync('appsvrUrl')}/platform/fileupload/v1/doUpload.do`,
        filePath: item.pic,
        name: 'file',
        withCredentials: true,
        formData: {
          file: item.pic,
          uploadPath: uploadDir
        },
        header: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${Taro.getStorageSync('qince-token')}` // 上传需要单独处理cookie
        },
        success(result) {
          // console.log('result:', result)
          resolve(result)
        },
        fail(e) {
          // console.log('uploadFile fail:', e)
          resolve({ e, domain: Taro.getStorageSync('appsvrUrl') })
        }
      })
    })
  })
  let result = await Promise.all(promiseArr)
  if (Array.isArray(result)) {
    let data = []
    let fail = null
    result.forEach(item => {
      let res = item.data ? JSON.parse(item.data) : {}
      if (res.code === '1') {
        data.push(...(res.data || []))
      } else {
        fail = res
      }
    })
    if (fail) {
      // 保证全部成功
      return Promise.resolve({ code: '0', data: [], message: '图片上传失败', ...fail })
    }
    return Promise.resolve({ code: '1', data })
  }

  let res = result.data ? JSON.parse(result.data) : {}
  return Promise.resolve(res)
}

export default forwardRef(Photo)

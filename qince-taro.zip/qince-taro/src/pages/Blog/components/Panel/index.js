/*
 * @Author: CaiPeng
 * @Date: 2022-09-14 15:49:15
 * @LastEditors: caipeng
 * @LastEditTime: 2023-03-03 10:20:02
 * @FilePath: \qince-taro\src\pages\Blog\components\Panel\index.js
 * @Description:
 */
import { View } from '@tarojs/components'

import BlogHeader from './Header'
import BlogBody from './Body'
import BlogFooter from './Footer'
import BlogOther from './Other'
import './index.less'

export default props => {
  const {
    value,
    userId,
    onPanelClick,
    onClickLink,
    onClickDelete,
    onClickPraise,
    onClickComment,
    onClickReply,
    onClickShare,
    onClickAttend
  } = props

  // 点击日报，查看日报详情
  const handleClick = e => {
    e.stopPropagation()
    onPanelClick && onPanelClick()
  }

  return (
    <View className='wq-blog-panel' onClick={handleClick}>
      <BlogHeader value={value} onClickAvatar={props.onClickAvatar} onClickAttend={onClickAttend} />
      <BlogBody value={value} onClickContent={onClickLink} />
      <BlogFooter
        value={value}
        userId={userId}
        onDeleteBlog={onClickDelete}
        onClickPraise={onClickPraise}
        onClickComment={onClickComment}
        onClickReply={onClickReply}
        onClickShare={onClickShare}
      />
      {value?.blog_type !== '3' && <BlogOther value={value} onClickReply={onClickReply} />}
    </View>
  )
}

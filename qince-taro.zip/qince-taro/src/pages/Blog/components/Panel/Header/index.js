/*
 * @Author: CaiPeng
 * @Date: 2022-09-14 15:49:15
 * @LastEditors: caipeng
 * @LastEditTime: 2023-04-25 15:53:53
 * @FilePath: \qince-taro\src\pages\Blog\components\Panel\Header\index.js
 * @Description:
 */
import { View, Text } from '@tarojs/components'
import classNames from 'classnames'

import { Avatar } from '@/components/Avatar'
import { Rate } from '@/components/Rate'

export default props => {
  const { value, onClickAvatar, onClickAttend } = props

  // 点击头像事件
  const handleClickAvatar = () => {
    onClickAvatar && onClickAvatar()
  }

  const handleChangeAttend = () => {
    onClickAttend?.(value)
  }

  return (
    <View className='wq-blog-panel-hd'>
      {value?.blog_type === '3' ? (
        <>
          <Avatar
            className='wq-blog-avatar'
            image={value?.publish_small_face}
            text={value?.commenter_name}
            onClick={handleClickAvatar}
          />
          <View className='weui-flex'>
            <View className='wq-blog-title weui-flex'>
              <Text className='qince-blog-title-item'>{value?.commenter_name}</Text>
              {value?.comment_content === '赞了我的日报' ? '赞了' : '评论'}
              <Text className='qince-blog-title-item'>{value?.commented_name}</Text>的
              {value?.commented_type_name}
            </View>
            <View class="qince-blog-attend" style={{alignSelf: 'center'}}>
              {value?.hasAttendAuth && (
                <Text className={classNames('qince-blog-attend-btn', {active: value?.hasAttend})} onClick={handleChangeAttend}>
                  {value.hasAttend ? '已关注' : '关注'}
                </Text>
              )}
            </View>
          </View>
        </>
      ) : (
        <>
          <Avatar
            className='wq-blog-avatar'
            image={value?.publish_small_face}
            text={value?.publish_name}
            onClick={handleClickAvatar}
          />
          <View className='weui-flex__item'>
            <View className='weui-flex'>
              <View className='weui-flex weui-flex__item'>
                <Text numberOfLine={2} className='wq-blog-name'>{value?.publish_name}</Text>
                <View class="qince-blog-attend" style={{alignSelf: 'center'}}>
                  {value.hasAttendAuth && (
                    <Text className={classNames('qince-blog-attend-btn', {active: value?.hasAttend})} onClick={handleChangeAttend}>
                      {value.hasAttend ? '已关注' : '关注'}
                    </Text>
                  )}
                </View>
              </View>
              {value?.blog_type !== '2' && value?.blog_type !== '100' && value?.score > 0 && (
                <View className='wq-blog-star'>
                  <Rate value={value?.score} readonly />
                </View>
              )}
            </View>
            <View className='wq-blog-dept weui-flex'>
              <Text className='weui-flex__item'>{value?.dept_name}</Text>
              <Text className='weui-flex__item' style={{ textAlign: 'right' }}>
                {value?.blog_type_name}
              </Text>
            </View>
          </View>
        </>
      )}
    </View>
  )
}

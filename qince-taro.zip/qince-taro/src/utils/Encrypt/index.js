import Taro from '@tarojs/taro'
import { JSEncrypt } from 'jsencrypt'

export default {
  // 获取登录的配置文件
  // 密码asr编码
  rsaEncode: function(password, publicKey) {
    let rsaType = ''
    if (publicKey) {
      var encrypt = new JSEncrypt() // eslint-disable-line
      rsaType = '1'
      encrypt.setPublicKey(publicKey)
      var newPassword = encrypt.encrypt(password)
      return {
        password: newPassword,
        rsaType: '1'
      }
    }
    rsaType = '0'
    return {
      password: btoa(password),
      rsaType: rsaType
    }
  },
  // 密文登录: 获取asr加密公钥
  getAsrPublicKey: function() {
    return Taro.request({
      url: `${HOST}/platform/encrypt/getPublicKey` // eslint-disable-line
    })
  }
}

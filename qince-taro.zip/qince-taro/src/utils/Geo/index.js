// 地址逆解析
import Taro from '@tarojs/taro'

import fetch from '@/utils/request'

// import CoordTransform from './CoordTransform'

/**
 * 获取地理位置
 * @param {*} flag 是否需要逆解析
 * @param {*} params 获取定位入参 type ： wgs84 返回 gps 坐标，gcj02 返回可用于 Taro.openLocation 的坐标
 * @returns
 */
export async function getAddress(params, flag = true) {
  Taro.showLoading({
    title: '获取位置中…',
    mask: true
  })
  // 判断缓存中是否存在位置信息，切未过期
  let cacheDate = Taro.getStorageSync('cache_location_with_expire')
  if (cacheDate) {
    let dateTime = +new Date()
    if (dateTime - cacheDate.time < 10 * 1000) {
      // 未过期
      let location = cacheDate.location
      if (flag) {
        // 需要逆解析
        let response = await geocoder({
          latlon: location.latlon,
          pointType: 'gcj02'
        })
        Taro.hideLoading()
        return Promise.resolve({
          ...response,
          ...location
        })
      } else {
        Taro.hideLoading()
        return Promise.resolve({
          code: '1',
          ...location
        })
      }
    } else {
      Taro.removeStorageSync('cache_location_with_expire')
    }
  }

  return new Promise((resolve, reject) => {
    Taro.getLocation({
      ...params,
      async success (result) {
        if (result.errMsg === 'getLocation:ok') {
          let location = {
            type: '1',
            latitude: result.latitude, // 纬度
            longitude: result.longitude, // 经度
            latlon: result.latitude + ',' + result.longitude
          }
          Taro.setStorageSync('cache_location_with_expire', {
            location: {
              latitude: result.latitude, // 纬度
              longitude: result.longitude, // 经度
              latlon: result.latitude + ',' + result.longitude,
            },
            time: +new Date()
          })
          if (flag) {
            // 需要逆解析
            let response = await geocoder({
              latlon: location.latlon,
              pointType: 'gcj02'
            })
            Taro.hideLoading()
            resolve({
              ...response,
              ...location
            })
          } else {
            Taro.hideLoading()
            resolve({
              code: '1',
              ...location
            })
          }
        } else {
          Taro.hideLoading()
          reject({
            code: '0',
            message: '无法获取您的位置信息，请授权获取位置信息'
          })
        }
      },
      fail () {
        reject({
          code: '0',
          message: '无法获取您的位置信息，请授权获取位置信息'
        })
      },
      complete () {
        Taro.hideLoading()
      }
    })
    
  })
  
}

function geocoder(params) {
  return new Promise((resolve, reject) => {
    fetch({
      url: `/platform/param/v1/getGeocoder.do`,
      method: 'POST',
      params: {
        latlon: params.latlon,
        pointType: params.pointType || 'bd09'
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
      .then(response => {
        if (response.code === '1') {
          let data = response.data
          resolve({
            code: '1',
            province: data.province && data.province.name,
            mss_province: data.province && data.province.scale,
            city: data.city && data.city.name,
            mss_city: data.city && data.city.scale,
            area: data.district && data.district.name,
            mss_area: data.district && data.district.scale,
            street: data.area && data.town.name,
            mss_street: data.area && data.town.scale,
            address: data.addr
          })
        } else {
          resolve({
            code: '0',
            message: '地址解析失败！'
          })
        }
      })
      .catch(() => {
        reject({
          code: '0',
          message: '地址解析失败！'
        })
      })
  })
}

/*
 * @Author: CaiPeng
 * @Date: 2022-09-14 15:49:15
 * @LastEditors: caipeng
 * @LastEditTime: 2023-02-10 15:03:16
 * @FilePath: \qince-taro\src\utils\format.js
 * @Description: 
 */
export default {
  formatDateDiff (val) {
    if (val) {
      let now = new Date()
      let target = new Date(val.substr(0, val.indexOf('.') - 1).replace(/-/g, '/'))
      let result = parseInt((now.getTime() - target.getTime()) / 1000)
      let yd = target.getFullYear() + '年'
      let md = ((target.getMonth() + 1) >= 10 ? (target.getMonth() + 1) : '0' + (target.getMonth() + 1)) + '月'
      let dd = (target.getDate() < 10 ? '0' + target.getDate() : target.getDate()) + '日'
      let hd = (target.getHours() < 10 ? '0' + target.getHours() : target.getHours())
      let id = (target.getMinutes() < 10 ? ('0' + target.getMinutes()) : target.getMinutes())
      if (result < 60) {
        return '刚刚'
      } else if (result < 3600) {
        return parseInt(result / 60) + '分钟前'
      } else if (result >= 3600 && now.getDate() - target.getDate() === 0 && now.getMonth() - target.getMonth() === 0) {
        return '今天 ' + hd + ':' + id
      } else if (now.getFullYear() - target.getFullYear() === 0) {
        return md + dd + ' ' + hd + ':' + id
      } else {
        return yd + md + dd + ' ' + hd + ':' + id
      }
    }
    return ''
  },
  formatEmotion: function (val) {
    if (typeof val === 'string') {
      const emotions = ['[微笑]', '[撇嘴]', '[色]', '[发呆]', '[得意]', '[流泪]', '[害羞]', '[闭嘴]', '[睡]', '[大哭]', '[尴尬]', '[发怒]', '[调皮]', '[呲牙]', '[惊讶]', '[难过]', '[酷]', '[冷汗]', '[抓狂]', '[吐]', '[偷笑]', '[可爱]', '[白眼]', '[傲慢]', '[饥饿]', '[困]', '[惊恐]', '[流汗]', '[憨笑]', '[大兵]', '[奋斗]', '[咒骂]', '[疑问]', '[嘘]', '[晕]', '[折磨]', '[衰]', '[骷髅]', '[敲打]', '[再见]', '[擦汗]', '[抠鼻]', '[鼓掌]', '[糗大了]', '[坏笑]', '[左哼哼]', '[右哼哼]', '[哈欠]', '[鄙视]', '[委屈]', '[快哭了]', '[阴险]', '[亲亲]', '[吓]', '[可怜]', '[菜刀]', '[西瓜]', '[啤酒]', '[篮球]', '[乒乓]', '[咖啡]', '[饭]', '[猪头]', '[玫瑰]', '[凋谢]', '[示爱]', '[爱心]', '[心碎]', '[蛋糕]', '[闪电]', '[炸弹]', '[刀]', '[足球]', '[瓢虫]', '[便便]', '[月亮]', '[太阳]', '[礼物]', '[拥抱]', '[强]', '[弱]', '[握手]', '[胜利]', '[抱拳]', '[勾引]', '[拳头]', '[差劲]', '[爱你]', '[NO]', '[OK]', '[爱情]', '[飞吻]', '[跳跳]', '[发抖]', '[怄火]', '[转圈]', '[磕头]', '[回头]', '[跳绳]', '[挥手]', '[激动]', '[街舞]', '[献吻]', '[左太极]', '[右太极]', '[删除]']
      return val.replace(/\[[\u4e00-\u9fa5]{1,3}\]|\[\w{1,3}\]/gi, function ($1) {
        const index = emotions.indexOf($1)
        if (index !== -1) {
          return `<img style="width:16px;height:16px;vertical-align:-3px;" src="//res.waiqin365.com/d/common_mobile/images/emotion/im_ee_${index + 1}.png">`
        }
        return $1
      })
    }
    return val
  },
  formatCurrency: function (val) {
    if (val) {
      let parts = val.toString().split('.')
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',')
      return parts.join('.')
    }
    return ''
  }
}
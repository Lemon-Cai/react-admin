import { useState, useEffect } from 'react'
import fetch from '@/utils/request'

/**
 * 菜单权限hook
 * @param {*} params
 * @description 查看（VIEW）新增（ADD）导出（EXPORT）打印（PRINT）复制（COPY）编辑 （EDIT）审批（APPROVAL）打回（UNAPPROVAL）删除（DELETE）红冲（HC）
 * @returns
 */
const usePermissions = params => {
  const [permissions, setPermissions] = useState([])

  useEffect(() => {
    fetch({
      url: params.url || '/platform/menu/v1/getMenuOpCodes.do',
      params: {
        menu_id: params.menuId
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }).then(response => {
      if (response?.code === '1') {
        setPermissions(response?.data || [])
      }
    })
  }, []) // eslint-disable-line

  return permissions
}

export default usePermissions

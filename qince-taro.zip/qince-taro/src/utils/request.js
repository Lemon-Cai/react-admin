import Taro from '@tarojs/taro'
import configStore from '../store'
/**
 * HOST 是在 config 中通过 defineConstants 配置的
 * 只所以不在代码中直接引用，是因为 eslint 会报 no-undef 的错误，因此用如下方式处理
 */
/* eslint-disable */
const host = HOST
const CODE_SUCCESS = '1'
const CODE_AUTH_EXPIRED = 401

function getStorage(key) {
  return Taro.getStorage({ key }).then(res => res.value).catch(() => '')
}

function updateStorage(param = {}) {
  return Promise.all([
    Taro.setStorage({ key: 'x-token', value: param.data })
  ])
}

/**
 * 封装网络请求
 * @param {*} options
 */
export default async function fetch (options) {
  const { host = Taro.getStorageSync('appsvrUrl') || 'https://xiaocui.waiqin365.com', url, params, method = 'POST', showToast = true, autoLogin = true, header = {} } = options
  const token = await Taro.getStorageSync('qince-token')
  const _header = token ? { ...header, 'Authorization': `Bearer ${token}`} : {...header}
  return Taro.request({
    url: `${host}${url}`,
    method,
    data: params,
    header: _header
  }).then(async (res) => {
    const { statusCode, data } = res
    if (statusCode !== 200) {
      await updateStorage({})
      Taro.showToast({
        mask: true,
        title: '服务器忙，请稍后重试！',
        icon: 'none'
      })
    }

    if (data?.code !== CODE_SUCCESS && statusCode ===  CODE_AUTH_EXPIRED) {
      setTimeout(async () => {
        await updateStorage({})
        const store = configStore()
        store.dispatch({
          type: 'HOME/INIT'
        })
        Taro.redirectTo({
          url: '/pages/Login/index'
        })
      }, 1500)
    }
 
    // return res.data
    return data
  }).catch((err) => {
    const defaultMsg = err.code === CODE_AUTH_EXPIRED ? '登录失效' : '请求异常'
    if (showToast) {
      Taro.showToast({
        mask: true,
        title: err && err.errorMsg || defaultMsg,
        icon: 'none'
      })
    }

    if (err.code === CODE_AUTH_EXPIRED && autoLogin) {
      Taro.redirectTo({
        url: '/pages/Login/index'
      })
    }

    return Promise.reject({ message: defaultMsg, ...err })
  })
}